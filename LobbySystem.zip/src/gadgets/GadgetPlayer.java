package gadgets;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Random;

import lobbySystem.Main;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Color;
import org.bukkit.Effect;
import org.bukkit.FireworkEffect;
import org.bukkit.FireworkEffect.Type;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.EnderPearl;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Firework;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.entity.TNTPrimed;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.meta.FireworkMeta;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import utils.ItemCreator;
import utils.SBManager;
import boots.BootPlayer;
import coinAPI.CoinAPI;
import de.slikey.effectlib.EffectManager;
import de.slikey.effectlib.effect.StarEffect;
import de.slikey.effectlib.effect.TextEffect;
import de.slikey.effectlib.util.ParticleEffect;

public class GadgetPlayer implements Listener {

	private static Main m = Main.getMain();
	
	public static HashMap<Player, Integer> gadgetCooldown = new HashMap<Player, Integer>();
	public static ArrayList<Player> smashingPlayers = new ArrayList<Player>();
	public static HashMap<Location, Integer> vulcanLocations = new HashMap<Location, Integer>();
	public static HashMap<Location, Integer> tntFountainLocations = new HashMap<Location, Integer>();
	public static ArrayList<TNTPrimed> primedTNT = new ArrayList<TNTPrimed>();
	public static HashMap<Item, Player> axes = new HashMap<Item, Player>();
	public static HashMap<Item, Player> slimes = new HashMap<Item, Player>();
	public static HashMap<Player, BukkitRunnable> discoPlayers = new HashMap<Player, BukkitRunnable>();
	public static HashMap<Player, Integer> discoTimeToPlay = new HashMap<Player, Integer>();
	
	public static void startGadgetCooldown() {
		Bukkit.getScheduler().scheduleSyncRepeatingTask(m, new Runnable() {
			
			@Override
			public void run() {
				for(Player players : gadgetCooldown.keySet()) {
					if(gadgetCooldown.get(players) <= 0) {
						gadgetCooldown.remove(players);
					} else {
						gadgetCooldown.replace(players, gadgetCooldown.get(players) - 1);
					}
				}
			}
		}, 20, 20);
	}
	
	
	@SuppressWarnings("deprecation")
	@EventHandler
	public void onInteract(PlayerInteractEvent e) {
		Player p = e.getPlayer();
		
		if(e.getAction() == Action.RIGHT_CLICK_AIR) {
			if(GadgetManager.playerGadgets.containsKey(p)) {
				Gadget gadget = GadgetManager.playerGadgets.get(p);
				if(e.getItem().getType() == gadget.getMat() && e.getItem() != null && e.getItem().hasItemMeta() && e.getItem().getItemMeta().getDisplayName() == gadget.getDisplayname()) {
					e.setCancelled(true);
					if(CoinAPI.getCoins(p.getUniqueId()) >= gadget.getCost()) {
						if(gadgetCooldown.containsKey(p)) {
							p.sendMessage(ChatColor.translateAlternateColorCodes('&', m.getMessage("gadgetCooldown")
									.replace("[prefix]", m.prefix).replace("[time]", "" + gadgetCooldown.get(p))));
							return;
						}
						
						EffectManager em = new EffectManager(m);
						
						switch (gadget) {
						case FIREWORK:
							CoinAPI.removeCoins(p.getUniqueId(), gadget.getCost());
							SBManager.updateLobbySB(p);
							if(!p.hasPermission(m.getPermission("gadgetsCooldownBypass"))) {gadgetCooldown.put(p, m.getConfigValueInt("gadgetCooldown"));}
							
							for(int i = 0; i < 20; i++) {
								Random random = new Random();
								Color randColor1 = Color.fromRGB(random.nextInt(255), random.nextInt(255), random.nextInt(255));
								Color randColor2 = Color.fromRGB(random.nextInt(255), random.nextInt(255), random.nextInt(255));
								Type randType = Type.values()[random.nextInt(Type.values().length)];
								int power = random.nextInt(2) + 1;
								
								Location loc = p.getLocation().add(random.nextInt(20) - 10, 0, random.nextInt(20) - 10);
								
								Firework firework = p.getWorld().spawn(loc, Firework.class);
								
								FireworkEffect effect = FireworkEffect.builder().withColor(randColor1).flicker(true).trail(true).withFade(randColor2).with(randType).build();
								FireworkMeta meta = firework.getFireworkMeta();
								meta.addEffect(effect);
								meta.setPower(power);
								firework.setFireworkMeta(meta);
							}
							
							break;
							
						case ENDERPEARL:
							CoinAPI.removeCoins(p.getUniqueId(), gadget.getCost());
							SBManager.updateLobbySB(p);
							if(!p.hasPermission(m.getPermission("gadgetsCooldownBypass"))) {gadgetCooldown.put(p, m.getConfigValueInt("gadgetCooldown"));}
							
							EnderPearl enderpearl = p.launchProjectile(EnderPearl.class);
							enderpearl.setPassenger(p);
							
							break;
							
						case SMASH:
							if(!smashingPlayers.contains(p)) {
								CoinAPI.removeCoins(p.getUniqueId(), gadget.getCost());
								SBManager.updateLobbySB(p);
								if(!p.hasPermission(m.getPermission("gadgetsCooldownBypass"))) {gadgetCooldown.put(p, m.getConfigValueInt("gadgetCooldown"));}
							
								p.setVelocity(new Vector(0, 3, 0));
								smashingPlayers.add(p);
							}
							
							break;
							
						case STAR:
							p.playSound(p.getLocation(), Sound.BLOCK_NOTE_PLING, 3, 2);
							CoinAPI.removeCoins(p.getUniqueId(), gadget.getCost());
							SBManager.updateLobbySB(p);
							if(!p.hasPermission(m.getPermission("gadgetsCooldownBypass"))) {gadgetCooldown.put(p, m.getConfigValueInt("gadgetCooldown"));}
							
							StarEffect star = new StarEffect(em);
							star.duration = 5000;
							star.particle = ParticleEffect.FLAME;
							star.setLocation(p.getLocation().add(0, 7, 0));
							star.start();
							
							break;
							
							
						case ROCKET:
							if(p.isOnGround()) {
								if(!p.hasPermission(m.getPermission("gadgetsCooldownBypass"))) {gadgetCooldown.put(p, m.getConfigValueInt("gadgetCooldown"));}
								CoinAPI.removeCoins(p.getUniqueId(), gadget.getCost());
								SBManager.updateLobbySB(p);
								
								Firework fw = p.getWorld().spawn(p.getLocation(), Firework.class);
								FireworkMeta fwm = fw.getFireworkMeta();
								fwm.setPower(3);
								
								for(int i= 0; i < 10; i++) {
									Random random = new Random();
									Color randColor1 = Color.fromRGB(random.nextInt(255), random.nextInt(255), random.nextInt(255));
									Color randColor2 = Color.fromRGB(random.nextInt(255), random.nextInt(255), random.nextInt(255));
									Type randType = Type.values()[random.nextInt(Type.values().length)];
									
									FireworkEffect effect = FireworkEffect.builder().withColor(randColor1).flicker(true).trail(true).withFade(randColor2).with(randType).build();

									fwm.addEffect(effect);
								}
								
								fw.setFireworkMeta(fwm);
								fw.setPassenger(p);
								p.getWorld().playEffect(p.getLocation(), Effect.EXPLOSION_HUGE, 10);
								p.getWorld().playSound(p.getLocation(), Sound.ENTITY_TNT_PRIMED, 3, 2);
							}
							
							break;
							
						case LIGHTNINGWAND:
							if(!p.hasPermission(m.getPermission("gadgetsCooldownBypass"))) {gadgetCooldown.put(p, m.getConfigValueInt("gadgetCooldown"));}
							CoinAPI.removeCoins(p.getUniqueId(), gadget.getCost());
							SBManager.updateLobbySB(p);
							
							for(int i = 0; i < 10; i++) {
								Location loc1 = p.getLocation().add(getRandom(10), 0, getRandom(10));
								Location loc2 = p.getLocation().subtract(getRandom(10), 0, getRandom(10));
								
								p.getWorld().strikeLightningEffect(loc1);
								p.getWorld().playSound(loc1, Sound.ENTITY_LIGHTNING_THUNDER, 3, 2);
								p.getWorld().spigot().playEffect(loc1, Effect.LAVA_POP, 0, 0, 0, 0, 0, 0, 100, 5);
								p.getWorld().strikeLightningEffect(loc2);
								p.getWorld().playSound(loc2, Sound.ENTITY_LIGHTNING_THUNDER, 3, 2);
								p.getWorld().spigot().playEffect(loc2, Effect.LAVA_POP, 0, 0, 0, 0, 0, 0, 100, 5);
							}
							
							break;
							
						case VULCAN:
							if(!p.hasPermission(m.getPermission("gadgetsCooldownBypass"))) {gadgetCooldown.put(p, m.getConfigValueInt("gadgetCooldown"));}
							CoinAPI.removeCoins(p.getUniqueId(), gadget.getCost());
							SBManager.updateLobbySB(p);
							vulcanLocations.put(p.getLocation(), 0);
							
							break;
							
						case TNTFOUNTAIN:
							if(!p.hasPermission(m.getPermission("gadgetsCooldownBypass"))) {gadgetCooldown.put(p, m.getConfigValueInt("gadgetCooldown"));}
							CoinAPI.removeCoins(p.getUniqueId(), gadget.getCost());
							SBManager.updateLobbySB(p);
							tntFountainLocations.put(p.getLocation(), 0);
							
							break;
						
						case KNOCKBACKAXE:
							if(!p.hasPermission(m.getPermission("gadgetsCooldownBypass"))) {gadgetCooldown.put(p, m.getConfigValueInt("gadgetCooldown"));}
							CoinAPI.removeCoins(p.getUniqueId(), gadget.getCost());
							SBManager.updateLobbySB(p);

							Item axe = p.getWorld().dropItem(p.getEyeLocation(), ItemCreator.crItem(Material.IRON_AXE, 1, " "));
							axe.setVelocity(p.getLocation().getDirection().multiply(3D).normalize());
							axes.put(axe, p);
							
							break;
						
						case FIRENAME:
							p.playSound(p.getLocation(), Sound.BLOCK_NOTE_PLING, 3, 2);
							CoinAPI.removeCoins(p.getUniqueId(), gadget.getCost());
							SBManager.updateLobbySB(p);
							if(!p.hasPermission(m.getPermission("gadgetsCooldownBypass"))) {gadgetCooldown.put(p, m.getConfigValueInt("gadgetCooldown"));}
							
							TextEffect effect = new TextEffect(em);
							effect.text = p.getDisplayName().replace("�7", "").replace("�8", "").replace("�4", "").replace("�6", "").replace("�e", "").replace("�5", "");
							effect.duration = 20000;
							effect.particle = ParticleEffect.FLAME;
							effect.setLocation(p.getLocation().add(0, 5, 0));
							effect.start();
							
							break;
							
						case DISCOARMOR:
							p.playSound(p.getLocation(), Sound.BLOCK_NOTE_PLING, 3, 2);
							if(discoPlayers.containsKey(p)) {
								discoPlayers.get(p).cancel();
								discoPlayers.remove(p);
								discoTimeToPlay.remove(p);
								p.getInventory().setHelmet(null);
								p.getInventory().setChestplate(null);
								p.getInventory().setLeggings(null);
								p.getInventory().setBoots(null);
								
								List<String> lore = new ArrayList<String>();
								lore.add("�e" + gadget.getCost() + " " + ChatColor.translateAlternateColorCodes('&', m.getMessage("costPerSecond").replace("[coins]", m.coinName)));
								p.getInventory().setItem(7, ItemCreator.crItemLeatherArmor(gadget.getMat(), 1, gadget.getDisplayname(), gadget.isEnch(), Color.ORANGE, lore));
								return;
								
							} else {
								if(BootPlayer.equippedBoots.containsKey(p)) {
									p.getInventory().setBoots(null);
									BootPlayer.equippedBoots.remove(p);
								}
								discoTimeToPlay.put(p, 0);
								discoPlayers.put(p, new BukkitRunnable() {
									
									@Override
									public void run() {
										if(CoinAPI.getCoins(p.getUniqueId()) >= gadget.getCost()) {
											discoTimeToPlay.replace(p, discoTimeToPlay.get(p) + 5);
											
											if(discoTimeToPlay.get(p) >= 20) {
												CoinAPI.removeCoins(p.getUniqueId(), gadget.getCost());
												SBManager.updateLobbySB(p);
												discoTimeToPlay.replace(p, 0);
											}
											
											p.getInventory().setHelmet(ItemCreator.crItemLeatherArmor(Material.LEATHER_HELMET, 1, " ", false, 
													Color.fromBGR(getRandom(255) + 1, getRandom(255) + 1, getRandom(255) + 1)));
											
											p.getInventory().setChestplate(ItemCreator.crItemLeatherArmor(Material.LEATHER_CHESTPLATE, 1, " ", false, 
													Color.fromBGR(getRandom(255) + 1, getRandom(255) + 1, getRandom(255) + 1)));
											
											p.getInventory().setLeggings(ItemCreator.crItemLeatherArmor(Material.LEATHER_LEGGINGS, 1, " ", false, 
													Color.fromBGR(getRandom(255) + 1, getRandom(255) + 1, getRandom(255) + 1)));
											
											p.getInventory().setBoots(ItemCreator.crItemLeatherArmor(Material.LEATHER_BOOTS, 1, " ", false, 
													Color.fromBGR(getRandom(255) + 1, getRandom(255) + 1, getRandom(255) + 1)));	
											
										} else {
											String msg = m.getMessage("notEnoughtCoins").replace("[prefix]", m.prefix).replace("[coinname]", m.coinName);
											p.sendMessage(ChatColor.translateAlternateColorCodes('&', msg));

											discoPlayers.get(p).cancel();
											discoPlayers.remove(p);
											discoTimeToPlay.remove(p);
											p.getInventory().setHelmet(null);
											p.getInventory().setChestplate(null);
											p.getInventory().setLeggings(null);
											p.getInventory().setBoots(null);
											
											List<String> lore = new ArrayList<String>();
											lore.add("�e" + gadget.getCost() + " " + ChatColor.translateAlternateColorCodes('&', 
													m.getMessage("costPerSecond").replace("[coins]", m.coinName)));
											p.getInventory().setItem(7, ItemCreator.crItemLeatherArmor(gadget.getMat(), 1, gadget.getDisplayname(), gadget.isEnch(), Color.ORANGE, lore));
										}
									}
								});
								discoPlayers.get(p).runTaskTimer(m, 0, 5);
								
								p.getInventory().getItem(7).addUnsafeEnchantment(Enchantment.DAMAGE_ALL, 1);
								p.getInventory().getItem(7).getItemMeta().addItemFlags(ItemFlag.HIDE_ENCHANTS);
								
								
							}
							break;
							
						case SLIME:
							if(!p.hasPermission(m.getPermission("gadgetsCooldownBypass"))) {gadgetCooldown.put(p, m.getConfigValueInt("gadgetCooldown"));}
							CoinAPI.removeCoins(p.getUniqueId(), gadget.getCost());
							SBManager.updateLobbySB(p);

							Item slime = p.getWorld().dropItem(p.getEyeLocation(), ItemCreator.crItem(Material.SLIME_BALL, 1, " "));
							slime.setVelocity(p.getLocation().getDirection().multiply(3D).normalize());
							slimes.put(slime, p);
							
							break;
							
						default:
							break;
						}
					} else {
						String msg = m.getMessage("notEnoughtCoins").replace("[prefix]", m.prefix).replace("[coinname]", m.coinName);
						p.sendMessage(ChatColor.translateAlternateColorCodes('&', msg));
					}
				}
			}
		}
	}
	
	public static int getRandom(int max) {
		Random r = new Random();
		return r.nextInt(max);
	}
	
	public static void startGadgetScheduler() {
		Bukkit.getScheduler().scheduleSyncRepeatingTask(m, new Runnable() {
			
			@SuppressWarnings("deprecation")
			@Override
			public void run() {
				for(Player p : Bukkit.getOnlinePlayers()) {
					if(smashingPlayers.contains(p)) {
						if(p.isOnGround()) {
							for(int i = 0; i < 5; i++) {
								p.getWorld().playEffect(p.getLocation(), Effect.EXPLOSION_HUGE, 1);
								p.getWorld().playSound(p.getLocation(), Sound.BLOCK_ANVIL_LAND, 2, 3);
							}
							for(Entity target : p.getNearbyEntities(5, 5, 5)) {
								if(p != target) {
									double Ax = p.getLocation().getX();
									double Ay = p.getLocation().getY();
									double Az = p.getLocation().getZ();
					
									double Bx = target.getLocation().getX();
									double By = target.getLocation().getY();
									double Bz = target.getLocation().getZ();
					
									double x = Bx - Ax;
									double y = By - Ay;
									double z = Bz - Az;
					
									target.getWorld().playEffect(target.getLocation(), Effect.EXPLOSION_HUGE, 5);
									Vector v = new Vector(x, y, z).normalize().multiply(3D).setY(0.5D);
									target.setVelocity(v);
								}
							}
							smashingPlayers.remove(p);
						} else {
							p.getWorld().spigot().playEffect(p.getLocation(), Effect.LAVA_POP, 0, 0, 0, (float) 0.5, 0, 0, 20, 5);
							p.getWorld().playSound(p.getLocation(), Sound.BLOCK_ANVIL_FALL, 2, 3);
						}
					}
				}
				
				// vulcan
				ArrayList<Location> remLocs = new ArrayList<Location>();
				for(Location loc : vulcanLocations.keySet()) {
					loc.getWorld().spigot().playEffect(loc, Effect.LAVA_POP, 0, 0, 0, 0, 0, 0, 20, 20);
					vulcanLocations.replace(loc, vulcanLocations.get(loc) + 1);
					
					if(vulcanLocations.get(loc) >= 100) {
						remLocs.add(loc);
					}
				}
				for(int i = 0; i < remLocs.size(); i++) {
					vulcanLocations.remove(remLocs.get(i));
				}
				remLocs.clear();
				
				// tnt fountain
				ArrayList<Location> remTNTLocs = new ArrayList<Location>();
				for(Location loc : tntFountainLocations.keySet()) {
					List<Integer> times = new ArrayList<Integer>();
					
					times.add(0);
					times.add(5);
					times.add(10);
					times.add(15);
					times.add(20);
					times.add(25);
					times.add(30);
					times.add(35);
					times.add(40);
					times.add(45);
					times.add(50);
					times.add(55);
					times.add(60);
					times.add(65);
					times.add(70);
					times.add(75);
					times.add(80);
					times.add(85);
					times.add(90);
					times.add(95);
					times.add(100);
					
					if(times.contains(tntFountainLocations.get(loc))) {
						TNTPrimed tnt = loc.getWorld().spawn(loc, TNTPrimed.class);
						tnt.setVelocity(new Vector(getRandom(2) - 0.5, 1, getRandom(2) - 0.5));
						tnt.setFuseTicks(20);
						
						loc.getWorld().spigot().playEffect(loc, Effect.LAVA_POP, 0, 0, 0, 0, 0, 0, 20, 20);
						
						primedTNT.add(tnt);
					}

					tntFountainLocations.replace(loc, tntFountainLocations.get(loc) + 1);
					
					if(tntFountainLocations.get(loc) >= 100) {
						remTNTLocs.add(loc);
					}
				}
				for(int i = 0; i < remTNTLocs.size(); i++) {
					tntFountainLocations.remove(remTNTLocs.get(i));
				}
				remTNTLocs.clear();
			
				
				//knockback axe
				for(int i = 0; i < axes.size(); i++) {
					Item item = (Item) axes.keySet().toArray()[i];
					
					for(Entity target : item.getNearbyEntities(0.2, 0.2, 0.2)) {
						if(item != target && axes.get(item) != target) {
							double Ax = item.getLocation().getX();
							double Ay = item.getLocation().getY();
							double Az = item.getLocation().getZ();
			
							double Bx = target.getLocation().getX();
							double By = target.getLocation().getY();
							double Bz = target.getLocation().getZ();
			
							double x = Bx - Ax;
							double y = By - Ay;
							double z = Bz - Az;
							
							Vector v = new Vector(x, y, z).normalize().multiply(3D).setY(0.5D);
							target.setVelocity(v);
						}
					}
					
					if(item.isOnGround()) {
						axes.remove(item);
						item.remove();
					}
				}
				
				// slime
				for(int i = 0; i < slimes.size(); i++) {
					Item item = (Item) slimes.keySet().toArray()[i];
					
					for(Entity target : item.getNearbyEntities(0.5, 0.5, 0.5)) {
						if(item != target && slimes.get(item) != target) {
							if(target instanceof Player) {
								((Player) target).addPotionEffect(new PotionEffect(PotionEffectType.CONFUSION, 250, 20, false, false));
								((Player) target).addPotionEffect(new PotionEffect(PotionEffectType.SLOW, 250, 2, false, false));
							}
						}
					}
					
					if(item.isOnGround()) {
						slimes.remove(item);
						item.remove();
					}
				}
				
			}
		}, 1, 1);	
	}
	
	@EventHandler
	public void onExplode(EntityExplodeEvent e) {
		if(e.getEntityType() == EntityType.PRIMED_TNT) {
			TNTPrimed tnt = (TNTPrimed) e.getEntity();
			
			int randInt = getRandom(2);
			Color c1 = null;
			Color c2 = null;
			if(randInt == 0) {c1 = Color.RED; c2 = Color.WHITE;} else {c1 = Color.WHITE; c2 = Color.RED;}
			
			
			Firework fw = tnt.getLocation().getWorld().spawn(tnt.getLocation(), Firework.class);
			FireworkEffect effect = FireworkEffect.builder().withColor(c1).flicker(true).trail(true).withFade(c2).with(Type.BALL_LARGE).build();
			FireworkMeta meta = fw.getFireworkMeta();
			meta.addEffect(effect);
			meta.setPower(0);
			fw.setFireworkMeta(meta);
		}
	}
	
}
