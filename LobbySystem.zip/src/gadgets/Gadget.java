package gadgets;

import lobbySystem.Main;

import org.bukkit.ChatColor;
import org.bukkit.Material;

public enum Gadget {

	FIREWORK(0, Material.FIREWORK, 20, false, ChatColor.translateAlternateColorCodes('&', Main.getMain().getMessage("firework")), true),
	ENDERPEARL(1, Material.ENDER_PEARL, 50, false, ChatColor.translateAlternateColorCodes('&', Main.getMain().getMessage("magicEnderpearl")), true),
	SMASH(2, Material.ANVIL, 100, false, ChatColor.translateAlternateColorCodes('&', Main.getMain().getMessage("smash")), true),
	STAR(3, Material.TOTEM, 10, false, ChatColor.translateAlternateColorCodes('&', Main.getMain().getMessage("firestar")), true),
	ROCKET(4, Material.FIREWORK, 50, false, ChatColor.translateAlternateColorCodes('&', Main.getMain().getMessage("rocket")), true),
	LIGHTNINGWAND(5, Material.STICK, 20, false, ChatColor.translateAlternateColorCodes('&', Main.getMain().getMessage("lightningwand")), true),
	VULCAN(6, Material.LAVA_BUCKET, 70, false, ChatColor.translateAlternateColorCodes('&', Main.getMain().getMessage("vulcan")), true),
	TNTFOUNTAIN(7, Material.TNT, 50, false, ChatColor.translateAlternateColorCodes('&', Main.getMain().getMessage("tntfountain")), true),
	KNOCKBACKAXE(8, Material.IRON_AXE, 40, false, ChatColor.translateAlternateColorCodes('&', Main.getMain().getMessage("knockbackaxe")), true),
	
	FIRENAME(9, Material.SIGN, 200, true, ChatColor.translateAlternateColorCodes('&', Main.getMain().getMessage("firename")), true),
	DISCOARMOR(10, Material.LEATHER_CHESTPLATE, 2, true, ChatColor.translateAlternateColorCodes('&', Main.getMain().getMessage("discoarmor")), false),
	SLIME(11, Material.SLIME_BALL, 25, true, ChatColor.translateAlternateColorCodes('&', Main.getMain().getMessage("slime")), true);
	
	private int slot;
	private Material mat;
	private int cost;
	private boolean permission;
	private String displayname;
	private boolean ench;
	
	private Gadget(int slot, Material mat, int cost, boolean permission, String displayname, boolean ench) {
		this.slot = slot;
		this.mat = mat;
		this.cost = cost;
		this.permission = permission;
		this.displayname = displayname;
		this.ench = ench;
	}
	
	public int getSlot() {
		return slot;
	}
	
	public Material getMat() {
		return mat;
	}
	public int getCost() {
		return cost;
	}
	public boolean isPermission() {
		return permission;
	}
	
	public String getDisplayname() {
		return displayname;
	}
	
	public boolean isEnch() {
		return ench;
	}

}
