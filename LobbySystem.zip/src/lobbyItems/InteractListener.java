package lobbyItems;

import lobby.BuildModeManager;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;

public class InteractListener implements Listener {

	@EventHandler
	public void onInteract(PlayerInteractEvent e) {
		Player p = e.getPlayer();
		
		if(e.getAction() == Action.RIGHT_CLICK_AIR || e.getAction() == Action.RIGHT_CLICK_BLOCK) {
			if(BuildModeManager.buildModeP.contains(e.getPlayer())) {
				return;
			}
			// this cancells also the interaction with chest or buttons
			e.setCancelled(true);
			
			// there is an exeption when you click by hand on the air or on blocks
			if(e.getItem() != null) {
				switch (e.getItem().getType()) {
				
				// normal items
				case COMPASS:
					CompassListener.openCompassInv(p);
					break;
					
				case BLAZE_ROD:
					HidePlayerItem.itemClicked(p);
					break;
					
				case NETHER_STAR:
					LobbyChangerListener.openLobbyInv(p);
					break;
					
				case CHEST:
					LobbyChestListener.openChestInv(p);
					break;
					
//				case SKULL_ITEM:
//					
//					break;
					
				// items with permissions
				case EYE_OF_ENDER:
					PlayerShieldListener.shieldClicked(p);
					break;
					
				case NAME_TAG:
					NickListener.nameTagClick(p);
				break;
				
				default:
					break;
				}
			}
		}
	}
	
}
