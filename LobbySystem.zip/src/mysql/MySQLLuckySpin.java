package mysql;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.UUID;

public class MySQLLuckySpin {

	public static void createTable() {
		try {
			PreparedStatement ps = MySQL.getConnection().prepareStatement("CREATE TABLE IF NOT EXISTS playerluckyspin (UUID VARCHAR(100), date DATE)");
			ps.executeUpdate();
		} catch(SQLException e) {e.printStackTrace();}
	}
	
	public static void addPlayerInList(UUID uuid, Date date) {
		if(!playerExist(uuid)) {
			try {
				PreparedStatement ps = MySQL.getConnection().prepareStatement("INSERT INTO playerluckyspin (UUID,date) VALUES (?,?)");
				ps.setString(1, uuid.toString());
				ps.setDate(2, date);
				ps.executeUpdate();
			} catch (SQLException e) {e.printStackTrace();}
		}
	}
	
	public static boolean playerExist(UUID uuid) {
		try {
			PreparedStatement ps = MySQL.getConnection().prepareStatement("SELECT date FROM playerluckyspin WHERE UUID = ?");
			ps.setString(1, uuid.toString());
			ResultSet rs = ps.executeQuery();
			return rs.next();
		} catch (SQLException e) {e.printStackTrace();}
		return false;
	}
	
	public static Date getNextSpinTime(UUID uuid) {
		if(playerExist(uuid)) {
			try {
				PreparedStatement ps = MySQL.getConnection().prepareStatement("SELECT date FROM playerluckyspin WHERE UUID = ?");
				ps.setString(1, uuid.toString());
				ResultSet rs = ps.executeQuery();
				while(rs.next()) {
					return rs.getDate("date");
				}
			} catch (SQLException e) {e.printStackTrace();}
		}
		return null;
	}
	
	public static void setNextSpinTime(UUID uuid) {
		if(playerExist(uuid)) {
			LocalDate ldate = LocalDate.now().plusDays(1);
			Date date = Date.valueOf(ldate);
				
			try {
				PreparedStatement ps = MySQL.getConnection().prepareStatement("UPDATE playerluckyspin SET date = ? WHERE UUID = ?");
				ps.setDate(1, date);
				ps.setString(2, uuid.toString());
				ps.executeUpdate();
			} catch (SQLException e) {e.printStackTrace();}
		}
	}
	
}
