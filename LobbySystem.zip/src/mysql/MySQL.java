package mysql;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import lobbySystem.Main;

import org.bukkit.Bukkit;

public class MySQL {
	
	public static Connection con;
	private static Main m = Main.getMain();
	
	public static void connect(String host, String port, String database, String username, String password) {
		if(!(isConnectet())) {
			try {
				con = DriverManager.getConnection("jdbc:mysql://" + host + ":" + port + "/" + database, username, password);
				Bukkit.getConsoleSender().sendMessage(m.prefix + " �a[MySQL] connected");
			} catch (SQLException e) {
				Bukkit.getConsoleSender().sendMessage(m.prefix + " �4[MySQL] Connection failed");
			}
		}
	}
	
	public static void disconect() {
		if(isConnectet()) {
			try {
				con.close();
				Bukkit.getConsoleSender().sendMessage(m.prefix + " �c[MySQL] Connection closed!");
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public static boolean isConnectet() {
		return (con == null ? false : true);
		
	}
	
	public static Connection getConnection() {
		return con;
	}

}
