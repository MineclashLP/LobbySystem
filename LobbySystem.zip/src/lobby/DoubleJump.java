package lobby;

import lobbySystem.Main;

import org.bukkit.Effect;
import org.bukkit.GameMode;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerToggleFlightEvent;
import org.bukkit.util.Vector;

public class DoubleJump implements Listener {

	@EventHandler
	public void onMove(PlayerMoveEvent e) {
		if(!e.getPlayer().isOnGround())
			return;
		if(e.getPlayer().hasPermission(Main.getMain().getPermission("doubleJump"))) {
			e.getPlayer().setAllowFlight(true);	
		}
	}
	
	@EventHandler
	public void onDoubleJump(PlayerToggleFlightEvent e) {
		Player p = e.getPlayer();
		
		if(e.isFlying() && p.getGameMode() != GameMode.CREATIVE) {
			if(p.hasPermission(Main.getMain().getPermission("doubleJump"))) {
				e.setCancelled(true);
				p.setAllowFlight(false);
				p.setFlying(false);
				
				Vector v = p.getLocation().getDirection().multiply(7D).setY(4D).normalize();;
				p.setVelocity(v);
				p.getWorld().playEffect(p.getLocation(), Effect.ENDER_SIGNAL, 3);
				p.playSound(p.getLocation(), Sound.ENTITY_ENDERDRAGON_FLAP, 3, 2);
			}
		}
 	}


	

}
