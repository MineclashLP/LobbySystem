package lobby;

import java.io.File;
import java.util.ArrayList;

import lobbySystem.Main;
import net.minecraft.server.v1_11_R1.IChatBaseComponent;
import net.minecraft.server.v1_11_R1.IChatBaseComponent.ChatSerializer;
import net.minecraft.server.v1_11_R1.PacketPlayOutChat;
import net.minecraft.server.v1_11_R1.PlayerConnection;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.craftbukkit.v1_11_R1.entity.CraftPlayer;
import org.bukkit.entity.Player;

public class BroadcastManager {

	public static ArrayList<String> actionBarMsg = new ArrayList<String>();
	private static int currentActionBarMsgIndex = 0;
	private static int time;
	
	public static void startMSGBoradcast() {
		Bukkit.getScheduler().scheduleSyncRepeatingTask(Main.getMain(), new Runnable() {
			
			@Override
			public void run() {
				for(Player all : Bukkit.getOnlinePlayers()) {
					// actionbar
					if(!(actionBarMsg.size() > 0)) {
						addMsgInList();
					}
					if(time <= Main.getMain().getConfigValueInt("actionBarMsgInterval")) {
						String msg = actionBarMsg.get(currentActionBarMsgIndex);
						PlayerConnection con = ((CraftPlayer)all).getHandle().playerConnection;
						IChatBaseComponent chat = ChatSerializer.a("{\"text\": \"" + msg + "\"}");
						PacketPlayOutChat packet = new PacketPlayOutChat(chat, (byte) 2);
						con.sendPacket(packet);
						time += 40;
						
					} else {
						if((actionBarMsg.size() - 1) <= currentActionBarMsgIndex) {currentActionBarMsgIndex = 0;} else {currentActionBarMsgIndex++;}
						time = 0;
					}
				}
			}
			
		}, 0, 40);
		
		
		
	}
	
	private static void addMsgInList() {
		int index = 1;
		boolean next = true;
		File f = new File(Main.getMain().getDataFolder() + File.separator + "actionbar.yml");
		FileConfiguration cfg = YamlConfiguration.loadConfiguration(f);
		
		while(next) {
			if(cfg.contains("msg" + index)) {
				String cfgMsg = cfg.getString("msg" + index);
				actionBarMsg.add(ChatColor.translateAlternateColorCodes('&', cfgMsg));
				index++;
			} else {
				next = false;
				return;
			}
		}
	}
	
}
