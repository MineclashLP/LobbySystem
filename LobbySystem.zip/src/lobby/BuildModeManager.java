package lobby;

import java.util.ArrayList;

import listener.JoinListener;

import org.bukkit.GameMode;
import org.bukkit.entity.Player;

public class BuildModeManager {

	public static ArrayList<Player> buildModeP = new ArrayList<Player>();
	
	public static void setPlayerInBuildMode(Player p) {
		if(!buildModeP.contains(p)) {
			buildModeP.add(p);
			p.getInventory().clear();
			p.setGameMode(GameMode.CREATIVE);
		}
	}
	
	public static void removeBuildModeP(Player p) {
		if(buildModeP.contains(p)) {
			buildModeP.remove(p);
			p.getInventory().clear();
			p.getInventory().setArmorContents(null);
			JoinListener.giveItems(p);
			p.setAllowFlight(false);
			p.setFoodLevel(20);
			p.setGameMode(GameMode.SURVIVAL);
		}
	}
}
