package commands;

import lobbySystem.Main;
import mysql.MySQLNickList;

import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

public class RemoveNickname_CMD implements CommandExecutor {

	private Main m = Main.getMain();
	
	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		if(sender.hasPermission(m.getPermission("removeNicknameUse"))) {
			if(args.length == 1) {
				String name = args[0];
				
				if(MySQLNickList.nameExist(name)) {
					
					MySQLNickList.removeName(name);
					
					String msg = m.getMessage("removeNicknameExec").replace("[prefix]", m.prefix).replace("[name]", name);
					sender.sendMessage(ChatColor.translateAlternateColorCodes('&', msg));
					
				} else {
					// the name already exists
					String msg = m.getMessage("nameNotExistErr").replace("[prefix]", m.prefix).replace("[name]", name);
					sender.sendMessage(ChatColor.translateAlternateColorCodes('&', msg));
				}
			} else {
				// the command is too long or too short
				sender.sendMessage(m.prefix + " �c/removenickname <name>");
			}
		} else {
			// the player hasn't the permission to run this command
			String msg = m.getMessage("noPerm").replace("[prefix]", m.prefix);
			sender.sendMessage(ChatColor.translateAlternateColorCodes('&', msg));
		}
			
		return true;
	}

}
