package commands;

import lobbySystem.Main;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import utils.SBManager;
import coinAPI.CoinAPI;

public class Coins_CMD implements CommandExecutor {

	private Main m = Main.getMain();
	
	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		if(sender.hasPermission(m.getPermission("coinsCMD"))) {
			// '/coins <ADD|REMOVE|SET> <Player> <Amount>'
			if(args.length == 3) {
				Player target = Bukkit.getPlayer(args[1]);
				
				if(target == null) {
					// the player is not online
					String notOnline = m.getMessage("playerNotOnline").replace("[prefix]", m.prefix);
					sender.sendMessage(ChatColor.translateAlternateColorCodes('&', notOnline));
					return true;
				}
				
				int amount = 0;
				try {
					amount = Integer.parseInt(args[2]);
				} catch(NumberFormatException ex) {
					// the amount argument isn't a number
					String noPerm = m.getMessage("noNumber").replace("[prefix]", m.prefix);
					sender.sendMessage(ChatColor.translateAlternateColorCodes('&', noPerm));
					return true;
				}
				
				// add
				if(args[0].equalsIgnoreCase("add")) {
					CoinAPI.addCoins(target.getUniqueId(), amount);
					
					SBManager.updateLobbySB(target);
					
					// execute msg
					String coinMsg = m.getMessage("addCoinsExec").replace("[prefix]", m.prefix).replace("[addcoins]", "" + amount).replace("[coinname]", m.coinName);
					sender.sendMessage(ChatColor.translateAlternateColorCodes('&', coinMsg));
				// remove
				} else if(args[0].equalsIgnoreCase("remove")) {
					if(CoinAPI.removeCoins(target.getUniqueId(), amount)) {
						
						SBManager.updateLobbySB(target);
						
						// execute msg
						String coinMsg = m.getMessage("removeCoinsExec").replace("[prefix]", m.prefix).replace("[removecoins]", "" + amount).replace("[coinname]", m.coinName);
						sender.sendMessage(ChatColor.translateAlternateColorCodes('&', coinMsg));
					} else {
						String msg = m.getMessage("minusCoins").replace("[prefix]", m.prefix).replace("[coinname]", m.coinName);
						sender.sendMessage(ChatColor.translateAlternateColorCodes('&', msg));
					}
				// set	
				} else if(args[0].equalsIgnoreCase("set")) {
					CoinAPI.setCoins(target.getUniqueId(), amount);
					
					SBManager.updateLobbySB(target);
					
					// execute msg
					String coinMsg = m.getMessage("setCoinsExec").replace("[prefix]", m.prefix).replace("[setcoins]", "" + amount).replace("[coinname]", m.coinName);
					sender.sendMessage(ChatColor.translateAlternateColorCodes('&', coinMsg));
				
				} else {
					// the first argument isn't correct
					sendCMDHelpPage(sender);
				}
				
				// '/coins <GET> <Player>'
			} else if (args.length == 2) {
				if(args[0].equalsIgnoreCase("get")) {
					Player target = Bukkit.getPlayer(args[1]);
						
					if(target == null) {
						// the player is not online
						String notOnline = m.getMessage("playerNotOnline").replace("[prefix]", m.prefix);
						sender.sendMessage(ChatColor.translateAlternateColorCodes('&', notOnline));
						return true;
					}
					
					int coins = CoinAPI.getCoins(target.getUniqueId());
					
					String coinMsg = m.getMessage("getCoinMsg").replace("[prefix]", m.prefix).replace("[coins]", "" + coins).replace("[coinname]", m.coinName);
					sender.sendMessage(ChatColor.translateAlternateColorCodes('&', coinMsg));
					
				} else {
					// the first argument isn't right
					sendCMDHelpPage(sender);
				}
			} else {
				// the cmd has not a args-lenght from 3
				sendCMDHelpPage(sender);
			}
		} else {
			// sender has no permission for /coins
			String noPerm = m.getMessage("noPerm").replace("[prefix]", m.prefix);
			sender.sendMessage(ChatColor.translateAlternateColorCodes('&', noPerm));
		}
		return true;
	}
	
	// Just a method for returning the help page
		private void sendCMDHelpPage(CommandSender s) {
			s.sendMessage("�4<============> �6Coin-CommandHelp �4<============>");
			s.sendMessage(" �f- �7/coins <add|remove|set> <player> <amount>");
			s.sendMessage(" �f- �7/coins <get> <player>");
		}

}
