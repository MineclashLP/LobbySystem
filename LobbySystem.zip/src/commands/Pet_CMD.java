package commands;

import lobbySystem.Main;
import mysql.MySQLPet;

import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import pets.PetInteractListener;

public class Pet_CMD implements CommandExecutor {
	
	private Main m = Main.getMain();
	
	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		if(sender instanceof Player) {
			Player p = (Player) sender;
			
			if(MySQLPet.hasAPet(p.getUniqueId())) {
				PetInteractListener.openPetOptions(p, MySQLPet.getPetType(p.getUniqueId()));
				
			} else {
				// the player has no selected pet
				String msg = m.getMessage("noSelectedPet").replace("[prefix]", m.prefix);
				p.sendMessage(ChatColor.translateAlternateColorCodes('&', msg));
			}
			
		}
		
		return true;
	}

}
