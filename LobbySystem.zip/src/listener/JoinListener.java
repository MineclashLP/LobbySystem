package listener;

import java.sql.Date;
import java.time.LocalDate;

import lobby.TabListHeaderAFooter;
import lobbyItems.NickListener;
import lobbySystem.Main;
import lukkySpins.LuckySpinManager;
import mysql.MySQLLuckySpin;
import mysql.MySQLNickList;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.potion.PotionEffect;

import rankAPI.RankAPI;
import utils.ItemCreator;
import utils.SBManager;
import utils.WarpSystem;
import coinAPI.CoinAPI;

public class JoinListener implements Listener {

	private static Main m = Main.getMain();
	
	@EventHandler
	public void onJoin(PlayerJoinEvent e) {
		Player p = e.getPlayer();
		
		// teleports the player to the spawn
		p.teleport(WarpSystem.getWarpLoc("spawn", p.getWorld()));
		
		// removes all potioneffects from the player
		for(PotionEffect effekt : p.getActivePotionEffects()) {
			p.removePotionEffect(effekt.getType());
		}
		
		// cleares the whole inventory
		p.getInventory().clear();
		p.getInventory().setArmorContents(null);
		
		// gives the player all lobby-items
		giveItems(p);
		
		p.setAllowFlight(false);
		
		MySQLLuckySpin.addPlayerInList(p.getUniqueId(), Date.valueOf(LocalDate.now()));
		LuckySpinManager.sendAvailableSpinMsg(p);
		
		p.setFoodLevel(20);
		p.setGameMode(GameMode.SURVIVAL);
		
		TabListHeaderAFooter.sendTablistHeaderAndFooter(p, m.getMessage("tabListHeader"), m.getMessage("tabListFooter"));
		
		CoinAPI.addUser(p.getUniqueId());
		MySQLNickList.addPlayer(p);
		
		// updates the sb of all players
		for(Player all : Bukkit.getOnlinePlayers()) {
			SBManager.updateLobbySB(all);
		}
		
		if(NickListener.isNicked(p)) {
			RankAPI.setRankToPlayer(p, MySQLNickList.getNamenow(p.getUniqueId()));
			
			String msg = m.getMessage("warningNicked").replace("[prefix]", m.prefix).replace("[namenow]", MySQLNickList.getNamenow(p.getUniqueId()));
			p.sendMessage(ChatColor.translateAlternateColorCodes('&', msg));
		} else {
			RankAPI.setRankToPlayer(p, p.getName());
		}
	}
	
	public static void giveItems(Player p) {
		// normal items
		p.getInventory().setItem(0, ItemCreator.crItem(Material.COMPASS, 1, ChatColor.translateAlternateColorCodes('&', m.getMessage("compass"))));
		if(WarpSystem.doesWarpExists("spawn")) {p.setCompassTarget(WarpSystem.getWarpLoc("spawn", p.getWorld()));}
		
		p.getInventory().setItem(1, ItemCreator.crItem(Material.BLAZE_ROD, 1, ChatColor.translateAlternateColorCodes('&', m.getMessage("hide_item"))));
		p.getInventory().setItem(4, ItemCreator.crItem(Material.NETHER_STAR, 1, ChatColor.translateAlternateColorCodes('&', m.getMessage("lobbychanger"))));
		p.getInventory().setItem(7, ItemCreator.crItem(Material.BARRIER, 1, ChatColor.translateAlternateColorCodes('&', m.getMessage("noGadget"))));
		p.getInventory().setItem(8, ItemCreator.crItem(Material.CHEST, 1, ChatColor.translateAlternateColorCodes('&', m.getMessage("chest"))));
//		p.getInventory().setItem(8, ItemCreator.crItemHead(1, ChatColor.translateAlternateColorCodes('&', m.getMessage("friends")), p.getName()));
		
		// items with permissions
		if(p.hasPermission(Main.getMain().getPermission("nickItem")))
			p.getInventory().setItem(5, ItemCreator.crItem(Material.NAME_TAG, 1, ChatColor.translateAlternateColorCodes('&', m.getMessage("name_tag"))));
		
		if(p.hasPermission(Main.getMain().getPermission("shieldItem")))
			p.getInventory().setItem(3, ItemCreator.crItem(Material.EYE_OF_ENDER, 1, ChatColor.translateAlternateColorCodes('&', m.getMessage("shield"))));
	}
	
}
