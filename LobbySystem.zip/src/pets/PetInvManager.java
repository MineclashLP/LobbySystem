package pets;

import java.util.HashMap;

import lobbySystem.Main;
import mysql.MySQLPet;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;

import utils.ItemCreator;
import utils.SBManager;
import coinAPI.CoinAPI;

public class PetInvManager implements Listener {

	private static Main m = Main.getMain();
	private static HashMap<Player, Pet> petBuy = new HashMap<Player, Pet>();
	
	public static void openPetsInv(Player p) {
		Inventory inv = Bukkit.createInventory(null, 9*3, "�5Pets");
		
		for(int i = 0; i < Pet.values().length; i++) {
			Pet pet = Pet.values()[i];
			if(!MySQLPet.hasPet(p.getUniqueId(), pet)) {
				if(pet.isPermission()) {
					if(p.hasPermission(m.getPermission("specialPets"))) {
						inv.setItem(pet.getSlot(), ItemCreator.crItemSpawnEgg(1, pet.getDisplayname() + " �7(�e" + pet.getCost() + " " + m.coinName + "�7)", pet.getEntType()));
						
					} else {
						inv.setItem(pet.getSlot(), ItemCreator.crItemSpawnEgg(1, pet.getDisplayname() + " �7(�e" + 
								ChatColor.translateAlternateColorCodes('&', m.getMessage("notAvailable")) + "�7)", pet.getEntType()));
					}
				} else {
					inv.setItem(pet.getSlot(), ItemCreator.crItemSpawnEgg(1, pet.getDisplayname() + " �7(�e" + pet.getCost() + " " + m.coinName + "�7)", pet.getEntType()));
				}
			} else {
				if(pet.isPermission()) {
					if(p.hasPermission(m.getPermission("specialPets"))) {
						inv.setItem(pet.getSlot(), ItemCreator.crItemSpawnEgg(1, pet.getDisplayname() + " �7(" + 
								ChatColor.translateAlternateColorCodes('&', m.getMessage("buyed")) + "�7)", pet.getEntType()));
					} else {
						inv.setItem(pet.getSlot(), ItemCreator.crItemSpawnEgg(1, pet.getDisplayname() + " �7(�e" + 
								ChatColor.translateAlternateColorCodes('&', m.getMessage("notAvailable")) + "�7)", pet.getEntType()));
					}
				} else {
					inv.setItem(pet.getSlot(), ItemCreator.crItemSpawnEgg(1, pet.getDisplayname() + " �7(" + 
							ChatColor.translateAlternateColorCodes('&', m.getMessage("buyed")) + "�7)", pet.getEntType()));
				}
			}
		}
		
		
		inv.setItem(9*2 + 4, ItemCreator.crItem(Material.BARRIER, 1, ChatColor.translateAlternateColorCodes('&', m.getMessage("removePet"))));
		
		// fills the inventory with dark glasspanes
		for(int i = 0; i < inv.getSize(); i++) {
			if(inv.getItem(i) == null) {
				inv.setItem(i, ItemCreator.crItem(Material.STAINED_GLASS_PANE, 1, (short) 7, " "));
			}
		}
		
		p.openInventory(inv);
	}
	
	
	@EventHandler
	public void onPetInvClick(InventoryClickEvent e) {
		Player p = (Player) e.getWhoClicked();
		
		if(e.getClickedInventory() != null && e.getClickedInventory().getTitle().equals("�5Pets")) {
			e.setCancelled(true);
			
			Pet pet = null;
			for(int i = 0; i < Pet.values().length; i++) {
				if(Pet.values()[i].getSlot() == e.getSlot()) {
					pet = Pet.values()[i];
				}
			}
			
			if(pet != null) {
				if(pet.isPermission()) {
					if(!p.hasPermission(m.getPermission("specialPets"))) {
						return;
					}
				}
				if(!MySQLPet.hasPet(p.getUniqueId(), pet)) {
					p.closeInventory();
					p.openInventory(getPetBuyAcceptInv(pet));
					
					if(petBuy.containsKey(p)) {
						petBuy.remove(p);
					}
					petBuy.put(p, pet);
					
				} else {
					// player activate the boots and gets the boots
					if(PetManager.playerPets.containsKey(p)) {
						PetManager.removePlayersPet(p);
					}
					PetManager.spawnPlayersPet(p, pet);
					p.closeInventory();
					
					// Here has to be the message for eqipping the boots
					String msg = m.getMessage("pSpawnPet").replace("[prefix]", m.prefix);
					p.sendMessage(ChatColor.translateAlternateColorCodes('&', msg));
				}
				
			} else {
				if(e.getCurrentItem().getType() == Material.BARRIER) {
					if(PetManager.playerPets.containsKey(p)) {
						PetManager.removePlayersPet(p);
						p.closeInventory();
						String msg = m.getMessage("petRemoved").replace("[prefix]", m.prefix);
						p.sendMessage(ChatColor.translateAlternateColorCodes('&', msg));
					}
				}
			}
		}
	}
	
	public static Inventory getPetBuyAcceptInv(Pet pet) {
		Inventory inv = Bukkit.createInventory(null, 9*1, pet.getDisplayname() + " �7- " + ChatColor.translateAlternateColorCodes('&', m.getMessage("petConfirmation")));
		
		inv.setItem(2, ItemCreator.crItem(Material.EMERALD, 1, ChatColor.translateAlternateColorCodes('&', m.getMessage("accept"))));
		inv.setItem(6, ItemCreator.crItem(Material.REDSTONE, 1, ChatColor.translateAlternateColorCodes('&', m.getMessage("abort"))));
		
		inv.setItem(4, ItemCreator.crItemSpawnEgg(1, pet.getDisplayname() + " �7(�e" + pet.getCost() + " " + m.coinName + "�7)", pet.getEntType()));
		
		// fills the inventory with dark glasspanes
		for(int i = 0; i < inv.getSize(); i++) {
			if(inv.getItem(i) == null) {
				inv.setItem(i, ItemCreator.crItem(Material.STAINED_GLASS_PANE, 1, (short) 7, " "));
			}
		}
		return inv;
	}
	
	
	@EventHandler
	public void onPetBuyInvClick(InventoryClickEvent e) {
		Player p = (Player) e.getWhoClicked();
		
		if(e.getClickedInventory() != null && e.getClickedInventory().getTitle().contains(ChatColor.translateAlternateColorCodes('&', m.getMessage("petConfirmation")))) {
			e.setCancelled(true);
			
			Pet pet = petBuy.get(p);
			
			if(e.getCurrentItem().getType() == Material.EMERALD) {
				int cost = pet.getCost();
				if(CoinAPI.getCoins(p.getUniqueId()) >= cost) {
					
					CoinAPI.removeCoins(p.getUniqueId(), cost);
					MySQLPet.addPetToPlayer(p.getUniqueId(), pet, false);
					petBuy.remove(p);
					p.closeInventory();
					SBManager.updateLobbySB(p);
					
					String msg = m.getMessage("unlockPets").replace("[prefix]", m.prefix).replace("[pet]", pet.getDisplayname());
					p.sendMessage(ChatColor.translateAlternateColorCodes('&', msg));
					
				} else {
					// player hasn't enought coins
					petBuy.remove(p);
					p.closeInventory();
					String msg = m.getMessage("notEnoughtCoins").replace("[prefix]", m.prefix).replace("[coinname]", m.coinName);
					p.sendMessage(ChatColor.translateAlternateColorCodes('&', msg));
				}
				
			} else if(e.getCurrentItem().getType() == Material.REDSTONE) {
				p.closeInventory();
				openPetsInv(p);
			}
			
		}
	}
	
}
