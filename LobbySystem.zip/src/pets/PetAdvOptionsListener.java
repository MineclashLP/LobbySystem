package pets;

import lobbySystem.Main;
import mysql.MySQLPet;

import org.bukkit.ChatColor;
import org.bukkit.DyeColor;
import org.bukkit.Material;
import org.bukkit.entity.Chicken;
import org.bukkit.entity.Cow;
import org.bukkit.entity.Creeper;
import org.bukkit.entity.Entity;
import org.bukkit.entity.MushroomCow;
import org.bukkit.entity.Ocelot;
import org.bukkit.entity.Wolf;
import org.bukkit.entity.Ocelot.Type;
import org.bukkit.entity.Pig;
import org.bukkit.entity.Player;
import org.bukkit.entity.Sheep;
import org.bukkit.entity.Skeleton;
import org.bukkit.entity.Zombie;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;

import utils.ItemCreator;

public class PetAdvOptionsListener implements Listener {

	private Main m = Main.getMain();
	
	@SuppressWarnings("deprecation")
	@EventHandler
	public void onClick(InventoryClickEvent ev) {
		Player p = (Player) ev.getWhoClicked();
		ItemStack item = ev.getCurrentItem();
		
		if(item == null) {
			return;
		}
		
		if(ev.getClickedInventory().getTitle().equals(ChatColor.translateAlternateColorCodes('&', m.getMessage("advancedPetOptions")))) {
			Pet pet = MySQLPet.getPetType(p.getUniqueId());
			Entity e = PetManager.playerPets.get(p);
			
			switch (pet) {
			case SHEEP:
				Sheep sheep = (Sheep) e;
				if(item.getType() == Material.WHEAT) {
					sheep.setBaby();
				}
				if(item.getType() == Material.SEEDS) {
					sheep.setAdult();
				}
				if(item.getType() == Material.WOOL) {
					byte woolcolor = item.getData().getData();
					if(woolcolor == 15) {
						woolcolor = 0;
					} else {
						woolcolor += 1;
					}
					sheep.setColor(DyeColor.getByWoolData(woolcolor));
				}
				if(item.getType() == Material.SHEARS) {
					if(ItemCreator.isEnch(item)) {
						sheep.setSheared(false);
					} else {
						sheep.setSheared(true);
					}
				}
				p.closeInventory();
				PetOptionsMenueManager.openPetAdvOptionsInv(p);
				break;

			case PIG:
				Pig pig = (Pig) e;
				if(item.getType() == Material.WHEAT) {
					pig.setBaby();
				}
				if(item.getType() == Material.SEEDS) {
					pig.setAdult();
				}
				if(item.getType() == Material.SADDLE) {
					if(ItemCreator.isEnch(item)) {
						pig.setSaddle(false);
					} else {
						pig.setSaddle(true);
					}
				}
				p.closeInventory();
				PetOptionsMenueManager.openPetAdvOptionsInv(p);
				break;
				
			case CHICKEN:
				Chicken chicken = (Chicken) e;
				if(item.getType() == Material.WHEAT) {
					chicken.setBaby();
				}
				if(item.getType() == Material.SEEDS) {
					chicken.setAdult();
				}
				p.closeInventory();
				PetOptionsMenueManager.openPetAdvOptionsInv(p);
				break;
				
			case COW:
				Cow cow = (Cow) e;
				if(item.getType() == Material.WHEAT) {
					cow.setBaby();
				}
				if(item.getType() == Material.SEEDS) {
					cow.setAdult();
				}
				p.closeInventory();
				PetOptionsMenueManager.openPetAdvOptionsInv(p);
				break;
				
			case OCELOT:
				Ocelot ocelot = (Ocelot) e;
				if(item.getType() == Material.WHEAT) {
					ocelot.setBaby();
				}
				if(item.getType() == Material.SEEDS) {
					ocelot.setAdult();
				}
				if(item.getType() == Material.WOOD_STAIRS) {
					if(ItemCreator.isEnch(item)) {
						ocelot.setSitting(false);
					} else {
						ocelot.setSitting(true);
					}
				}
				if(item.getType() == Material.COOKED_FISH) {
					if(ItemCreator.isEnch(item)) {
						ocelot.setTamed(false);
					} else {
						ocelot.setTamed(true);
					}
				}
				if(item.getType() == Material.INK_SACK) {
					Type catType = ocelot.getCatType();
					int id = catType.getId();
					if(id == 3) {
						catType = Type.values()[0];
					} else {
						catType = Type.values()[id + 1];
					}
					ocelot.setCatType(catType);
				}
				p.closeInventory();
				PetOptionsMenueManager.openPetAdvOptionsInv(p);
				break;
				
			case CREEPER:
				Creeper creeper = (Creeper) e;
				if(item.getType() == Material.ANVIL) {
					if(ItemCreator.isEnch(item)) {
						creeper.setPowered(false);
					} else {
						creeper.setPowered(true);
					}
				}
				p.closeInventory();
				PetOptionsMenueManager.openPetAdvOptionsInv(p);
				break;
			
			case SKELETON:
				Skeleton skeleton = (Skeleton) e;
				if(item.getType() == skeleton.getEquipment().getHelmet().getType()) {
					if(item.getType() == Material.LEATHER_HELMET) {
						skeleton.getEquipment().setHelmet(ItemCreator.crItemArmor(Material.CHAINMAIL_HELMET, 1, "", false));
					}
					if(item.getType() == Material.CHAINMAIL_HELMET) {
						skeleton.getEquipment().setHelmet(ItemCreator.crItemArmor(Material.GOLD_HELMET, 1, "", false));					
					}
					if(item.getType() == Material.GOLD_HELMET) {
						skeleton.getEquipment().setHelmet(ItemCreator.crItemArmor(Material.IRON_HELMET, 1, "", false));
					}
					if(item.getType() == Material.IRON_HELMET) {
						skeleton.getEquipment().setHelmet(ItemCreator.crItemArmor(Material.DIAMOND_HELMET, 1, "", false));
					}
					if(item.getType() == Material.DIAMOND_HELMET) {
						skeleton.getEquipment().setHelmet(ItemCreator.crItemArmor(Material.LEATHER_HELMET, 1, "", false));
					}
				}
				p.closeInventory();
				PetOptionsMenueManager.openPetAdvOptionsInv(p);
				break;
				
			case ZOMBIE:
				Zombie zombie = (Zombie) e;
				if(item.getType() == Material.WHEAT) {
					zombie.setBaby(true);
				}
				if(item.getType() == Material.SEEDS) {
					zombie.setBaby(false);
				}
				if(item.getType() == zombie.getEquipment().getHelmet().getType()) {
					if(item.getType() == Material.LEATHER_HELMET) {
						zombie.getEquipment().setHelmet(ItemCreator.crItemArmor(Material.CHAINMAIL_HELMET, 1, "", false));
					}
					if(item.getType() == Material.CHAINMAIL_HELMET) {
						zombie.getEquipment().setHelmet(ItemCreator.crItemArmor(Material.GOLD_HELMET, 1, "", false));					
					}
					if(item.getType() == Material.GOLD_HELMET) {
						zombie.getEquipment().setHelmet(ItemCreator.crItemArmor(Material.IRON_HELMET, 1, "", false));
					}
					if(item.getType() == Material.IRON_HELMET) {
						zombie.getEquipment().setHelmet(ItemCreator.crItemArmor(Material.DIAMOND_HELMET, 1, "", false));
					}
					if(item.getType() == Material.DIAMOND_HELMET) {
						zombie.getEquipment().setHelmet(ItemCreator.crItemArmor(Material.LEATHER_HELMET, 1, "", false));
					}
				}
				p.closeInventory();
				PetOptionsMenueManager.openPetAdvOptionsInv(p);
				break;
				
			case SPIDER:
				p.closeInventory();
				PetOptionsMenueManager.openPetAdvOptionsInv(p);
				break;
				
			case IRONGOLEM:
				p.closeInventory();
				PetOptionsMenueManager.openPetAdvOptionsInv(p);
				break;
				
			case WITCH:
				p.closeInventory();
				PetOptionsMenueManager.openPetAdvOptionsInv(p);
				break;
				
			case BLAZE:
				p.closeInventory();
				PetOptionsMenueManager.openPetAdvOptionsInv(p);
				break;
				
			case ENDERMAN:
				p.closeInventory();
				PetOptionsMenueManager.openPetAdvOptionsInv(p);
				break;
				
			case WOLF:
				Wolf wolf = (Wolf) e;
				if(item.getType() == Material.WHEAT) {
					wolf.setBaby();
				}
				if(item.getType() == Material.SEEDS) {
					wolf.setAdult();
				}
				if(item.getType() == Material.WOOD_STAIRS) {
					if(ItemCreator.isEnch(item)) {
						wolf.setSitting(false);
					} else {
						wolf.setSitting(true);
					}
				}
				if(item.getType() == Material.COOKED_FISH) {
					if(ItemCreator.isEnch(item)) {
						wolf.setTamed(false);
					} else {
						wolf.setTamed(true);
					}
				}
				if(item.getType() == Material.WOOL) {
					byte color = item.getData().getData();
					if(color == 15) {
						color = 0;
					} else {
						color += 1;
					}
					wolf.setCollarColor((DyeColor.getByWoolData(color)));
				}
				
				p.closeInventory();
				PetOptionsMenueManager.openPetAdvOptionsInv(p);
				break;
				
			case SNOWMAN:
				p.closeInventory();
				PetOptionsMenueManager.openPetAdvOptionsInv(p);
				break;
				
			case MUSHROOMCOW:
				MushroomCow mushroomcow = (MushroomCow) e;
				if(item.getType() == Material.WHEAT) {
					mushroomcow.setBaby();
				}
				if(item.getType() == Material.SEEDS) {
					mushroomcow.setAdult();
				}
				p.closeInventory();
				PetOptionsMenueManager.openPetAdvOptionsInv(p);
				break;
				
			case SILVERFISH:
				p.closeInventory();
				PetOptionsMenueManager.openPetAdvOptionsInv(p);
				break;
				
			case CAVESPIDER:
				p.closeInventory();
				PetOptionsMenueManager.openPetAdvOptionsInv(p);
				break;
				
			default:
				break;
			}
		}
		
	}
	
}
