package pets;

import java.lang.reflect.Field;
import java.util.HashMap;

import mysql.MySQLPet;
import net.minecraft.server.v1_11_R1.EntityCreeper;

import org.bukkit.DyeColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.craftbukkit.v1_11_R1.entity.CraftCreature;
import org.bukkit.craftbukkit.v1_11_R1.entity.CraftCreeper;
import org.bukkit.entity.Blaze;
import org.bukkit.entity.CaveSpider;
import org.bukkit.entity.Chicken;
import org.bukkit.entity.Cow;
import org.bukkit.entity.Creeper;
import org.bukkit.entity.Enderman;
import org.bukkit.entity.Entity;
import org.bukkit.entity.IronGolem;
import org.bukkit.entity.MushroomCow;
import org.bukkit.entity.Ocelot;
import org.bukkit.entity.Ocelot.Type;
import org.bukkit.entity.Pig;
import org.bukkit.entity.Player;
import org.bukkit.entity.Sheep;
import org.bukkit.entity.Silverfish;
import org.bukkit.entity.Skeleton;
import org.bukkit.entity.Snowman;
import org.bukkit.entity.Spider;
import org.bukkit.entity.Witch;
import org.bukkit.entity.Wolf;
import org.bukkit.entity.Zombie;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerMoveEvent;
import org.spigotmc.event.entity.EntityDismountEvent;

import petCustomEntity.CustomBlaze;
import petCustomEntity.CustomCaveSpider;
import petCustomEntity.CustomChicken;
import petCustomEntity.CustomCow;
import petCustomEntity.CustomCreeper;
import petCustomEntity.CustomEnderman;
import petCustomEntity.CustomIronGolem;
import petCustomEntity.CustomMushroomCow;
import petCustomEntity.CustomOcelot;
import petCustomEntity.CustomPig;
import petCustomEntity.CustomSheep;
import petCustomEntity.CustomSilverfish;
import petCustomEntity.CustomSkeleton;
import petCustomEntity.CustomSnowMan;
import petCustomEntity.CustomSpider;
import petCustomEntity.CustomWitch;
import petCustomEntity.CustomWolf;
import petCustomEntity.CustomZombie;
import utils.ItemCreator;

public class PetManager implements Listener {

	public static HashMap<Player, Entity> playerPets = new HashMap<Player, Entity>();
	
	@SuppressWarnings("deprecation")
	public static void spawnPlayersPet(Player p, Pet pet) {
		MySQLPet.setPlayersPet(p, pet);
		
		switch (pet) {
		case SHEEP:
			Sheep sheep = (Sheep) p.getWorld().spawnEntity(p.getLocation(), pet.getEntType());
			sheep.setAdult();
			sheep.setAgeLock(true);
			sheep.setTarget(null);
			sheep.setColor(DyeColor.WHITE);
			sheep.setSheared(false);
			sheep.setCustomName(MySQLPet.getPetName(p.getUniqueId()));
			sheep.setCustomNameVisible(true);
			sheep.setPassenger(null);
			playerPets.put(p, sheep);
			break;
			
		case PIG:
			Pig pig = (Pig) p.getWorld().spawnEntity(p.getLocation(), pet.getEntType());
			pig.setAdult();
			pig.setAgeLock(true);
			pig.setTarget(null);
			pig.setSaddle(false);
			pig.setCustomName(MySQLPet.getPetName(p.getUniqueId()));
			pig.setCustomNameVisible(true);
			pig.setPassenger(null);
			playerPets.put(p, pig);
			break;
			
		case CHICKEN:
			Chicken chicken = (Chicken) p.getWorld().spawnEntity(p.getLocation(), pet.getEntType());
			chicken.setAdult();
			chicken.setAgeLock(true);
			chicken.setTarget(null);
			chicken.setCustomName(MySQLPet.getPetName(p.getUniqueId()));
			chicken.setCustomNameVisible(true);
			chicken.setPassenger(null);
			playerPets.put(p, chicken);
			break;
			
		case COW:
			Cow cow = (Cow) p.getWorld().spawnEntity(p.getLocation(), pet.getEntType());
			cow.setAdult();
			cow.setAgeLock(true);
			cow.setTarget(null);
			cow.setCustomName(MySQLPet.getPetName(p.getUniqueId()));
			cow.setCustomNameVisible(true);
			cow.setPassenger(null);
			playerPets.put(p, cow);
			break;	
			
		case OCELOT:
			Ocelot ocelot = (Ocelot) p.getWorld().spawnEntity(p.getLocation(), pet.getEntType());
			ocelot.setAdult();
			ocelot.setAgeLock(true);
			ocelot.setTarget(null);
			ocelot.setSitting(false);
			ocelot.setTamed(true);
			ocelot.setCatType(Type.WILD_OCELOT);
//			ocelot.setOwner(p);
			ocelot.setCustomName(MySQLPet.getPetName(p.getUniqueId()));
			ocelot.setCustomNameVisible(true);
			ocelot.setPassenger(null);
			playerPets.put(p, ocelot);
			break;	
			
		case CREEPER:
			Creeper creeper = (Creeper) p.getWorld().spawnEntity(p.getLocation(), pet.getEntType());
			creeper.setTarget(null);
			creeper.setPowered(false);
			creeper.setCustomName(MySQLPet.getPetName(p.getUniqueId()));
			creeper.setCustomNameVisible(true);
			creeper.setPassenger(null);
			setDontExplode(creeper);
			playerPets.put(p, creeper);
			break;	
			
		case SKELETON:
			Skeleton skeleton = (Skeleton) p.getWorld().spawnEntity(p.getLocation(), pet.getEntType());
			skeleton.setTarget(null);
			skeleton.setCustomName(MySQLPet.getPetName(p.getUniqueId()));
			skeleton.setCustomNameVisible(true);
			skeleton.setPassenger(null);
			skeleton.getEquipment().setHelmet(ItemCreator.crItemArmor(Material.IRON_HELMET, 1, "", false));
			playerPets.put(p, skeleton);
			break;
			
		case ZOMBIE:
			Zombie zombie = (Zombie) p.getWorld().spawnEntity(p.getLocation(), pet.getEntType());
			zombie.setTarget(null);
			zombie.setBaby(false);
			zombie.setCustomName(MySQLPet.getPetName(p.getUniqueId()));
			zombie.setCustomNameVisible(true);
			zombie.setPassenger(null);
			zombie.getEquipment().setHelmet(ItemCreator.crItemArmor(Material.IRON_HELMET, 1, "", false));
			playerPets.put(p, zombie);
			break;
			
		case SPIDER:
			Spider spider = (Spider) p.getWorld().spawnEntity(p.getLocation(), pet.getEntType());
			spider.setTarget(null);
			spider.setCustomName(MySQLPet.getPetName(p.getUniqueId()));
			spider.setCustomNameVisible(true);
			spider.setPassenger(null);
			playerPets.put(p, spider);
			break;
			
		case IRONGOLEM:
			IronGolem irongolem = (IronGolem) p.getWorld().spawnEntity(p.getLocation(), pet.getEntType());
			irongolem.setTarget(null);
			irongolem.setCustomName(MySQLPet.getPetName(p.getUniqueId()));
			irongolem.setCustomNameVisible(true);
			irongolem.setPassenger(null);
			playerPets.put(p, irongolem);
			break;
			
		case WITCH:
			Witch witch = (Witch) p.getWorld().spawnEntity(p.getLocation(), pet.getEntType());
			witch.setTarget(null);
			witch.setCustomName(MySQLPet.getPetName(p.getUniqueId()));
			witch.setCustomNameVisible(true);
			witch.setPassenger(null);
			playerPets.put(p, witch);
			break;
			
		case BLAZE:
			Blaze blaze = (Blaze) p.getWorld().spawnEntity(p.getLocation(), pet.getEntType());
			blaze.setTarget(null);
			blaze.setCustomName(MySQLPet.getPetName(p.getUniqueId()));
			blaze.setCustomNameVisible(true);
			blaze.setPassenger(null);
			playerPets.put(p, blaze);
			break;
			
		case ENDERMAN:
			Enderman enderman = (Enderman) p.getWorld().spawnEntity(p.getLocation(), pet.getEntType());
			enderman.setTarget(null);
			enderman.setCustomName(MySQLPet.getPetName(p.getUniqueId()));
			enderman.setCustomNameVisible(true);
			enderman.setPassenger(null);
			playerPets.put(p, enderman);
			break;	
			
		case WOLF:
			Wolf wolf = (Wolf) p.getWorld().spawnEntity(p.getLocation(), pet.getEntType());
			wolf.setAgeLock(true);
			wolf.setTarget(null);
			wolf.setAngry(false);
			wolf.setSitting(false);
			wolf.setTamed(true);
			wolf.setCollarColor(DyeColor.RED);
			wolf.setAdult();
			wolf.setCustomName(MySQLPet.getPetName(p.getUniqueId()));
			wolf.setCustomNameVisible(true);
			wolf.setPassenger(null);
			playerPets.put(p, wolf);
			break;	
			
		case SNOWMAN:
			Snowman snowman = (Snowman) p.getWorld().spawnEntity(p.getLocation(), pet.getEntType());
			snowman.setTarget(null);
			snowman.setCustomName(MySQLPet.getPetName(p.getUniqueId()));
			snowman.setCustomNameVisible(true);
			snowman.setPassenger(null);
			playerPets.put(p, snowman);
			break;	
			
		case MUSHROOMCOW:
			MushroomCow mushroomcow = (MushroomCow) p.getWorld().spawnEntity(p.getLocation(), pet.getEntType());
			mushroomcow.setTarget(null);
			mushroomcow.setAdult();
			mushroomcow.setCustomName(MySQLPet.getPetName(p.getUniqueId()));
			mushroomcow.setCustomNameVisible(true);
			mushroomcow.setPassenger(null);
			playerPets.put(p, mushroomcow);
			break;	
			
		case SILVERFISH:
			Silverfish silverfish = (Silverfish) p.getWorld().spawnEntity(p.getLocation(), pet.getEntType());
			silverfish.setTarget(null);
			silverfish.setCustomName(MySQLPet.getPetName(p.getUniqueId()));
			silverfish.setCustomNameVisible(true);
			silverfish.setPassenger(null);
			playerPets.put(p, silverfish);
			break;	
			
		case CAVESPIDER:
			CaveSpider cavespider = (CaveSpider) p.getWorld().spawnEntity(p.getLocation(), pet.getEntType());
			cavespider.setTarget(null);
			cavespider.setCustomName(MySQLPet.getPetName(p.getUniqueId()));
			cavespider.setCustomNameVisible(true);
			cavespider.setPassenger(null);
			playerPets.put(p, cavespider);
			break;	
		
		default:
			break;
		}
		
	}
	
	@SuppressWarnings("deprecation")
	public static void ridePet(Player p) {
		if(playerPets.containsKey(p)) {
			Entity e = playerPets.get(p);
			e.remove();
			Pet pet = MySQLPet.getPetType(p.getUniqueId());
			playerPets.remove(p);
			
			switch (pet) {
			case SHEEP:
				Sheep oldSheep = (Sheep) e;
				Sheep sheep = CustomSheep.spawn(p.getLocation());
				if(oldSheep.isAdult()) {sheep.setAdult();} else {sheep.setBaby();}
				sheep.setAgeLock(true);
				sheep.setTarget(null);
				sheep.setColor(oldSheep.getColor());
				sheep.setSheared(oldSheep.isSheared());
				sheep.setCustomName(MySQLPet.getPetName(p.getUniqueId()));
				sheep.setCustomNameVisible(true);
				sheep.setPassenger(p);
				playerPets.put(p, sheep);
				break;
				
			case PIG:
				Pig oldPig = (Pig) e;
				Pig pig = CustomPig.spawn(p.getLocation());
				if(oldPig.isAdult()) {pig.setAdult();} else {pig.setBaby();}
				pig.setAgeLock(true);
				pig.setTarget(null);
				pig.setSaddle(oldPig.hasSaddle());
				pig.setCustomName(MySQLPet.getPetName(p.getUniqueId()));
				pig.setCustomNameVisible(true);
				pig.setPassenger(p);
				playerPets.put(p, pig);
				break;
				
			case CHICKEN:
				Chicken oldChicken = (Chicken) e;
				Chicken chicken = CustomChicken.spawn(p.getLocation());
				if(oldChicken.isAdult()) {chicken.setAdult();} else {chicken.setBaby();}
				chicken.setAgeLock(true);
				chicken.setTarget(null);
				chicken.setCustomName(MySQLPet.getPetName(p.getUniqueId()));
				chicken.setCustomNameVisible(true);
				chicken.setPassenger(p);
				playerPets.put(p, chicken);
				break;
				
			case COW:
				Cow oldCow = (Cow) e;
				Cow cow = CustomCow.spawn(p.getLocation());
				if(oldCow.isAdult()) {cow.setAdult();} else {cow.setBaby();}
				cow.setAgeLock(true);
				cow.setTarget(null);
				cow.setCustomName(MySQLPet.getPetName(p.getUniqueId()));
				cow.setCustomNameVisible(true);
				cow.setPassenger(p);
				playerPets.put(p, cow);
				break;	
				
			case OCELOT:
				Ocelot oldOcelot = (Ocelot) e;
				Ocelot ocelot = CustomOcelot.spawn(p.getLocation());
				if(oldOcelot.isAdult()) {ocelot.setAdult();} else {ocelot.setBaby();}
				ocelot.setAgeLock(true);
				ocelot.setTarget(null);
				ocelot.setSitting(oldOcelot.isSitting());
				ocelot.setTamed(oldOcelot.isTamed());
				ocelot.setCatType(oldOcelot.getCatType());
//				ocelot.setOwner(p);
				ocelot.setCustomName(MySQLPet.getPetName(p.getUniqueId()));
				ocelot.setCustomNameVisible(true);
				ocelot.setPassenger(p);
				playerPets.put(p, ocelot);
				break;	
				
			case CREEPER:
				Creeper oldCreeper = (Creeper) e;
				Creeper creeper = CustomCreeper.spawn(p.getLocation());
				creeper.setTarget(null);
				creeper.setPowered(oldCreeper.isPowered());
				creeper.setCustomName(MySQLPet.getPetName(p.getUniqueId()));
				creeper.setCustomNameVisible(true);
				creeper.setPassenger(p);
				setDontExplode(creeper);
				playerPets.put(p, creeper);
				break;	
				
			case SKELETON:
				Skeleton oldSkeleton = (Skeleton) e;
				Skeleton skeleton = CustomSkeleton.spawn(p.getLocation());
				skeleton.setTarget(null);
				skeleton.setCustomName(MySQLPet.getPetName(p.getUniqueId()));
				skeleton.setCustomNameVisible(true);
				skeleton.setPassenger(p);
				skeleton.getEquipment().setHelmet(oldSkeleton.getEquipment().getHelmet());
				playerPets.put(p, skeleton);
				break;
				
			case ZOMBIE:
				Zombie oldZombie = (Zombie) e;
				Zombie zombie = CustomZombie.spawn(p.getLocation());
				zombie.setTarget(null);
				zombie.setBaby(oldZombie.isBaby());
				zombie.setCustomName(MySQLPet.getPetName(p.getUniqueId()));
				zombie.setCustomNameVisible(true);
				zombie.setPassenger(p);
				zombie.getEquipment().setHelmet(oldZombie.getEquipment().getHelmet());
				playerPets.put(p, zombie);
				break;
				
			case SPIDER:
				Spider spider = CustomSpider.spawn(p.getLocation());
				spider.setTarget(null);
				spider.setCustomName(MySQLPet.getPetName(p.getUniqueId()));
				spider.setCustomNameVisible(true);
				spider.setPassenger(p);
				playerPets.put(p, spider);
				break;
				
			case IRONGOLEM:
				IronGolem irongolem = CustomIronGolem.spawn(p.getLocation());
				irongolem.setTarget(null);
				irongolem.setCustomName(MySQLPet.getPetName(p.getUniqueId()));
				irongolem.setCustomNameVisible(true);
				irongolem.setPassenger(p);
				playerPets.put(p, irongolem);
				break;	
			
			case WITCH:
				Witch witch = CustomWitch.spawn(p.getLocation());
				witch.setTarget(null);
				witch.setCustomName(MySQLPet.getPetName(p.getUniqueId()));
				witch.setCustomNameVisible(true);
				witch.setPassenger(p);
				playerPets.put(p, witch);
				break;
				
			case BLAZE:
				Blaze blaze = CustomBlaze.spawn(p.getLocation());
				blaze.setTarget(null);
				blaze.setCustomName(MySQLPet.getPetName(p.getUniqueId()));
				blaze.setCustomNameVisible(true);
				blaze.setPassenger(p);
				playerPets.put(p, blaze);
				break;
				
			case ENDERMAN:
				Enderman enderman = CustomEnderman.spawn(p.getLocation());
				enderman.setTarget(null);
				enderman.setCustomName(MySQLPet.getPetName(p.getUniqueId()));
				enderman.setCustomNameVisible(true);
				enderman.setPassenger(p);
				playerPets.put(p, enderman);
				break;	
				
			case WOLF:
				Wolf oldWolf = (Wolf) e;
				Wolf wolf = CustomWolf.spawn(p.getLocation());
				wolf.setAgeLock(true);
				wolf.setTarget(null);
				wolf.setAngry(oldWolf.isAngry());
				wolf.setSitting(oldWolf.isSitting());
				wolf.setTamed(oldWolf.isTamed());
				wolf.setCollarColor(oldWolf.getCollarColor());
				if(oldWolf.isAdult()) {wolf.setAdult();} else {wolf.setBaby();}
				wolf.setCustomName(MySQLPet.getPetName(p.getUniqueId()));
				wolf.setCustomNameVisible(true);
				wolf.setPassenger(p);
				playerPets.put(p, wolf);
				break;	
				
			case SNOWMAN:
				Snowman snowman = CustomSnowMan.spawn(p.getLocation());
				snowman.setTarget(null);
				snowman.setCustomName(MySQLPet.getPetName(p.getUniqueId()));
				snowman.setCustomNameVisible(true);
				snowman.setPassenger(p);
				playerPets.put(p, snowman);
				break;	
				
			case MUSHROOMCOW:
				MushroomCow oldMushroomcow = (MushroomCow) e;
				MushroomCow mushroomcow = CustomMushroomCow.spawn(p.getLocation());
				mushroomcow.setTarget(null);
				if(oldMushroomcow.isAdult()) {mushroomcow.setAdult();} else {mushroomcow.setBaby();}
				mushroomcow.setCustomName(MySQLPet.getPetName(p.getUniqueId()));
				mushroomcow.setCustomNameVisible(true);
				mushroomcow.setPassenger(p);
				playerPets.put(p, mushroomcow);
				break;	
				
			case SILVERFISH:
				Silverfish silverfish = CustomSilverfish.spawn(p.getLocation());
				silverfish.setTarget(null);
				silverfish.setCustomName(MySQLPet.getPetName(p.getUniqueId()));
				silverfish.setCustomNameVisible(true);
				silverfish.setPassenger(p);
				playerPets.put(p, silverfish);
				break;	
				
			case CAVESPIDER:
				CaveSpider cavespider = CustomCaveSpider.spawn(p.getLocation());
				cavespider.setTarget(null);
				cavespider.setCustomName(MySQLPet.getPetName(p.getUniqueId()));
				cavespider.setCustomNameVisible(true);
				cavespider.setPassenger(p);
				playerPets.put(p, cavespider);
				break;	
				
			default:
				break;
			}
		}
	}
	
	public static void setPetName(Player p, String name) {
		if(playerPets.containsKey(p)) {
			MySQLPet.setPetName(p.getUniqueId(), name);
			playerPets.get(p).setCustomName(name);
		}
	}
	
	public static void removePlayersPet(Player p) {
		MySQLPet.removePet(p.getUniqueId());
		playerPets.get(p).remove();
		playerPets.remove(p);
	}

	@EventHandler
	public void onMove(PlayerMoveEvent e) {
		Player p = e.getPlayer();
		
		if(playerPets.containsKey(p)) {
			Entity ent = playerPets.get(p);
			
			Location loc = p.getLocation();
			if(ent.getLocation().distance(p.getLocation()) >= 3) {
				((CraftCreature)ent).getHandle().getNavigation().a(loc.getX(), loc.getY(), loc.getZ(), 1.7D);
			
			}
			if(ent.getLocation().distance(p.getLocation()) >= 15) {
				ent.teleport(p);
			}
		}
	}
	
	@SuppressWarnings("deprecation")
	@EventHandler
	public void onDismount(EntityDismountEvent event) {
		if(event.getEntity() instanceof Player) {
			Player p = (Player) event.getEntity();
			if(playerPets.containsKey(p)) {
				Entity e = playerPets.get(p);
				e.remove();
				Pet pet = MySQLPet.getPetType(p.getUniqueId());
				playerPets.remove(p);
				
				switch (pet) {
				case SHEEP:
					Sheep oldSheep = (Sheep) e;
					Sheep sheep = (Sheep) p.getWorld().spawnEntity(p.getLocation(), pet.getEntType());
					if(oldSheep.isAdult()) {sheep.setAdult();} else {sheep.setBaby();}
					sheep.setAgeLock(true);
					sheep.setTarget(null);
					sheep.setColor(oldSheep.getColor());
					sheep.setSheared(oldSheep.isSheared());
					sheep.setCustomName(MySQLPet.getPetName(p.getUniqueId()));
					sheep.setCustomNameVisible(true);
					sheep.setPassenger(null);
					playerPets.put(p, sheep);
					break;
					
				case PIG:
					Pig oldPig = (Pig) e;
					Pig pig = (Pig) p.getWorld().spawnEntity(p.getLocation(), pet.getEntType());
					if(oldPig.isAdult()) {pig.setAdult();} else {pig.setBaby();}
					pig.setAgeLock(true);
					pig.setTarget(null);
					pig.setSaddle(oldPig.hasSaddle());
					pig.setCustomName(MySQLPet.getPetName(p.getUniqueId()));
					pig.setCustomNameVisible(true);
					pig.setPassenger(null);
					playerPets.put(p, pig);
					break;
					
				case CHICKEN:
					Chicken oldChicken = (Chicken) e;
					Chicken chicken = (Chicken) p.getWorld().spawnEntity(p.getLocation(), pet.getEntType());
					if(oldChicken.isAdult()) {chicken.setAdult();} else {chicken.setBaby();}
					chicken.setAgeLock(true);
					chicken.setTarget(null);
					chicken.setCustomName(MySQLPet.getPetName(p.getUniqueId()));
					chicken.setCustomNameVisible(true);
					chicken.setPassenger(null);
					playerPets.put(p, chicken);
					break;
					
				case COW:
					Cow oldCow = (Cow) e;
					Cow cow = (Cow) p.getWorld().spawnEntity(p.getLocation(), pet.getEntType());
					if(oldCow.isAdult()) {cow.setAdult();} else {cow.setBaby();}
					cow.setAgeLock(true);
					cow.setTarget(null);
					cow.setCustomName(MySQLPet.getPetName(p.getUniqueId()));
					cow.setCustomNameVisible(true);
					cow.setPassenger(null);
					playerPets.put(p, cow);
					break;	
					
				case OCELOT:
					Ocelot oldOcelot = (Ocelot) e;
					Ocelot ocelot = (Ocelot) p.getWorld().spawnEntity(p.getLocation(), pet.getEntType());
					if(oldOcelot.isAdult()) {ocelot.setAdult();} else {ocelot.setBaby();}
					ocelot.setAgeLock(true);
					ocelot.setTarget(null);
					ocelot.setSitting(oldOcelot.isSitting());
					ocelot.setTamed(oldOcelot.isTamed());
					ocelot.setCatType(oldOcelot.getCatType());
//					ocelot.setOwner(p);
					ocelot.setCustomName(MySQLPet.getPetName(p.getUniqueId()));
					ocelot.setCustomNameVisible(true);
					ocelot.setPassenger(null);
					playerPets.put(p, ocelot);
					break;	
					
				case CREEPER:
					Creeper oldCreeper = (Creeper) e;
					Creeper creeper = (Creeper) p.getWorld().spawnEntity(p.getLocation(), pet.getEntType());
					creeper.setTarget(null);
					creeper.setPowered(oldCreeper.isPowered());
					creeper.setCustomName(MySQLPet.getPetName(p.getUniqueId()));
					creeper.setCustomNameVisible(true);
					creeper.setPassenger(null);
					setDontExplode(creeper);
					playerPets.put(p, creeper);
					break;	
					
				case SKELETON:
					Skeleton oldSkeleton = (Skeleton) e;
					Skeleton skeleton = (Skeleton) p.getWorld().spawnEntity(p.getLocation(), pet.getEntType());
					skeleton.setTarget(null);
					skeleton.setCustomName(MySQLPet.getPetName(p.getUniqueId()));
					skeleton.setCustomNameVisible(true);
					skeleton.setPassenger(null);
					skeleton.getEquipment().setHelmet(oldSkeleton.getEquipment().getHelmet());
					playerPets.put(p, skeleton);
					break;
					
				case ZOMBIE:
					Zombie oldZombie = (Zombie) e;
					Zombie zombie = (Zombie) p.getWorld().spawnEntity(p.getLocation(), pet.getEntType());
					zombie.setTarget(null);
					zombie.setBaby(oldZombie.isBaby());
					zombie.setCustomName(MySQLPet.getPetName(p.getUniqueId()));
					zombie.setCustomNameVisible(true);
					zombie.setPassenger(null);
					zombie.getEquipment().setHelmet(oldZombie.getEquipment().getHelmet());
					playerPets.put(p, zombie);
					break;
					
				case SPIDER:
					Spider spider = (Spider) p.getWorld().spawnEntity(p.getLocation(), pet.getEntType());
					spider.setTarget(null);
					spider.setCustomName(MySQLPet.getPetName(p.getUniqueId()));
					spider.setCustomNameVisible(true);
					spider.setPassenger(null);
					playerPets.put(p, spider);
					break;
					
				case IRONGOLEM:
					IronGolem irongolem = (IronGolem) p.getWorld().spawnEntity(p.getLocation(), pet.getEntType());
					irongolem.setTarget(null);
					irongolem.setCustomName(MySQLPet.getPetName(p.getUniqueId()));
					irongolem.setCustomNameVisible(true);
					irongolem.setPassenger(null);
					playerPets.put(p, irongolem);
					break;
					
				case WITCH:
					Witch witch = (Witch) p.getWorld().spawnEntity(p.getLocation(), pet.getEntType());
					witch.setTarget(null);
					witch.setCustomName(MySQLPet.getPetName(p.getUniqueId()));
					witch.setCustomNameVisible(true);
					witch.setPassenger(null);
					playerPets.put(p, witch);
					break;
					
				case BLAZE:
					Blaze blaze = (Blaze) p.getWorld().spawnEntity(p.getLocation(), pet.getEntType());
					blaze.setTarget(null);
					blaze.setCustomName(MySQLPet.getPetName(p.getUniqueId()));
					blaze.setCustomNameVisible(true);
					blaze.setPassenger(null);
					playerPets.put(p, blaze);
					break;
					
				case ENDERMAN:
					Enderman enderman = (Enderman) p.getWorld().spawnEntity(p.getLocation(), pet.getEntType());
					enderman.setTarget(null);
					enderman.setCustomName(MySQLPet.getPetName(p.getUniqueId()));
					enderman.setCustomNameVisible(true);
					enderman.setPassenger(null);
					playerPets.put(p, enderman);
					break;	
					
				case WOLF:
					Wolf oldWolf = (Wolf) e;
					Wolf wolf = (Wolf) p.getWorld().spawnEntity(p.getLocation(), pet.getEntType());
					wolf.setAgeLock(true);
					wolf.setTarget(null);
					wolf.setAngry(oldWolf.isAngry());
					wolf.setSitting(oldWolf.isSitting());
					wolf.setTamed(oldWolf.isTamed());
					wolf.setCollarColor(oldWolf.getCollarColor());
					if(oldWolf.isAdult()) {wolf.setAdult();} else {wolf.setBaby();}
					wolf.setCustomName(MySQLPet.getPetName(p.getUniqueId()));
					wolf.setCustomNameVisible(true);
					wolf.setPassenger(null);
					playerPets.put(p, wolf);
					break;	
					
				case SNOWMAN:
					Snowman snowman = (Snowman) p.getWorld().spawnEntity(p.getLocation(), pet.getEntType());
					snowman.setTarget(null);
					snowman.setCustomName(MySQLPet.getPetName(p.getUniqueId()));
					snowman.setCustomNameVisible(true);
					snowman.setPassenger(null);
					playerPets.put(p, snowman);
					break;	
					
				case MUSHROOMCOW:
					MushroomCow oldMushroomcow = (MushroomCow) e;
					MushroomCow mushroomcow = (MushroomCow) p.getWorld().spawnEntity(p.getLocation(), pet.getEntType());
					mushroomcow.setTarget(null);
					if(oldMushroomcow.isAdult()) {mushroomcow.setAdult();} else {mushroomcow.setBaby();}
					mushroomcow.setCustomName(MySQLPet.getPetName(p.getUniqueId()));
					mushroomcow.setCustomNameVisible(true);
					mushroomcow.setPassenger(null);
					playerPets.put(p, mushroomcow);
					break;	
					
				case SILVERFISH:
					Silverfish silverfish = (Silverfish) p.getWorld().spawnEntity(p.getLocation(), pet.getEntType());
					silverfish.setTarget(null);
					silverfish.setCustomName(MySQLPet.getPetName(p.getUniqueId()));
					silverfish.setCustomNameVisible(true);
					silverfish.setPassenger(null);
					playerPets.put(p, silverfish);
					break;	
					
				case CAVESPIDER:
					CaveSpider cavespider = (CaveSpider) p.getWorld().spawnEntity(p.getLocation(), pet.getEntType());
					cavespider.setTarget(null);
					cavespider.setCustomName(MySQLPet.getPetName(p.getUniqueId()));
					cavespider.setCustomNameVisible(true);
					cavespider.setPassenger(null);
					playerPets.put(p, cavespider);
					break;	
					
				default:
					break;
				}
			}
		}
	}
	
	public static void setDontExplode(Creeper creeper) {
        EntityCreeper entCreeper = ((CraftCreeper)creeper).getHandle();
        Field fuseF = null;
        try {
            fuseF = EntityCreeper.class.getDeclaredField("maxFuseTicks");
        } catch(NoSuchFieldException ex) {;}
        fuseF.setAccessible(true);
        try {
            fuseF.setInt(entCreeper, Integer.MAX_VALUE);
        } catch(IllegalAccessException ex) {;}
	}
	
}