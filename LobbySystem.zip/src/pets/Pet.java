package pets;

import lobbySystem.Main;
import net.minecraft.server.v1_11_R1.EntityBlaze;
import net.minecraft.server.v1_11_R1.EntityCaveSpider;
import net.minecraft.server.v1_11_R1.EntityChicken;
import net.minecraft.server.v1_11_R1.EntityCow;
import net.minecraft.server.v1_11_R1.EntityCreeper;
import net.minecraft.server.v1_11_R1.EntityEnderman;
import net.minecraft.server.v1_11_R1.EntityInsentient;
import net.minecraft.server.v1_11_R1.EntityIronGolem;
import net.minecraft.server.v1_11_R1.EntityMushroomCow;
import net.minecraft.server.v1_11_R1.EntityOcelot;
import net.minecraft.server.v1_11_R1.EntityPig;
import net.minecraft.server.v1_11_R1.EntitySheep;
import net.minecraft.server.v1_11_R1.EntitySilverfish;
import net.minecraft.server.v1_11_R1.EntitySkeleton;
import net.minecraft.server.v1_11_R1.EntitySnowman;
import net.minecraft.server.v1_11_R1.EntitySpider;
import net.minecraft.server.v1_11_R1.EntityTypes;
import net.minecraft.server.v1_11_R1.EntityWitch;
import net.minecraft.server.v1_11_R1.EntityWolf;
import net.minecraft.server.v1_11_R1.EntityZombie;
import net.minecraft.server.v1_11_R1.MinecraftKey;

import org.bukkit.ChatColor;
import org.bukkit.entity.EntityType;

import petCustomEntity.CustomBlaze;
import petCustomEntity.CustomCaveSpider;
import petCustomEntity.CustomChicken;
import petCustomEntity.CustomCow;
import petCustomEntity.CustomCreeper;
import petCustomEntity.CustomEnderman;
import petCustomEntity.CustomIronGolem;
import petCustomEntity.CustomMushroomCow;
import petCustomEntity.CustomOcelot;
import petCustomEntity.CustomPig;
import petCustomEntity.CustomSheep;
import petCustomEntity.CustomSilverfish;
import petCustomEntity.CustomSkeleton;
import petCustomEntity.CustomSnowMan;
import petCustomEntity.CustomSpider;
import petCustomEntity.CustomWitch;
import petCustomEntity.CustomWolf;
import petCustomEntity.CustomZombie;



public enum Pet {

	SHEEP(0, EntityType.SHEEP, false, ChatColor.translateAlternateColorCodes('&', Main.getMain().getMessage("sheep")), 500, 200, 
			"Sheep", 91, EntitySheep.class, CustomSheep.class),
			
	PIG(1, EntityType.PIG, false, ChatColor.translateAlternateColorCodes('&', Main.getMain().getMessage("pig")), 500, 100,
			"Pig", 90, EntityPig.class, CustomPig.class),
			
	CHICKEN(2, EntityType.CHICKEN, false, ChatColor.translateAlternateColorCodes('&', Main.getMain().getMessage("chicken")), 500, 50,
			"Chicken", 93, EntityChicken.class, CustomChicken.class),
			
	COW(3, EntityType.COW, false, ChatColor.translateAlternateColorCodes('&', Main.getMain().getMessage("cow")), 500, 50,
			"Cow", 92, EntityCow.class, CustomCow.class),
			
	OCELOT(4, EntityType.OCELOT, false, ChatColor.translateAlternateColorCodes('&', Main.getMain().getMessage("ocelot")), 500, 300,
			"Ozelot", 98, EntityOcelot.class, CustomOcelot.class),
			
	CREEPER(5, EntityType.CREEPER, false, ChatColor.translateAlternateColorCodes('&', Main.getMain().getMessage("creeper")), 500, 50,
			"Creeper", 50, EntityCreeper.class, CustomCreeper.class),
			
	SKELETON(6, EntityType.SKELETON, false, ChatColor.translateAlternateColorCodes('&', Main.getMain().getMessage("skeleton")), 500, 50,
			"Skeleton", 51, EntitySkeleton.class, CustomSkeleton.class),
			
	ZOMBIE(7, EntityType.ZOMBIE, false, ChatColor.translateAlternateColorCodes('&', Main.getMain().getMessage("zombie")), 500, 100,
			"Zombie", 54, EntityZombie.class, CustomZombie.class),
			
	SPIDER(8, EntityType.SPIDER, false, ChatColor.translateAlternateColorCodes('&', Main.getMain().getMessage("spider")), 500, 0,
			"Spider", 52, EntitySpider.class, CustomSpider.class),
	
	IRONGOLEM(9, EntityType.IRON_GOLEM, true, ChatColor.translateAlternateColorCodes('&', Main.getMain().getMessage("irongolem")), 1500, 0,
			"VillagerGolem", 99, EntityIronGolem.class, CustomIronGolem.class),
	
	WITCH(10, EntityType.WITCH, true, ChatColor.translateAlternateColorCodes('&', Main.getMain().getMessage("witch")), 1500, 0,
			"Witch", 66, EntityWitch.class, CustomWitch.class),
	
	BLAZE(11, EntityType.BLAZE, true, ChatColor.translateAlternateColorCodes('&', Main.getMain().getMessage("blaze")), 1500, 0,
			"Blaze", 61, EntityBlaze.class, CustomBlaze.class),
			
	ENDERMAN(12, EntityType.ENDERMAN, true, ChatColor.translateAlternateColorCodes('&', Main.getMain().getMessage("enderman")), 2500, 0,
			"Enderman", 58, EntityEnderman.class, CustomEnderman.class),
	
	WOLF(13, EntityType.WOLF, true, ChatColor.translateAlternateColorCodes('&', Main.getMain().getMessage("wolf")), 2200, 300,
			"Wolf", 95, EntityWolf.class, CustomWolf.class),
			
	SNOWMAN(14, EntityType.SNOWMAN, true, ChatColor.translateAlternateColorCodes('&', Main.getMain().getMessage("snowman")), 1500, 0,
			"SnowMan", 97, EntitySnowman.class, CustomSnowMan.class),
			
	MUSHROOMCOW(15, EntityType.MUSHROOM_COW, true, ChatColor.translateAlternateColorCodes('&', Main.getMain().getMessage("mushroomcow")), 1500, 50,
			"MushroomCow", 96, EntityMushroomCow.class, CustomMushroomCow.class),
		
	SILVERFISH(16, EntityType.SILVERFISH, true, ChatColor.translateAlternateColorCodes('&', Main.getMain().getMessage("silverfish")), 1500, 0,
			"Silverfish", 60, EntitySilverfish.class, CustomSilverfish.class),
					
	CAVESPIDER(17, EntityType.CAVE_SPIDER, true, ChatColor.translateAlternateColorCodes('&', Main.getMain().getMessage("cavespider")), 1500, 0,
			"CaveSpider", 59, EntityCaveSpider.class, CustomCaveSpider.class);
							
	private int slot;
	private EntityType entType;
	private boolean permission;
	private String displayname;
	private int cost;
	private int optionCost;
	
	// this is for the nms
	private String name;
	private int id;
	private Class<? extends EntityInsentient> nmsClass;
	private Class<? extends EntityInsentient> customClass;
    private MinecraftKey key;
    private MinecraftKey oldKey;
	
	private Pet(int slot, EntityType entType, boolean permission, String displayname, int cost, int optionCost,
			String name, int id, Class<? extends EntityInsentient> nmsClass, Class<? extends EntityInsentient> customClass) {
		this.slot = slot;
		this.entType = entType;
		this.permission = permission;
		this.displayname = displayname;
		this.cost = cost;
		this.optionCost = optionCost;
		
		this.name = name;
		this.id = id;
		this.nmsClass = nmsClass;
		this.customClass = customClass;
        this.key = new MinecraftKey(name);
        this.oldKey = EntityTypes.b.b(nmsClass);
	}
	
	public static void registerEntities() { for (Pet ce : values()) ce.register(); }
    public static void unregisterEntities() { for (Pet ce : values()) ce.unregister(); }

    private void register() {
        EntityTypes.d.add(key);
        EntityTypes.b.a(id, key, customClass);
    }

    private void unregister() {
        EntityTypes.d.remove(key);
        EntityTypes.b.a(id, oldKey, nmsClass);
    }

    public String getName() {
        return name;
    }

    public int getID() {
        return id;
    }

    public Class<?> getCustomClass() {
        return customClass;
    }
	
	public int getSlot() {
		return slot;
	}
	
	public String getDisplayname() {
		return displayname;
	}
	
	public EntityType getEntType() {
		return entType;
	}
	
	public boolean isPermission() {
		return permission;
	}

	public int getCost() {
		return cost;
	}

	public int getOptionCost() {
		return optionCost;
	}
}
