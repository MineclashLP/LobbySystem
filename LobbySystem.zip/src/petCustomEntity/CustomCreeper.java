package petCustomEntity;

import java.lang.reflect.Field;

import net.minecraft.server.v1_11_R1.EntityCreeper;
import net.minecraft.server.v1_11_R1.EntityLiving;
import net.minecraft.server.v1_11_R1.World;

import org.bukkit.Location;
import org.bukkit.craftbukkit.v1_11_R1.CraftWorld;
import org.bukkit.craftbukkit.v1_11_R1.entity.CraftCreeper;
import org.bukkit.entity.Creeper;
import org.bukkit.event.entity.CreatureSpawnEvent.SpawnReason;

public class CustomCreeper extends EntityCreeper {

	public CustomCreeper(World world) {
		super(world);
		Field field = null;
		try {
			field = EntityCreeper.class.getDeclaredField("maxFuseTicks");
		} catch (NoSuchFieldException e1) { e1.printStackTrace(); }
		field.setAccessible(true);
		try {
			field.setInt(this, Integer.MAX_VALUE);
		} catch (IllegalAccessException e) {e.printStackTrace();}
	}
	
	public static Creeper spawn(Location loc) {
		  CustomCreeper customSpider = new CustomCreeper(((CraftWorld)loc.getWorld()).getHandle());
		  customSpider.setPositionRotation(loc.getX(), loc.getY(), loc.getZ(), loc.getYaw(), loc.getPitch());
		  ((CraftWorld)loc.getWorld()).getHandle().addEntity(customSpider, SpawnReason.CUSTOM);	
		  return (CraftCreeper) customSpider.getBukkitEntity();
	}
	
	@Override
	public void g(float sideMot, float forMot) {
		if(!this.passengers.isEmpty()) {
			EntityLiving passenger = (EntityLiving) this.passengers.get(0);

			this.yaw = passenger.yaw;
			this.lastYaw = this.yaw;
			this.pitch = (passenger.pitch * 0.5F);

			setYawPitch(this.yaw, this.pitch);

			this.aN = this.yaw;
			this.aP = this.aN;

			Float speedmultiplicator = 3F;//Here you can set the speed

			sideMot = passenger.be * speedmultiplicator;
			forMot = passenger.bf * speedmultiplicator; 

			if(forMot <= 0.0F) {
				forMot *= 0.25F;// Make backwards slower
			}

			Field jump = null; //Jumping

			try {
				jump = EntityLiving.class.getDeclaredField("bd");
			} catch (NoSuchFieldException e1) {
				e1.printStackTrace();
			} catch (SecurityException e1) {
				e1.printStackTrace();
			}

			jump.setAccessible(true);

			if (jump != null && this.onGround) { // Wouldn't want it jumping while on the ground would we?
				try {
					if (jump.getBoolean(passenger)) {
						double jumpHeight = 0.5D; //Here you can set the jumpHeight
						this.motY = jumpHeight; // Used all the time in NMS for entity jumping
					}

				} catch (IllegalAccessException e) {
					e.printStackTrace();
				}
			}

			super.g(sideMot, forMot);
		}
	}
	
}
