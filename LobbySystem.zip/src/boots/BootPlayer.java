package boots;

import java.util.ArrayList;
import java.util.HashMap;

import lobbySystem.Main;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Blaze;
import org.bukkit.entity.Creeper;
import org.bukkit.entity.Enderman;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.entity.Skeleton;
import org.bukkit.entity.Snowman;
import org.bukkit.entity.Witch;
import org.bukkit.entity.Zombie;
import org.bukkit.event.Listener;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import de.slikey.effectlib.EffectManager;
import de.slikey.effectlib.effect.ShieldEffect;
import de.slikey.effectlib.util.ParticleEffect;
import utils.ItemCreator;

public class BootPlayer implements Listener {

	private static Main m = Main.getMain();
	public static HashMap<Player, Boot> equippedBoots = new HashMap<Player, Boot>();
	
	public static void setPlayerBoots(Player p, Boot boot) {
		if(equippedBoots.containsKey(p)) {
			equippedBoots.remove(p);
			p.getInventory().setBoots(null);
		}
		
		equippedBoots.put(p, boot);
		if(boot.getMaterial() == Material.LEATHER_BOOTS) {
			p.getInventory().setBoots(ItemCreator.crItemLeatherArmor(boot.getMaterial(), 1, boot.getDisplayname(), true, boot.getColor()));
		} else {
			p.getInventory().setBoots(ItemCreator.crItemArmor(boot.getMaterial(), 1, boot.getDisplayname(), true));
		}
	}
	
	public static void startBootEffectRunnable() {
		HashMap<Item, Integer> goldTime = new HashMap<Item, Integer>();
		HashMap<Item, Integer> steakTime = new HashMap<Item, Integer>();
		
		Bukkit.getScheduler().scheduleSyncRepeatingTask(m, new Runnable() {
			
			@SuppressWarnings("deprecation")
			@Override
			public void run() {
				for(Player all : Bukkit.getOnlinePlayers()) {
					if(equippedBoots.containsKey(all)) {
						if(all.isSneaking()) {
							if(equippedBoots.get(all).getSneakEffect() != null) {
								all.getWorld().spigot().playEffect(all.getLocation(), equippedBoots.get(all).getSneakEffect(), 0, 0, 0, (float) 0.5, 0, 0, 15, 5);
							}
							
							if(equippedBoots.get(all) == Boot.JETPACKBOOTS) {
								all.setVelocity(all.getLocation().getDirection().multiply(5D).normalize());
							}
							if(equippedBoots.get(all) == Boot.BURNBOOTS) {
								all.setFireTicks(20);
							}
							if(equippedBoots.get(all) == Boot.SHIELDBOOTS) {
								EffectManager em = new EffectManager(m);
								ShieldEffect effect = new ShieldEffect(em);
								effect.duration = 20;
								effect.particle = ParticleEffect.FLAME;
								effect.setLocation(all.getLocation());
								effect.start();
							}
							if(equippedBoots.get(all) == Boot.GHOSTBOOTS) {
								all.addPotionEffect(new PotionEffect(PotionEffectType.INVISIBILITY, 20, 1, false, false));
							}
							if(equippedBoots.get(all) == Boot.HOVERBOOTS) {
								all.addPotionEffect(new PotionEffect(PotionEffectType.LEVITATION, 20, 5, false, false));
							}
						} else {
							all.getWorld().spigot().playEffect(all.getLocation(), equippedBoots.get(all).getNormalEffect(), 0, 0, 0, (float) 0.3, 0, 0, 1, 0);
							
							if(equippedBoots.get(all) == Boot.MONEYBOOTS) {
								Item item = all.getWorld().dropItem(all.getLocation(), ItemCreator.crItem(Material.GOLD_INGOT, 1, " "));
								goldTime.put(item, 40);
							}
							if(equippedBoots.get(all) == Boot.STEAKBOOTS) {
								Item item = all.getWorld().dropItem(all.getLocation(), ItemCreator.crItem(Material.COOKED_BEEF, 1, " "));
								steakTime.put(item, 40);
							}
							if(equippedBoots.get(all) == Boot.SPEEDBOOTS) {
								all.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 20, 2, false, false));
							}
							
							ArrayList<Item> removeGoldItems = new ArrayList<Item>();
							for(Item items : goldTime.keySet()) {
								goldTime.replace(items, goldTime.get(items) - 1);
								if(goldTime.get(items) <= 0) {
									removeGoldItems.add(items);
									items.remove();
								}
							}
							removeGoldItems.clear();
							
							ArrayList<Item> removeSteakItems = new ArrayList<Item>();
							for(Item items : steakTime.keySet()) {
								steakTime.replace(items, steakTime.get(items) - 1);
								if(steakTime.get(items) <= 0) {
									removeSteakItems.add(items);
									items.remove();
								}
							}
							removeSteakItems.clear();
						}
					}
					
					
					// for the pets
					for(Entity ents : all.getWorld().getEntities()) {
						if(ents instanceof Skeleton) {
							((Skeleton) ents).setTarget(null);
						}
						if(ents instanceof Zombie) {
							((Zombie) ents).setTarget(null);
						}
						if(ents instanceof Creeper) {
							((Creeper) ents).setTarget(null);
						}
						if(ents instanceof Witch) {
							((Witch) ents).setTarget(null);
						}
						if(ents instanceof Blaze) {
							((Blaze) ents).setTarget(null);
						}
						if(ents instanceof Enderman) {
							((Enderman) ents).setTarget(null);
						}
						
						if(ents instanceof Snowman) {
							ArrayList<Location> locs = new ArrayList<Location>();
							locs.add(ents.getLocation().add(0, 0, 0));
							locs.add(ents.getLocation().add(1, 0, 0));
							locs.add(ents.getLocation().add(1, 0, 1));
							locs.add(ents.getLocation().add(0, 0, 1));
							locs.add(ents.getLocation().subtract(1, 0, 0));
							locs.add(ents.getLocation().subtract(1, 0, 1));
							locs.add(ents.getLocation().subtract(0, 0, 1));
							locs.add(ents.getLocation().subtract(1, 0, 0).add(0, 0, 1));
							locs.add(ents.getLocation().subtract(0, 0, 1).add(1, 0, 0));
							
							for(Location loc : locs) {
								if(loc.getBlock().getType() == Material.SNOW) {
									loc.getBlock().setType(Material.AIR);
								}
							}
						}
					}
				}
			}
		}, 1, 1);
	}
	
	
}
