package utils;

import java.util.List;

import org.bukkit.Color;
import org.bukkit.DyeColor;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.EntityType;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.LeatherArmorMeta;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.inventory.meta.SpawnEggMeta;

public class ItemCreator {

	public static ItemStack crItem(Material material, int amount, String displayname) {
		ItemStack item = new ItemStack(material, amount);
		ItemMeta meta = item.getItemMeta();
		meta.setDisplayName(displayname);
		item.setItemMeta(meta);
		return item;
	}
	
	public static ItemStack crItemArmor(Material material, int amount, String displayname, boolean ench) {
		ItemStack item = new ItemStack(material, amount);
		if(ench) item.addUnsafeEnchantment(Enchantment.DAMAGE_ALL, 1);
		ItemMeta meta = item.getItemMeta();
		meta.setDisplayName(displayname);
		meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
		meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
		item.setItemMeta(meta);
		return item;
	}
	
	public static ItemStack crItemLeatherArmor(Material material, int amount, String displayname, boolean ench, Color color) {
		ItemStack item = new ItemStack(material, amount);
		if(ench) item.addUnsafeEnchantment(Enchantment.DAMAGE_ALL, 1);
		LeatherArmorMeta meta = (LeatherArmorMeta) item.getItemMeta();
		meta.setDisplayName(displayname);
		meta.setColor(color);
		meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
		meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
		item.setItemMeta(meta);
		return item;
	}
	
	public static ItemStack crItemLeatherArmor(Material material, int amount, String displayname, boolean ench, Color color, List<String> lore) {
		ItemStack item = new ItemStack(material, amount);
		if(ench) item.addUnsafeEnchantment(Enchantment.DAMAGE_ALL, 1);
		LeatherArmorMeta meta = (LeatherArmorMeta) item.getItemMeta();
		meta.setDisplayName(displayname);
		meta.setLore(lore);
		meta.setColor(color);
		meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
		meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
		item.setItemMeta(meta);
		return item;
	}
	
	public static ItemStack crItem(Material material, int amount, List<String> lore, String displayname) {
		ItemStack item = new ItemStack(material, amount);
		ItemMeta meta = item.getItemMeta();
		meta.setDisplayName(displayname);
		meta.setLore(lore);
		item.setItemMeta(meta);
		return item;
	}
	
	public static ItemStack crItem(Material material, int amount, short subID, String displayname) {
		ItemStack item = new ItemStack(material, amount, subID);
		ItemMeta meta = item.getItemMeta();
		meta.setDisplayName(displayname);
		item.setItemMeta(meta);
		return item;
	}
	
	public static ItemStack crItemSpawnEgg(int amount, String displayname, EntityType type) {
		ItemStack item = new ItemStack(Material.MONSTER_EGG, amount);
		SpawnEggMeta meta = (SpawnEggMeta) item.getItemMeta();
		meta.setDisplayName(displayname);
		meta.setSpawnedType(type);
		item.setItemMeta(meta);
		return item;
	}
	
	public static ItemStack crItem(Material material, int amount, short subID, String displayname, boolean enchantet, boolean unbreakable) {
		ItemStack item = new ItemStack(material, amount, subID);
		if(enchantet) {item.addUnsafeEnchantment(Enchantment.DAMAGE_ALL, 1);};
		ItemMeta meta = item.getItemMeta();
		meta.setDisplayName(displayname);
		meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
		meta.addItemFlags(ItemFlag.HIDE_UNBREAKABLE);
		if(unbreakable) {meta.setUnbreakable(true);};
		item.setItemMeta(meta);
		return item;
	}
	
	public static ItemStack crItem(Material material, int amount, short subID, List<String> lore, String displayname, boolean enchantet, boolean unbreakable) {
		ItemStack item = new ItemStack(material, amount, subID);
		if(enchantet) {item.addUnsafeEnchantment(Enchantment.DAMAGE_ALL, 1);};
		ItemMeta meta = item.getItemMeta();
		meta.setDisplayName(displayname);
		meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
		meta.addItemFlags(ItemFlag.HIDE_UNBREAKABLE);
		meta.setLore(lore);
		if(unbreakable) {meta.setUnbreakable(true);};
		item.setItemMeta(meta);
		return item;
	}
	
	public static ItemStack crItemHead(int amount, String displayname, String ownerName) {
		ItemStack item = new ItemStack(Material.SKULL_ITEM, amount, (short) 3);
		SkullMeta meta = (SkullMeta) item.getItemMeta();
		meta.setDisplayName(displayname);
		meta.setOwner(ownerName);
		item.setItemMeta(meta);
		return item;
	}
	
	public static void fillInvWithDarkGlass(Inventory inv) {
		for(int i = 0; i < inv.getSize(); i++) {
			if(inv.getItem(i) == null) {
				inv.setItem(i, ItemCreator.crItem(Material.STAINED_GLASS_PANE, 1, (short) 7, " "));
			}
		}
	}
	
	public static boolean isEnch(ItemStack item) {
		if(item.getEnchantments().size() > 0)
			return true;
		return false;
	}

	@SuppressWarnings("deprecation")
	public static ItemStack crItemWool(int amount, String displayname, DyeColor color) {
		ItemStack item = new ItemStack(Material.WOOL, amount, color.getWoolData());
		ItemMeta meta = item.getItemMeta();
		meta.setDisplayName(displayname);
		item.setItemMeta(meta);
		return item;
	}
}
