package utils;

import lobbySystem.Main;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Scoreboard;

import coinAPI.CoinAPI;

public class SBManager {

	private static Main m = Main.getMain();
	
	public static void updateLobbySB(Player p) {
		Scoreboard sb = Bukkit.getScoreboardManager().getMainScoreboard();
		
		if(sb.getObjective("lobbySB") != null)
			sb.getObjective("lobbySB").unregister();
		
		Objective obj = sb.registerNewObjective("lobbySB", "dummy");
		obj.setDisplayName(ChatColor.translateAlternateColorCodes('&', m.getConfigValueString("sbTitel")));
		obj.setDisplaySlot(DisplaySlot.SIDEBAR);
		
		obj.getScore("�7-------------").setScore(9);
		obj.getScore("" + ChatColor.translateAlternateColorCodes('&', m.getMessage("player"))).setScore(8);
		obj.getScore("�f" + Bukkit.getOnlinePlayers().size()).setScore(7);
		obj.getScore("  ").setScore(6);
		obj.getScore("" + ChatColor.translateAlternateColorCodes('&', m.getMessage("lobby"))).setScore(5);
		obj.getScore("�f" + p.getWorld().getName()).setScore(4);
		obj.getScore(" ").setScore(3);
		obj.getScore(m.coinName + ":").setScore(2);
		obj.getScore("�f" + CoinAPI.getCoins(p.getUniqueId())).setScore(1);
		
		p.setScoreboard(sb);
	}
	
}
