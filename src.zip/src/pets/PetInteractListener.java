package pets;

import lobbySystem.Main;
import mysql.MySQLPet;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.inventory.Inventory;

import utils.ItemCreator;

public class PetInteractListener implements Listener {

	@EventHandler
	public void onInteract(PlayerInteractEntityEvent e) {
		Player p = e.getPlayer();
		
		e.setCancelled(true);
		
		Entity ent = e.getRightClicked();
		Player owner = null;
		
		for(Player players : PetManager.playerPets.keySet()) {
			if(PetManager.playerPets.get(players).equals(ent)) {
				owner = players;
			}
		}
		
		if(owner != null && p.equals(owner)) {
			Pet pet = MySQLPet.getPetType(owner.getUniqueId());
			openPetOptions(p, pet);
		}
	}
	
	private static Main m = Main.getMain();
	
	public static void openPetOptions(Player p, Pet pet) {
		Inventory inv = Bukkit.createInventory(null, 9*1, pet.getDisplayname() + " �7- " + ChatColor.translateAlternateColorCodes('&', m.getMessage("petOptions")));
		
		inv.setItem(0, ItemCreator.crItem(Material.NAME_TAG, 1, ChatColor.translateAlternateColorCodes('&', m.getMessage("changeName"))));
		inv.setItem(1, ItemCreator.crItemArmor(Material.IRON_HELMET, 1, ChatColor.translateAlternateColorCodes('&', m.getMessage("setOnHead")), false));
		inv.setItem(4, ItemCreator.crItem(Material.SADDLE, 1, ChatColor.translateAlternateColorCodes('&', m.getMessage("ride"))));
		if(MySQLPet.hasPetOptions(p.getUniqueId(), pet)) {
			inv.setItem(7, ItemCreator.crItem(Material.NETHER_STAR, 1, ChatColor.translateAlternateColorCodes('&', m.getMessage("petOptions")) 
					+ " �7(" + ChatColor.translateAlternateColorCodes('&', m.getMessage("buyed")) + "�7)"));
		} else {
			inv.setItem(7, ItemCreator.crItem(Material.NETHER_STAR, 1, ChatColor.translateAlternateColorCodes('&', m.getMessage("petOptions"))
					+ " �7(�e" + pet.getOptionCost() + " " + m.coinName + "�7)"));
		}
		inv.setItem(8, ItemCreator.crItem(Material.BARRIER, 1, ChatColor.translateAlternateColorCodes('&', m.getMessage("removePet"))));
		
		
		// fills the inventory with dark glasspanes
		for(int i = 0; i < inv.getSize(); i++) {
			if(inv.getItem(i) == null) {
				inv.setItem(i, ItemCreator.crItem(Material.STAINED_GLASS_PANE, 1, (short) 7, " "));
			}
		}
		
		p.openInventory(inv);
	}
	
}
