package pets;

import java.util.ArrayList;
import java.util.HashMap;

import lobbySystem.Main;
import mysql.MySQLPet;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Chicken;
import org.bukkit.entity.Cow;
import org.bukkit.entity.Creeper;
import org.bukkit.entity.Entity;
import org.bukkit.entity.MushroomCow;
import org.bukkit.entity.Ocelot;
import org.bukkit.entity.Pig;
import org.bukkit.entity.Player;
import org.bukkit.entity.Sheep;
import org.bukkit.entity.Skeleton;
import org.bukkit.entity.Wolf;
import org.bukkit.entity.Zombie;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;

import utils.ItemCreator;
import utils.SBManager;
import coinAPI.CoinAPI;

public class PetOptionsMenueManager implements Listener {

	private static Main m = Main.getMain();
	public static ArrayList<Player> petRenameP = new ArrayList<Player>();
	public static HashMap<Player, Pet> petOptionsBuyP = new HashMap<Player, Pet>();
	
	@SuppressWarnings("deprecation")
	@EventHandler
	public void onClick(InventoryClickEvent e) {
		Player p = (Player) e.getWhoClicked();
		
		if(e.getClickedInventory() != null && e.getClickedInventory().getTitle().contains(ChatColor.translateAlternateColorCodes('&', m.getMessage("petOptions")))) {
			Pet pet = MySQLPet.getPetType(p.getUniqueId());
			
			if(e.getCurrentItem().getType() == Material.NETHER_STAR) {
				if(MySQLPet.hasPetOptions(p.getUniqueId(), pet)) {
					openPetAdvOptionsInv(p);
				} else {
					if(petOptionsBuyP.containsKey(p)) {
						petOptionsBuyP.remove(p);
					}
					petOptionsBuyP.put(p, pet);
					openPetOptionsBuyInv(p);
				}
			}
			
			if(e.getCurrentItem().getType() == Material.IRON_HELMET) {
				Entity ent = PetManager.playerPets.get(p);
				if(p.getPassengers().contains(ent)) {
					ent.teleport(p);
					p.closeInventory();
				} else {
					p.setPassenger(ent);
					p.closeInventory();
					String msg = m.getMessage("petOnHead").replace("[prefix]", m.prefix);
					p.sendMessage(ChatColor.translateAlternateColorCodes('&', msg));
				}
			}
			
			if(e.getCurrentItem().getType() == Material.BARRIER) {
				if(PetManager.playerPets.containsKey(p)) {
					PetManager.removePlayersPet(p);
					p.closeInventory();
					String msg = m.getMessage("petRemoved").replace("[prefix]", m.prefix);
					p.sendMessage(ChatColor.translateAlternateColorCodes('&', msg));
				}
			}
			
			if(e.getCurrentItem().getType() == Material.NAME_TAG) {
				if(!petRenameP.contains(p)) {
					petRenameP.add(p);
				}
				p.closeInventory();
				String msg = m.getMessage("petRenameInfo").replace("[prefix]", m.prefix);
				p.sendMessage(ChatColor.translateAlternateColorCodes('$', msg));
			}
			
			if(e.getCurrentItem().getType() == Material.SADDLE) {
				PetManager.ridePet(p);
				p.closeInventory();
			}
			
		} else {
			if(e.getClickedInventory() != null && e.getClickedInventory().getTitle().contains(ChatColor.translateAlternateColorCodes('&', m.getMessage("advancedPetOptions")))) {
				
				
			}
		}
		
	}
	
	@SuppressWarnings("deprecation")
	public static void openPetAdvOptionsInv(Player p) {
		Pet pet = MySQLPet.getPetType(p.getUniqueId());
		String changeAge = ChatColor.translateAlternateColorCodes('&', m.getMessage("changeAge"));
		switch (pet) {
		case SHEEP:
			Sheep sheep = (Sheep) PetManager.playerPets.get(p);
			Inventory inv = Bukkit.createInventory(null, 9*1, ChatColor.translateAlternateColorCodes('&', m.getMessage("advancedPetOptions")));
			if(sheep.isAdult()) {inv.setItem(0, ItemCreator.crItem(Material.WHEAT, 1, changeAge));} else {inv.setItem(0, ItemCreator.crItem(Material.SEEDS, 1, changeAge));}
			inv.setItem(1, ItemCreator.crItemWool(1, ChatColor.translateAlternateColorCodes('&', m.getMessage("changeColor")), sheep.getColor()));
			if(!sheep.isSheared()) {inv.setItem(2, ItemCreator.crItem(Material.SHEARS, 1, ChatColor.translateAlternateColorCodes('&', m.getMessage("changeSheared"))));} 
				else {inv.setItem(2, ItemCreator.crItem(Material.SHEARS, 1, (short) 0, ChatColor.translateAlternateColorCodes('&', m.getMessage("changeSheared")), true, true));}
			ItemCreator.fillInvWithDarkGlass(inv);
			p.openInventory(inv);
			break;
			
		case PIG:
			Pig pig = (Pig) PetManager.playerPets.get(p);
			Inventory inv2 = Bukkit.createInventory(null, 9*1, ChatColor.translateAlternateColorCodes('&', m.getMessage("advancedPetOptions")));
			if(pig.isAdult()) {inv2.setItem(0, ItemCreator.crItem(Material.WHEAT, 1, changeAge));} else {inv2.setItem(0, ItemCreator.crItem(Material.SEEDS, 1, changeAge));}
			if(!pig.hasSaddle()) {inv2.setItem(1, ItemCreator.crItem(Material.SADDLE, 1, ChatColor.translateAlternateColorCodes('&', m.getMessage("changeSaddle"))));} 
				else {inv2.setItem(1, ItemCreator.crItem(Material.SADDLE, 1, (short) 0, ChatColor.translateAlternateColorCodes('&', m.getMessage("changeSaddle")), true, true));}
			ItemCreator.fillInvWithDarkGlass(inv2);
			p.openInventory(inv2);
			break;
			
		case CHICKEN:
			Chicken chicken = (Chicken) PetManager.playerPets.get(p);
			Inventory inv3 = Bukkit.createInventory(null, 9*1, ChatColor.translateAlternateColorCodes('&', m.getMessage("advancedPetOptions")));
			if(chicken.isAdult()) {inv3.setItem(0, ItemCreator.crItem(Material.WHEAT, 1, changeAge));} else {inv3.setItem(0, ItemCreator.crItem(Material.SEEDS, 1, changeAge));}
			ItemCreator.fillInvWithDarkGlass(inv3);
			p.openInventory(inv3);
			break;
			
		case COW:
			Cow cow = (Cow) PetManager.playerPets.get(p);
			Inventory inv4 = Bukkit.createInventory(null, 9*1, ChatColor.translateAlternateColorCodes('&', m.getMessage("advancedPetOptions")));
			if(cow.isAdult()) {inv4.setItem(0, ItemCreator.crItem(Material.WHEAT, 1, changeAge));} else {inv4.setItem(0, ItemCreator.crItem(Material.SEEDS, 1, changeAge));}
			ItemCreator.fillInvWithDarkGlass(inv4);
			p.openInventory(inv4);
			break;
			
		case OCELOT:
			Ocelot ocelot = (Ocelot) PetManager.playerPets.get(p);
			Inventory inv5 = Bukkit.createInventory(null, 9*1, ChatColor.translateAlternateColorCodes('&', m.getMessage("advancedPetOptions")));
			if(ocelot.isAdult()) {inv5.setItem(0, ItemCreator.crItem(Material.WHEAT, 1, changeAge));} else {inv5.setItem(0, ItemCreator.crItem(Material.SEEDS, 1, changeAge));}
			if(!ocelot.isSitting()) {inv5.setItem(1, ItemCreator.crItem(Material.WOOD_STAIRS, 1, ChatColor.translateAlternateColorCodes('&', m.getMessage("changeSitting"))));} 
				else {inv5.setItem(1, ItemCreator.crItem(Material.WOOD_STAIRS, 1, (short) 0, ChatColor.translateAlternateColorCodes('&', m.getMessage("changeSitting")), true, true));}
			if(!ocelot.isTamed()) {inv5.setItem(2, ItemCreator.crItem(Material.COOKED_FISH, 1, ChatColor.translateAlternateColorCodes('&', m.getMessage("changeTamed"))));} 
				else {inv5.setItem(2, ItemCreator.crItem(Material.COOKED_FISH, 1, (short) 0, ChatColor.translateAlternateColorCodes('&', m.getMessage("changeTamed")), true, true));}
			inv5.setItem(3, ItemCreator.crItem(Material.INK_SACK, 1, (short) (ocelot.getCatType().getId() + 1), ChatColor.translateAlternateColorCodes('&', m.getMessage("changeCatType"))));
			ItemCreator.fillInvWithDarkGlass(inv5);
			p.openInventory(inv5);
			break;	
			
		case CREEPER:
			Creeper creeper = (Creeper) PetManager.playerPets.get(p);
			Inventory inv6 = Bukkit.createInventory(null, 9*1, ChatColor.translateAlternateColorCodes('&', m.getMessage("advancedPetOptions")));
			if(!creeper.isPowered()) {inv6.setItem(0, ItemCreator.crItem(Material.ANVIL, 1, ChatColor.translateAlternateColorCodes('&', m.getMessage("changePowered"))));} 
				else {inv6.setItem(0, ItemCreator.crItem(Material.ANVIL, 1, (short) 0, ChatColor.translateAlternateColorCodes('&', m.getMessage("changePowered")), true, true));}
			ItemCreator.fillInvWithDarkGlass(inv6);
			p.openInventory(inv6);
			break;
			
		case SKELETON:
			Skeleton skeleton = (Skeleton) PetManager.playerPets.get(p);
			Inventory inv7 = Bukkit.createInventory(null, 9*1, ChatColor.translateAlternateColorCodes('&', m.getMessage("advancedPetOptions")));
			inv7.setItem(0, ItemCreator.crItemArmor(skeleton.getEquipment().getHelmet().getType(), 1, ChatColor.translateAlternateColorCodes('&', m.getMessage("changeHelmetType")), false));
			ItemCreator.fillInvWithDarkGlass(inv7);
			p.openInventory(inv7);
			break;
			
		case ZOMBIE:
			Zombie zombie = (Zombie) PetManager.playerPets.get(p);
			Inventory inv8 = Bukkit.createInventory(null, 9*1, ChatColor.translateAlternateColorCodes('&', m.getMessage("advancedPetOptions")));
			if(!zombie.isBaby()) {inv8.setItem(0, ItemCreator.crItem(Material.WHEAT, 1, changeAge));} else {inv8.setItem(0, ItemCreator.crItem(Material.SEEDS, 1, changeAge));}
			inv8.setItem(1, ItemCreator.crItemArmor(zombie.getEquipment().getHelmet().getType(), 1, ChatColor.translateAlternateColorCodes('&', m.getMessage("changeHelmetType")), false));
			ItemCreator.fillInvWithDarkGlass(inv8);
			p.openInventory(inv8);
			break;
			
		case SPIDER:
			Inventory inv9 = Bukkit.createInventory(null, 9*1, ChatColor.translateAlternateColorCodes('&', m.getMessage("advancedPetOptions")));
			ItemCreator.fillInvWithDarkGlass(inv9);
			p.openInventory(inv9);
			break;
			
		case IRONGOLEM:
			Inventory inv10 = Bukkit.createInventory(null, 9*1, ChatColor.translateAlternateColorCodes('&', m.getMessage("advancedPetOptions")));
			ItemCreator.fillInvWithDarkGlass(inv10);
			p.openInventory(inv10);
			break;
			
		case WITCH:
			Inventory inv11 = Bukkit.createInventory(null, 9*1, ChatColor.translateAlternateColorCodes('&', m.getMessage("advancedPetOptions")));
			ItemCreator.fillInvWithDarkGlass(inv11);
			p.openInventory(inv11);
			break;
			
		case BLAZE:
			Inventory inv12 = Bukkit.createInventory(null, 9*1, ChatColor.translateAlternateColorCodes('&', m.getMessage("advancedPetOptions")));
			ItemCreator.fillInvWithDarkGlass(inv12);
			p.openInventory(inv12);
			break;
			
		case ENDERMAN:
			Inventory inv13 = Bukkit.createInventory(null, 9*1, ChatColor.translateAlternateColorCodes('&', m.getMessage("advancedPetOptions")));
			ItemCreator.fillInvWithDarkGlass(inv13);
			p.openInventory(inv13);
			break;
			
		case WOLF:
			Wolf wolf = (Wolf) PetManager.playerPets.get(p);
			Inventory inv14 = Bukkit.createInventory(null, 9*1, ChatColor.translateAlternateColorCodes('&', m.getMessage("advancedPetOptions")));
			
			if(wolf.isAdult()) {inv14.setItem(0, ItemCreator.crItem(Material.WHEAT, 1, changeAge));} else {inv14.setItem(0, ItemCreator.crItem(Material.SEEDS, 1, changeAge));}
			if(!wolf.isSitting()) {inv14.setItem(1, ItemCreator.crItem(Material.WOOD_STAIRS, 1, ChatColor.translateAlternateColorCodes('&', m.getMessage("changeSitting"))));} 
				else {inv14.setItem(1, ItemCreator.crItem(Material.WOOD_STAIRS, 1, (short) 0, ChatColor.translateAlternateColorCodes('&', m.getMessage("changeSitting")), true, true));}
			if(!wolf.isTamed()) {inv14.setItem(2, ItemCreator.crItem(Material.COOKED_FISH, 1, ChatColor.translateAlternateColorCodes('&', m.getMessage("changeTamed"))));} 
				else {inv14.setItem(2, ItemCreator.crItem(Material.COOKED_FISH, 1, (short) 0, ChatColor.translateAlternateColorCodes('&', m.getMessage("changeTamed")), true, true));}
			inv14.setItem(3, ItemCreator.crItemWool(1, ChatColor.translateAlternateColorCodes('&', m.getMessage("changeColor")), wolf.getCollarColor()));
			
			ItemCreator.fillInvWithDarkGlass(inv14);
			p.openInventory(inv14);
			break;
			
		case SNOWMAN:
			Inventory inv15 = Bukkit.createInventory(null, 9*1, ChatColor.translateAlternateColorCodes('&', m.getMessage("advancedPetOptions")));
			ItemCreator.fillInvWithDarkGlass(inv15);
			p.openInventory(inv15);
			break;
			
		case MUSHROOMCOW:
			MushroomCow mushroomcow = (MushroomCow) PetManager.playerPets.get(p);
			Inventory inv16 = Bukkit.createInventory(null, 9*1, ChatColor.translateAlternateColorCodes('&', m.getMessage("advancedPetOptions")));
			if(mushroomcow.isAdult()) {inv16.setItem(0, ItemCreator.crItem(Material.WHEAT, 1, changeAge));} else {inv16.setItem(0, ItemCreator.crItem(Material.SEEDS, 1, changeAge));}
			ItemCreator.fillInvWithDarkGlass(inv16);
			p.openInventory(inv16);
			break;
			
		case SILVERFISH:
			Inventory inv17 = Bukkit.createInventory(null, 9*1, ChatColor.translateAlternateColorCodes('&', m.getMessage("advancedPetOptions")));
			ItemCreator.fillInvWithDarkGlass(inv17);
			p.openInventory(inv17);
			break;
			
		case CAVESPIDER:
			Inventory inv18 = Bukkit.createInventory(null, 9*1, ChatColor.translateAlternateColorCodes('&', m.getMessage("advancedPetOptions")));
			ItemCreator.fillInvWithDarkGlass(inv18);
			p.openInventory(inv18);
			break;
			
		default:
			break;
		}
	}

	public static void openPetOptionsBuyInv(Player p) {
		Inventory inv = Bukkit.createInventory(null, 9*1, ChatColor.translateAlternateColorCodes('&', m.getMessage("petOptionsConfirmation")));
		
		inv.setItem(2, ItemCreator.crItem(Material.EMERALD, 1, ChatColor.translateAlternateColorCodes('&', m.getMessage("accept"))));
		inv.setItem(6, ItemCreator.crItem(Material.REDSTONE, 1, ChatColor.translateAlternateColorCodes('&', m.getMessage("abort"))));
		
		inv.setItem(4, ItemCreator.crItem(Material.NETHER_STAR, 1, ChatColor.translateAlternateColorCodes('&', m.getMessage("advancedPetOptions")) 
				+ " �7(�e" + petOptionsBuyP.get(p).getOptionCost() + " " + m.coinName + "�7)"));
		
		// fills the inventory with dark glasspanes
		for(int i = 0; i < inv.getSize(); i++) {
			if(inv.getItem(i) == null) {
				inv.setItem(i, ItemCreator.crItem(Material.STAINED_GLASS_PANE, 1, (short) 7, " "));
			}
		}
		p.openInventory(inv);
	}
	
	@EventHandler
	public void onPetOptionsBuyInvClick(InventoryClickEvent e) {
		Player p = (Player) e.getWhoClicked();
		
		if(e.getClickedInventory() != null && e.getClickedInventory().getTitle().contains(ChatColor.translateAlternateColorCodes('&', m.getMessage("petOptionsConfirmation")))) {
			e.setCancelled(true);
			
			Pet pet = petOptionsBuyP.get(p);
			
			if(e.getCurrentItem().getType() == Material.EMERALD) {
				int cost = pet.getOptionCost();
				if(CoinAPI.getCoins(p.getUniqueId()) >= cost) {
					
					CoinAPI.removeCoins(p.getUniqueId(), cost);
					MySQLPet.setHasPetOptions(p.getUniqueId(), pet, true);
					petOptionsBuyP.remove(p);
					p.closeInventory();
					SBManager.updateLobbySB(p);
					
					String msg = m.getMessage("unlockPetOptions").replace("[prefix]", m.prefix).replace("[pet]", pet.getDisplayname());
					p.sendMessage(ChatColor.translateAlternateColorCodes('&', msg));
					
				} else {
					// player hasn't enought coins
					petOptionsBuyP.remove(p);
					p.closeInventory();
					String msg = m.getMessage("notEnoughtCoins").replace("[prefix]", m.prefix).replace("[coinname]", m.coinName);
					p.sendMessage(ChatColor.translateAlternateColorCodes('&', msg));
				}
				
			} else if(e.getCurrentItem().getType() == Material.REDSTONE) {
				p.closeInventory();
				petOptionsBuyP.remove(p);
				PetInteractListener.openPetOptions(p, pet);
			}
			
		}
	}
	
}
