package lukkySpins;

import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;

import lobbySystem.Main;
import mysql.MySQLBoots;
import mysql.MySQLLuckySpin;
import mysql.MySQLPet;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.inventory.Inventory;

import pets.Pet;
import utils.ItemCreator;
import utils.SBManager;
import boots.Boot;
import coinAPI.CoinAPI;

public class LuckySpinManager implements Listener {

	private static Main m = Main.getMain();
	private static HashMap<Player, ArrayList<Rewards>> playerRewards = new HashMap<Player, ArrayList<Rewards>>();
	
	public static ArrayList<Rewards> randomRewards() {
		Rewards[] rewards = Rewards.values();
		ArrayList<Rewards> returnRewards = new ArrayList<Rewards>();
		HashMap<Rewards, Integer> used = new HashMap<Rewards, Integer>();
 		
		int count = 0;
		for(int i = 0; i < rewards.length; i++) {
			count += rewards[i].getChance();
		}
		
		Random r = new Random();
		int i = 0;
		while(i < count) {
			Rewards rew = rewards[r.nextInt(rewards.length)];
			
			if(!used.containsKey(rew)) {
				used.put(rew, 0);
			}
			
			if(used.get(rew) != rew.getChance()) {
				returnRewards.add(rew);
				used.replace(rew, used.get(rew) + 1);
				i++;
			}
		}
		return returnRewards;
	}
	
	public static void openLuckySpinInv(Player p) {
		if(playerRewards.containsKey(p)) {
			playerRewards.remove(p);
		}
		ArrayList<Rewards> rewards = randomRewards();
		playerRewards.put(p, rewards);
		Inventory inv = Bukkit.createInventory(null, 9*3, ChatColor.translateAlternateColorCodes('&', m.getMessage("luckySpin")));
		
		inv.setItem(0, ItemCreator.crItem(Material.STAINED_GLASS_PANE, 1, (short) 14, " "));
		inv.setItem(1, ItemCreator.crItem(Material.STAINED_GLASS_PANE, 1, (short) 14, " "));
		inv.setItem(2, ItemCreator.crItem(Material.STAINED_GLASS_PANE, 1, (short) 14, " "));
		inv.setItem(3, ItemCreator.crItem(Material.STAINED_GLASS_PANE, 1, (short) 14, " "));
		inv.setItem(4, ItemCreator.crItem(Material.STAINED_GLASS_PANE, 1, (short) 5, " "));
		inv.setItem(5, ItemCreator.crItem(Material.STAINED_GLASS_PANE, 1, (short) 14, " "));
		inv.setItem(6, ItemCreator.crItem(Material.STAINED_GLASS_PANE, 1, (short) 14, " "));
		inv.setItem(7, ItemCreator.crItem(Material.STAINED_GLASS_PANE, 1, (short) 14, " "));
		inv.setItem(8, ItemCreator.crItem(Material.STAINED_GLASS_PANE, 1, (short) 14, " "));
		
		inv.setItem(9, rewards.get(0).getItem());
		inv.setItem(10, rewards.get(1).getItem());
		inv.setItem(11, rewards.get(2).getItem());
		inv.setItem(12, rewards.get(3).getItem());
		inv.setItem(13, rewards.get(4).getItem());
		inv.setItem(14, rewards.get(5).getItem());
		inv.setItem(15, rewards.get(6).getItem());
		inv.setItem(16, rewards.get(7).getItem());
		inv.setItem(17, rewards.get(8).getItem());
		
		inv.setItem(18, ItemCreator.crItem(Material.STAINED_GLASS_PANE, 1, (short) 14, " "));
		inv.setItem(19, ItemCreator.crItem(Material.STAINED_GLASS_PANE, 1, (short) 14, " "));
		inv.setItem(20, ItemCreator.crItem(Material.STAINED_GLASS_PANE, 1, (short) 14, " "));
		inv.setItem(21, ItemCreator.crItem(Material.STAINED_GLASS_PANE, 1, (short) 14, " "));
		inv.setItem(22, ItemCreator.crItem(Material.STAINED_GLASS_PANE, 1, (short) 5, " "));
		inv.setItem(23, ItemCreator.crItem(Material.STAINED_GLASS_PANE, 1, (short) 14, " "));
		inv.setItem(24, ItemCreator.crItem(Material.STAINED_GLASS_PANE, 1, (short) 14, " "));
		inv.setItem(25, ItemCreator.crItem(Material.STAINED_GLASS_PANE, 1, (short) 14, " "));
		inv.setItem(26, ItemCreator.crItem(Material.STAINED_GLASS_PANE, 1, (short) 14, " "));
		
		rewardListIndex.put(p, 9);
		timeNeedForInvUpdate.put(p, 1);
		timeHaveForInvUpdate.put(p, 0);
		spinPlayers.add(p);
		
		p.openInventory(inv);
	}
	
	public static HashMap<Player, Integer> rewardListIndex = new HashMap<Player, Integer>();
	public static HashMap<Player, Integer> timeNeedForInvUpdate = new HashMap<Player, Integer>();
	public static HashMap<Player, Integer> timeHaveForInvUpdate = new HashMap<Player, Integer>();
	public static ArrayList<Player> spinPlayers = new ArrayList<Player>();
	
	public static void startLuckySpinScheduler() {
		ArrayList<Player> removePlayers = new ArrayList<Player>();
		Bukkit.getScheduler().scheduleSyncRepeatingTask(m, new Runnable() {
			
			@Override
			public void run() {
				for(Player all : spinPlayers) {
					timeHaveForInvUpdate.replace(all, timeHaveForInvUpdate.get(all) + 1);
					
					if(timeHaveForInvUpdate.get(all) >= timeNeedForInvUpdate.get(all)) {
						timeHaveForInvUpdate.replace(all, 0);
						rewardListIndex.replace(all, rewardListIndex.get(all) + 1);
						updatePlayerInvs(all, false);
						
						if(rewardListIndex.get(all) >= 50) {
							timeNeedForInvUpdate.replace(all, timeNeedForInvUpdate.get(all) + 1);
						}	
						if(rewardListIndex.get(all) >= 60) {
							timeNeedForInvUpdate.replace(all, timeNeedForInvUpdate.get(all) + 3);
						}						
						
						if(timeNeedForInvUpdate.get(all) >= 30) {
							removePlayers.add(all);
						}
					}
				}
				for(Player rp : removePlayers) {
					updatePlayerInvs(rp, true);
					timeHaveForInvUpdate.remove(rp);
					timeNeedForInvUpdate.remove(rp);
					spinPlayers.remove(rp);
					rp.playSound(rp.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 3, 2);
				}
				removePlayers.clear();
			}
			
		}, 1, 1);
	}
	
	public static void updatePlayerInvs(Player p, boolean finish) {
		if(finish) {
			int wonIndex = rewardListIndex.get(p) - 4;
			Inventory inv = p.getOpenInventory().getTopInventory();
			inv.setItem(0, ItemCreator.crItem(Material.STAINED_GLASS_PANE, 1, (short) 5, " "));
			inv.setItem(1, ItemCreator.crItem(Material.STAINED_GLASS_PANE, 1, (short) 5, " "));
			inv.setItem(2, ItemCreator.crItem(Material.STAINED_GLASS_PANE, 1, (short) 5, " "));
			inv.setItem(3, ItemCreator.crItem(Material.STAINED_GLASS_PANE, 1, (short) 5, " "));
			inv.setItem(4, ItemCreator.crItem(Material.STAINED_GLASS_PANE, 1, (short) 14, " "));
			inv.setItem(5, ItemCreator.crItem(Material.STAINED_GLASS_PANE, 1, (short) 5, " "));
			inv.setItem(6, ItemCreator.crItem(Material.STAINED_GLASS_PANE, 1, (short) 5, " "));
			inv.setItem(7, ItemCreator.crItem(Material.STAINED_GLASS_PANE, 1, (short) 5, " "));
			inv.setItem(8, ItemCreator.crItem(Material.STAINED_GLASS_PANE, 1, (short) 5, " "));
				
			inv.setItem(9, ItemCreator.crItem(Material.STAINED_GLASS_PANE, 1, (short) 5, " "));
			inv.setItem(10, ItemCreator.crItem(Material.STAINED_GLASS_PANE, 1, (short) 14, " "));
			inv.setItem(11, ItemCreator.crItem(Material.STAINED_GLASS_PANE, 1, (short) 14, " "));
			inv.setItem(12, ItemCreator.crItem(Material.STAINED_GLASS_PANE, 1, (short) 14, " "));
			inv.setItem(13, playerRewards.get(p).get(wonIndex).getItem());
			inv.setItem(14, ItemCreator.crItem(Material.STAINED_GLASS_PANE, 1, (short) 14, " "));
			inv.setItem(15, ItemCreator.crItem(Material.STAINED_GLASS_PANE, 1, (short) 14, " "));
			inv.setItem(16, ItemCreator.crItem(Material.STAINED_GLASS_PANE, 1, (short) 14, " "));
			inv.setItem(17, ItemCreator.crItem(Material.STAINED_GLASS_PANE, 1, (short) 5, " "));
				
			inv.setItem(18, ItemCreator.crItem(Material.STAINED_GLASS_PANE, 1, (short) 5, " "));
			inv.setItem(19, ItemCreator.crItem(Material.STAINED_GLASS_PANE, 1, (short) 5, " "));
			inv.setItem(20, ItemCreator.crItem(Material.STAINED_GLASS_PANE, 1, (short) 5, " "));
			inv.setItem(21, ItemCreator.crItem(Material.STAINED_GLASS_PANE, 1, (short) 5, " "));
			inv.setItem(22, ItemCreator.crItem(Material.STAINED_GLASS_PANE, 1, (short) 14, " "));
			inv.setItem(23, ItemCreator.crItem(Material.STAINED_GLASS_PANE, 1, (short) 5, " "));
			inv.setItem(24, ItemCreator.crItem(Material.STAINED_GLASS_PANE, 1, (short) 5, " "));
			inv.setItem(25, ItemCreator.crItem(Material.STAINED_GLASS_PANE, 1, (short) 5, " "));
			inv.setItem(26, ItemCreator.crItem(Material.STAINED_GLASS_PANE, 1, (short) 5, " "));
			
		} else { 
			ArrayList<Rewards> rewards = playerRewards.get(p);
			int rewardIndex = rewardListIndex.get(p);
				
			Inventory inv = p.getOpenInventory().getTopInventory();
			inv.setItem(0, ItemCreator.crItem(Material.STAINED_GLASS_PANE, 1, (short) 14, " "));
			inv.setItem(1, ItemCreator.crItem(Material.STAINED_GLASS_PANE, 1, (short) 14, " "));
			inv.setItem(2, ItemCreator.crItem(Material.STAINED_GLASS_PANE, 1, (short) 14, " "));
			inv.setItem(3, ItemCreator.crItem(Material.STAINED_GLASS_PANE, 1, (short) 14, " "));
			inv.setItem(4, ItemCreator.crItem(Material.STAINED_GLASS_PANE, 1, (short) 5, " "));
			inv.setItem(5, ItemCreator.crItem(Material.STAINED_GLASS_PANE, 1, (short) 14, " "));
			inv.setItem(6, ItemCreator.crItem(Material.STAINED_GLASS_PANE, 1, (short) 14, " "));
			inv.setItem(7, ItemCreator.crItem(Material.STAINED_GLASS_PANE, 1, (short) 14, " "));
			inv.setItem(8, ItemCreator.crItem(Material.STAINED_GLASS_PANE, 1, (short) 14, " "));
				
			inv.setItem(9, rewards.get(rewardIndex - 8).getItem());
			inv.setItem(10, rewards.get(rewardIndex - 7).getItem());
			inv.setItem(11, rewards.get(rewardIndex - 6).getItem());
			inv.setItem(12, rewards.get(rewardIndex - 5).getItem());
			inv.setItem(13, rewards.get(rewardIndex - 4).getItem());
			inv.setItem(14, rewards.get(rewardIndex - 3).getItem());
			inv.setItem(15, rewards.get(rewardIndex - 2).getItem());
			inv.setItem(16, rewards.get(rewardIndex - 1).getItem());
			inv.setItem(17, rewards.get(rewardIndex - 0).getItem());
				
			inv.setItem(18, ItemCreator.crItem(Material.STAINED_GLASS_PANE, 1, (short) 14, " "));
			inv.setItem(19, ItemCreator.crItem(Material.STAINED_GLASS_PANE, 1, (short) 14, " "));
			inv.setItem(20, ItemCreator.crItem(Material.STAINED_GLASS_PANE, 1, (short) 14, " "));
			inv.setItem(21, ItemCreator.crItem(Material.STAINED_GLASS_PANE, 1, (short) 14, " "));
			inv.setItem(22, ItemCreator.crItem(Material.STAINED_GLASS_PANE, 1, (short) 5, " "));
			inv.setItem(23, ItemCreator.crItem(Material.STAINED_GLASS_PANE, 1, (short) 14, " "));
			inv.setItem(24, ItemCreator.crItem(Material.STAINED_GLASS_PANE, 1, (short) 14, " "));
			inv.setItem(25, ItemCreator.crItem(Material.STAINED_GLASS_PANE, 1, (short) 14, " "));
			inv.setItem(26, ItemCreator.crItem(Material.STAINED_GLASS_PANE, 1, (short) 14, " "));
				
			p.playSound(p.getLocation(), Sound.BLOCK_NOTE_PLING, 3, 2);
		}
	}
	
	@EventHandler
	public void onInvClose(InventoryCloseEvent e) {
		Player p = (Player) e.getPlayer();
		
		if(e.getInventory().getTitle().equals(ChatColor.translateAlternateColorCodes('&', m.getMessage("luckySpin")))) {
			if(!spinPlayers.contains(p)) {
				Rewards reward = playerRewards.get(p).get(rewardListIndex.get(p) - 4);					
				
				switch (reward) {
				case NOTHING:
					break;
					
				case COINS1:
					CoinAPI.addCoins(p.getUniqueId(), reward.getCoinValue());
					SBManager.updateLobbySB(p);
					break;
					
				case COINS2:
					CoinAPI.addCoins(p.getUniqueId(), reward.getCoinValue());
					SBManager.updateLobbySB(p);
					break;
					
				case COINS3:
					CoinAPI.addCoins(p.getUniqueId(), reward.getCoinValue());
					SBManager.updateLobbySB(p);
					break;
				
				case COINS4:
					CoinAPI.addCoins(p.getUniqueId(), reward.getCoinValue());
					SBManager.updateLobbySB(p);			
					break;
							
				case COINS5:
					CoinAPI.addCoins(p.getUniqueId(), reward.getCoinValue());
					SBManager.updateLobbySB(p);
					break;
				
				case COW:
					if(MySQLPet.hasPet(p.getUniqueId(), Pet.COW)) {
						CoinAPI.addCoins(p.getUniqueId(), reward.getCoinValue());
						SBManager.updateLobbySB(p);
					} else {
						MySQLPet.addPetToPlayer(p.getUniqueId(), Pet.COW, false);
					}
					break;
				
				case CHICKEN:
					if(MySQLPet.hasPet(p.getUniqueId(), Pet.CHICKEN)) {
						CoinAPI.addCoins(p.getUniqueId(), reward.getCoinValue());
						SBManager.updateLobbySB(p);
					} else {
						MySQLPet.addPetToPlayer(p.getUniqueId(), Pet.CHICKEN, false);
					}
					break;
				
				case ZOMBIE:
					if(MySQLPet.hasPet(p.getUniqueId(), Pet.ZOMBIE)) {
						CoinAPI.addCoins(p.getUniqueId(), reward.getCoinValue());
						SBManager.updateLobbySB(p);
					} else {
						MySQLPet.addPetToPlayer(p.getUniqueId(), Pet.ZOMBIE, false);
					}
					break;
				
				case MUSICBOOTS:
					if(MySQLBoots.hasBoot(p.getUniqueId(), Boot.MUSICBOOTS)) {
						CoinAPI.addCoins(p.getUniqueId(), reward.getCoinValue());
						SBManager.updateLobbySB(p);
					} else {
						MySQLBoots.addBootToPlayer(p.getUniqueId(), Boot.MUSICBOOTS);
					}
					break;
				
				case MAGICBOOTS:
					if(MySQLBoots.hasBoot(p.getUniqueId(), Boot.MAGICBOOTS)) {
						CoinAPI.addCoins(p.getUniqueId(), reward.getCoinValue());
						SBManager.updateLobbySB(p);
					} else {
						MySQLBoots.addBootToPlayer(p.getUniqueId(), Boot.MAGICBOOTS);
					}
					break;
			
				default:
					break;
				}
						
				rewardListIndex.remove(p);
				playerRewards.remove(p);
				
			} else {
				timeHaveForInvUpdate.remove(p);
				timeNeedForInvUpdate.remove(p);
				spinPlayers.remove(p);
				rewardListIndex.remove(p);
				playerRewards.remove(p);
			}
		}
	}
	
	public static boolean hasSpin(Player p) {
		Date date = MySQLLuckySpin.getNextSpinTime(p.getUniqueId());
		if(date.before(Date.valueOf(LocalDate.now())) || date.equals(Date.valueOf(LocalDate.now()))) {
			return true;
		}
		return false;
	}
	
	public static void sendAvailableSpinMsg(Player p) {
		if(p.hasPermission(m.getPermission("luckySpinTimeBypass"))) {
			String msg = m.getMessage("unlimitedSpins").replace("[prefix]", m.prefix);
			p.sendMessage(ChatColor.translateAlternateColorCodes('&', msg));
			
		} else if(hasSpin(p)) {
			String msg = m.getMessage("hasSpin").replace("[prefix]", m.prefix);
			p.sendMessage(ChatColor.translateAlternateColorCodes('&', msg));
			
		} else {
			String msg = m.getMessage("noSpin").replace("[prefix]", m.prefix);
			p.sendMessage(ChatColor.translateAlternateColorCodes('&', msg));
		}
	}
	
}
