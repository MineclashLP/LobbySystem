package lukkySpins;

import lobbySystem.Main;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.EntityType;
import org.bukkit.inventory.ItemStack;

import pets.Pet;
import utils.ItemCreator;
import boots.Boot;

public enum Rewards {

	NOTHING(ItemCreator.crItem(Material.BARRIER, 1, "�4-----"), 30, 0),
	COINS1(ItemCreator.crItem(Material.EMERALD, 1, "�620 " + Main.getMain().coinName), 20, 20),
	COINS2(ItemCreator.crItem(Material.EMERALD, 2, "�650 " + Main.getMain().coinName), 20, 50),
	COINS3(ItemCreator.crItem(Material.EMERALD, 3, "�6100 " + Main.getMain().coinName), 5, 100),
	COINS4(ItemCreator.crItem(Material.EMERALD, 4, "�6120 " + Main.getMain().coinName), 10, 120),
	COINS5(ItemCreator.crItem(Material.EMERALD, 5, "�6150 " + Main.getMain().coinName), 20, 150),
	COW(ItemCreator.crItemSpawnEgg(1, ChatColor.translateAlternateColorCodes('&', Main.getMain().getMessage("cow")), EntityType.COW), 8, Pet.COW.getCost()),
	CHICKEN(ItemCreator.crItemSpawnEgg(1, ChatColor.translateAlternateColorCodes('&', Main.getMain().getMessage("chicken")), EntityType.CHICKEN), 7, Pet.CHICKEN.getCost()),
	ZOMBIE(ItemCreator.crItemSpawnEgg(1, ChatColor.translateAlternateColorCodes('&', Main.getMain().getMessage("zombie")), EntityType.ZOMBIE), 5, Pet.ZOMBIE.getCost()),
	MUSICBOOTS(ItemCreator.crItemLeatherArmor(Boot.MUSICBOOTS.getMaterial(), 1, Boot.MUSICBOOTS.getDisplayname(), true, Boot.MUSICBOOTS.getColor()), 8, Boot.MUSICBOOTS.getCost()),
	MAGICBOOTS(ItemCreator.crItemLeatherArmor(Boot.MAGICBOOTS.getMaterial(), 1, Boot.MAGICBOOTS.getDisplayname(), true, Boot.MAGICBOOTS.getColor()), 11, Boot.MAGICBOOTS.getCost());
	
	private ItemStack item;
	private int chance;
	private int coinValue;
	
	private Rewards(ItemStack item, int chance, int coinValue) {
		this.item = item;
		this.chance = chance;
		this.coinValue = coinValue;
	}
	
	public ItemStack getItem() {
		return item;
	}
	
	public int getChance() {
		return chance;
	}
	
	public int getCoinValue() {
		return coinValue;
	}
	
}
