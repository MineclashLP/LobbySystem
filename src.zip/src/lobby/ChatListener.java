package lobby;

import lobbySystem.Main;

import org.bukkit.ChatColor;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;

import pets.PetManager;
import pets.PetOptionsMenueManager;

public class ChatListener implements Listener {

	@EventHandler
	public void onChat(AsyncPlayerChatEvent e) {
		
		if(PetOptionsMenueManager.petRenameP.contains(e.getPlayer())) {
			e.setCancelled(true);
			PetManager.setPetName(e.getPlayer(), ChatColor.translateAlternateColorCodes('&', e.getMessage()));
			
			PetOptionsMenueManager.petRenameP.remove(e.getPlayer());
			
			String msg = Main.getMain().getMessage("petRenamed").replace("[prefix]", Main.getMain().prefix).replace("[name]", ChatColor.translateAlternateColorCodes('&', e.getMessage()));
			e.getPlayer().sendMessage(ChatColor.translateAlternateColorCodes('&', msg));
		}
		
		e.setFormat(e.getPlayer().getDisplayName() + " �8>> �f" + e.getMessage());
	}
	
}
