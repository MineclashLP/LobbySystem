package lobby;

import lobbySystem.Main;

import org.bukkit.Effect;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.util.Vector;

public class Jumppads implements Listener {

	@EventHandler
	public void onMove(PlayerMoveEvent e) {
		Player p = e.getPlayer();
		
		if(Main.getMain().getConfigValueBoolean("Jumppads")) {
			if(p.getLocation().getBlock().getType() == Material.STONE_PLATE || p.getLocation().getBlock().getType() == Material.GOLD_PLATE ||
					p.getLocation().getBlock().getType() == Material.IRON_PLATE || p.getLocation().getBlock().getType() == Material.WOOD_PLATE) {
				
				Vector v = p.getLocation().getDirection().multiply(3D).setY(1D);
				p.setVelocity(v);
				p.getWorld().playEffect(p.getLocation(), Effect.ENDER_SIGNAL, 3);
				p.playSound(p.getLocation(), Sound.ENTITY_ENDERDRAGON_FLAP, 3, 2);
			}
		}
		
	}
	
}
