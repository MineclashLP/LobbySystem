package boots;

import gadgets.GadgetManager;
import gadgets.GadgetPlayer;

import java.util.HashMap;

import lobbySystem.Main;
import mysql.MySQLBoots;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;

import utils.ItemCreator;
import utils.SBManager;
import coinAPI.CoinAPI;

public class BootManager implements Listener {

	private static Main m = Main.getMain();
	private static HashMap<Player, Boot> bootBuy = new HashMap<Player, Boot>();
	
	public static void openBootsInv(Player p) {
		Inventory inv = Bukkit.createInventory(null, 9*3, "�6Boots");
		
		Boot[] boots = Boot.values();
		for(int i = 0; i < boots.length; i++) {
			if(boots[i].isPermission()) {
				if(p.hasPermission(m.getPermission("specialBoots"))) {
					if(!MySQLBoots.hasBoot(p.getUniqueId(), boots[i])) {
						if(boots[i].getMaterial() == Material.LEATHER_BOOTS) {
							inv.setItem(boots[i].getId(), ItemCreator.crItemLeatherArmor(boots[i].getMaterial(), 1, 
									boots[i].getDisplayname() + " �7(�e" + boots[i].getCost() + " " + m.coinName + "�7)", true, boots[i].getColor()));
						} else {
							inv.setItem(boots[i].getId(), ItemCreator.crItemArmor(boots[i].getMaterial(), 1, 
									boots[i].getDisplayname() + " �7(�e" + boots[i].getCost()+ " " + m.coinName + "�7)", true));
						}
					} else {
						if(boots[i].getMaterial() == Material.LEATHER_BOOTS) {
							inv.setItem(boots[i].getId(), ItemCreator.crItemLeatherArmor(boots[i].getMaterial(), 1, 
									boots[i].getDisplayname() + " �7(" + ChatColor.translateAlternateColorCodes('&', m.getMessage("buyed")) + "�7)", true, boots[i].getColor()));
						} else {
							inv.setItem(boots[i].getId(), ItemCreator.crItemArmor(boots[i].getMaterial(), 1, boots[i].getDisplayname() + " �7(" + 
									ChatColor.translateAlternateColorCodes('&', m.getMessage("buyed")) + "�7)", true));
						}
					}
					
				} else {
					// the player hasn't the permission
					if(boots[i].getMaterial() == Material.LEATHER_BOOTS) {
						inv.setItem(boots[i].getId(), ItemCreator.crItemLeatherArmor(boots[i].getMaterial(), 1, 
								boots[i].getDisplayname() + " �7(�e" + ChatColor.translateAlternateColorCodes('&', m.getMessage("notAvailable")) + "�7)", true, boots[i].getColor()));
					} else {
						inv.setItem(boots[i].getId(), ItemCreator.crItemArmor(boots[i].getMaterial(), 1, 
								boots[i].getDisplayname() + " �7(�e" + boots[i].getCost()+ " " + m.coinName + "�7)", true));
					}
				}
				
			} else {
				if(!MySQLBoots.hasBoot(p.getUniqueId(), boots[i])) {
					if(boots[i].getMaterial() == Material.LEATHER_BOOTS) {
						inv.setItem(boots[i].getId(), ItemCreator.crItemLeatherArmor(boots[i].getMaterial(), 1, 
								boots[i].getDisplayname() + " �7(�e" + boots[i].getCost()  + " " + m.coinName + "�7)", true, boots[i].getColor()));
					} else {
						inv.setItem(boots[i].getId(), ItemCreator.crItemArmor(boots[i].getMaterial(), 1, boots[i].getDisplayname() + " �7(" + 
								boots[i].getDisplayname() + " �7(�e" + boots[i].getCost()  + " " + m.coinName + "�7)", true));
					}
				} else {
					if(boots[i].getMaterial() == Material.LEATHER_BOOTS) {
						inv.setItem(boots[i].getId(), ItemCreator.crItemLeatherArmor(boots[i].getMaterial(), 1, 
								boots[i].getDisplayname() + " �7(" + ChatColor.translateAlternateColorCodes('&', m.getMessage("buyed")) + "�7)", true, boots[i].getColor()));
					} else {
						inv.setItem(boots[i].getId(), ItemCreator.crItemArmor(boots[i].getMaterial(), 1, boots[i].getDisplayname() + " �7(" + 
								ChatColor.translateAlternateColorCodes('&', m.getMessage("buyed")) + "�7)", true));
					}
				}
			}
		}
		
		inv.setItem(9*2 + 4, ItemCreator.crItem(Material.BARRIER, 1, ChatColor.translateAlternateColorCodes('&', m.getMessage("removeBoots"))));
		
		// fills the inventory with dark glasspanes
		for(int i = 0; i < inv.getSize(); i++) {
			if(inv.getItem(i) == null) {
				inv.setItem(i, ItemCreator.crItem(Material.STAINED_GLASS_PANE, 1, (short) 7, " "));
			}
		}
		p.openInventory(inv);
	}
	
	
	@EventHandler
	public void onBootInvClick(InventoryClickEvent e) {
		Player p = (Player) e.getWhoClicked();
		
		if(e.getClickedInventory() != null && e.getClickedInventory().getTitle().equals("�6Boots")) {
			e.setCancelled(true);
			
			Boot boot = null;
			for(int i = 0; i < Boot.values().length; i++) {
				if(Boot.values()[i].getId() == e.getSlot()) {
					boot = Boot.values()[i];
				}
			}
			
			if(boot != null) {
				if(boot.isPermission()) {
					if(!p.hasPermission(m.getPermission("specialBoots"))) {
						return;
					}
				}
				if(!MySQLBoots.hasBoot(p.getUniqueId(), boot)) {
					p.closeInventory();
					p.openInventory(getBootBuyAcceptInv(boot));
					
					if(bootBuy.containsKey(p)) {
						bootBuy.remove(p);
					}
					bootBuy.put(p, boot);
					
				} else {
					if(!GadgetPlayer.discoPlayers.containsKey(p)) {
						// player activate the boots and gets the boots
						BootPlayer.setPlayerBoots(p, boot);
						p.closeInventory();
						
						String msg = m.getMessage("pSetBoots").replace("[prefix]", m.prefix).replace("[boots]", boot.getDisplayname());
						p.sendMessage(ChatColor.translateAlternateColorCodes('&', msg));
						
					} else {
						String msg = m.getMessage("wearDiscoArmor").replace("[prefix]", m.prefix).replace("[discoarmor]", GadgetManager.playerGadgets.get(p).getDisplayname());
						p.sendMessage(ChatColor.translateAlternateColorCodes('&', msg));
						p.closeInventory();
						return;
					}
				}
				
			} else {
				if(e.getCurrentItem().getType() == Material.BARRIER) {
					if(BootPlayer.equippedBoots.containsKey(p)) {
						p.getInventory().setBoots(null);
						BootPlayer.equippedBoots.remove(p);
						p.closeInventory();
					}
				}
			}
		}
	}
	
	public static Inventory getBootBuyAcceptInv(Boot boot) {
		Inventory inv = Bukkit.createInventory(null, 9*1, boot.getDisplayname() + " �7- " + ChatColor.translateAlternateColorCodes('&', m.getMessage("bootConfirmation")));
		
		inv.setItem(2, ItemCreator.crItem(Material.EMERALD, 1, ChatColor.translateAlternateColorCodes('&', m.getMessage("accept"))));
		inv.setItem(6, ItemCreator.crItem(Material.REDSTONE, 1, ChatColor.translateAlternateColorCodes('&', m.getMessage("abort"))));
		
		if(boot.getMaterial() == Material.LEATHER_BOOTS) {
			inv.setItem(4, ItemCreator.crItemLeatherArmor(boot.getMaterial(), 1, boot.getDisplayname() + " �7(�e" + boot.getCost()  + " " + m.coinName + "�7)", true, boot.getColor()));
		} else {
			inv.setItem(4, ItemCreator.crItemArmor(boot.getMaterial(), 1, boot.getDisplayname() + " �7(�e" + boot.getCost()  + " " + m.coinName + "�7)", true));
		}
		
		// fills the inventory with dark glasspanes
		for(int i = 0; i < inv.getSize(); i++) {
			if(inv.getItem(i) == null) {
				inv.setItem(i, ItemCreator.crItem(Material.STAINED_GLASS_PANE, 1, (short) 7, " "));
			}
		}
		return inv;
	}

	
	@EventHandler
	public void onBootBuyInvClick(InventoryClickEvent e) {
		Player p = (Player) e.getWhoClicked();
		
		if(e.getClickedInventory() != null && e.getClickedInventory().getTitle().contains(ChatColor.translateAlternateColorCodes('&', m.getMessage("bootConfirmation")))) {
			e.setCancelled(true);
			
			Boot boot = bootBuy.get(p);
			bootBuy.remove(p);
			
			if(e.getCurrentItem() != null && e.getCurrentItem().getType() == Material.EMERALD) {
				int cost = boot.getCost();
				if(CoinAPI.getCoins(p.getUniqueId()) >= cost) {
					
					CoinAPI.removeCoins(p.getUniqueId(), cost);
					MySQLBoots.addBootToPlayer(p.getUniqueId(), boot);
					bootBuy.remove(p);
					p.closeInventory();
					SBManager.updateLobbySB(p);
					
					String msg = m.getMessage("unlockBoots").replace("[prefix]", m.prefix).replace("[boots]", boot.getDisplayname());
					p.sendMessage(ChatColor.translateAlternateColorCodes('&', msg));
					
				} else {
					// player hasn't enought coins
					bootBuy.remove(p);
					p.closeInventory();
					String msg = m.getMessage("notEnoughtCoins").replace("[prefix]", m.prefix).replace("[coinname]", m.coinName);
					p.sendMessage(ChatColor.translateAlternateColorCodes('&', msg));
				}
				
			} else if(e.getCurrentItem().getType() == Material.REDSTONE) {
				p.closeInventory();
				openBootsInv(p);
			}
			
		}
	}
	
	
}