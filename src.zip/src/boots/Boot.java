package boots;

import org.bukkit.Color;
import org.bukkit.Effect;
import org.bukkit.Material;

public enum Boot {

	@SuppressWarnings("deprecation")
	FIREBOOT(0, "�4Fireboots", 700, Material.LEATHER_BOOTS, Color.RED, false, Effect.FLAME, Effect.MOBSPAWNER_FLAMES),
	
	@SuppressWarnings("deprecation")
	ENDERBOOT(1, "�5Enderboots", 500, Material.LEATHER_BOOTS, Color.PURPLE, false, Effect.WITCH_MAGIC, Effect.ENDER_SIGNAL),
	
	@SuppressWarnings("deprecation")
	LOVEBOOTS(2, "�cLoveboots", 400, Material.LEATHER_BOOTS, Color.FUCHSIA, false, Effect.HEART, Effect.COLOURED_DUST),
	
	@SuppressWarnings("deprecation")
	MUSICBOOTS(3, "�bMusicboots", 350, Material.LEATHER_BOOTS, Color.AQUA, false, Effect.NOTE, Effect.NOTE),
	
	@SuppressWarnings("deprecation")
	RAINYBOOTS(4, "�9Rainyboots", 600, Material.LEATHER_BOOTS, Color.BLUE, false, Effect.WATERDRIP, Effect.SPLASH),
	
	@SuppressWarnings("deprecation")
	MAGICBOOTS(5, "�aMagicboots", 500, Material.LEATHER_BOOTS, Color.LIME, false, Effect.HAPPY_VILLAGER, Effect.FIREWORKS_SPARK),
	
	@SuppressWarnings("deprecation")
	LAVABOOTS(6, "�4Lavaboots", 1000, Material.LEATHER_BOOTS, Color.RED, false, Effect.LAVA_POP, Effect.LAVA_POP),
	
	@SuppressWarnings("deprecation")
	MYSTICBOOTS(7, "�5Mysticboots", 300, Material.LEATHER_BOOTS, Color.PURPLE, false, Effect.FLYING_GLYPH, Effect.FLYING_GLYPH),
	
	@SuppressWarnings("deprecation")
	ANGRYBOOTS(8, "�7Angryboots", 400, Material.LEATHER_BOOTS, Color.SILVER, false, Effect.VILLAGER_THUNDERCLOUD, Effect.EXPLOSION),
	
	
	
	@SuppressWarnings("deprecation")
	EXPLOSIONBOOTS(9, "�7Explosionboots", 1800, Material.LEATHER_BOOTS, Color.GRAY, true, Effect.EXPLOSION, Effect.EXPLOSION_HUGE),
	
	@SuppressWarnings("deprecation")
	MONEYBOOTS(10, "�6Moneyboots", 2000, Material.LEATHER_BOOTS, Color.ORANGE, true, Effect.FLAME, Effect.FLAME),
	
	@SuppressWarnings("deprecation")
	JETPACKBOOTS(11, "�7Jetpackboots", 2200, Material.LEATHER_BOOTS, Color.SILVER, true, Effect.SMOKE, Effect.FLAME),
	
	@SuppressWarnings("deprecation")
	BURNBOOTS(12, "�4Burnboots", 1500, Material.LEATHER_BOOTS, Color.RED, true, Effect.FLAME, null),
	
	@SuppressWarnings("deprecation")
	STEAKBOOTS(13, "�6Steakboots", 1800, Material.LEATHER_BOOTS, Color.MAROON, true, Effect.FLAME, Effect.LAVA_POP),
	
	@SuppressWarnings("deprecation")
	SHIELDBOOTS(14, "�7Shieldboots", 2000, Material.LEATHER_BOOTS, Color.BLACK, true, Effect.FLAME, null),
	
	@SuppressWarnings("deprecation")
	GHOSTBOOTS(15, "�fGhostboots", 1500, Material.LEATHER_BOOTS, Color.WHITE, true, Effect.EXPLOSION, null),
	
	@SuppressWarnings("deprecation")
	HOVERBOOTS(16, "�9Hoverboots", 1700, Material.LEATHER_BOOTS, Color.BLUE, true, Effect.CLOUD, Effect.FIREWORKS_SPARK),
	
	@SuppressWarnings("deprecation")
	SPEEDBOOTS(17, "�bSpeedboots", 2000, Material.LEATHER_BOOTS, Color.AQUA, true, Effect.SMOKE, Effect.HAPPY_VILLAGER);
	
	private int id;
	private String displayname;
	private int cost;
	private Material material;
	private Color color;
	private boolean permission;
	private Effect normalEffect;
	private Effect sneakEffect;
	
	
	private Boot(int id, String displayname, int cost, Material material, Color color, boolean permission, Effect normalEffect, Effect sneakEffect) {
		this.id = id;
		this.displayname = displayname;
		this.cost = cost;
		this.material = material;
		this.color = color;
		this.permission = permission;
		this.normalEffect = normalEffect;
		this.sneakEffect = sneakEffect;
	}

	public int getId() {
		return id;
	}
	
	public String getDisplayname() {
		return displayname;
	}

	public int getCost() {
		return cost;
	}
	
	public Material getMaterial() {
		return material;
	}
	
	public Color getColor() {
		return color;
	}

	public boolean isPermission() {
		return permission;
	}
	
	public Effect getNormalEffect() {
		return normalEffect;
	}
	
	public Effect getSneakEffect() {
		return sneakEffect;
	}
	
}
