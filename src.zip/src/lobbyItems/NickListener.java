package lobbyItems;

import java.util.Random;

import lobbySystem.Main;
import mysql.MySQLNickList;
import mysql.MySQLPet;

import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.entity.Player;

import pets.PetManager;
import rankAPI.RankAPI;

public class NickListener {

	private static Main m = Main.getMain();
	
	public static void nameTagClick(Player p) {
		try {
			if(isNicked(p)) {
				unnickPlayer(p);
				
				p.playSound(p.getLocation(), Sound.BLOCK_NOTE_PLING, 10, 1);
				
				String msg = m.getMessage("unnickPlayer").replace("[prefix]", m.prefix);
				p.sendMessage(ChatColor.translateAlternateColorCodes('&', msg));
				
			} else {
				String newName = getRandomNickname();
				
				MySQLNickList.setNamenow(p.getUniqueId(), newName);
				RankAPI.setRankToPlayer(p, newName);
				
				p.playSound(p.getLocation(), Sound.BLOCK_NOTE_PLING, 10, 1);
				
				if(PetManager.playerPets.containsKey(p)) {
					if(MySQLPet.getPetName(p.getUniqueId()).equals(p.getDisplayName()+ "�e's Pet")) {
						PetManager.setPetName(p, p.getDisplayName()+ "�e's Pet");
					}
				}
				
				String msg = m.getMessage("nickPlayer").replace("[prefix]", m.prefix).replace("[newname]", newName);
				p.sendMessage(ChatColor.translateAlternateColorCodes('&', msg));
			}
		} catch(NullPointerException e) {}
	}
	
	public static void unnickPlayer(Player p) {
		MySQLNickList.setNamenow(p.getUniqueId(), p.getName());
		RankAPI.setRankToPlayer(p, p.getName());
		
		if(PetManager.playerPets.containsKey(p)) {
			if(MySQLPet.getPetName(p.getUniqueId()).equals(p.getDisplayName()+ "�e's Pet")) {
				PetManager.setPetName(p, p.getDisplayName()+ "�e's Pet");
			}
		}
	}
	
	public static boolean isNicked(Player p) {
		if(!MySQLNickList.getNamenow(p.getUniqueId()).equals(p.getName()))
			return true;
		return false;
	}
	
	public static String getRandomNickname() {
		Random r = new Random();
		String name = MySQLNickList.getNames().get(r.nextInt(MySQLNickList.getNames().size()));
		return name;
	}

}
