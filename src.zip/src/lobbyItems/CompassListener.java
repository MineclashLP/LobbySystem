package lobbyItems;

import lobbySystem.Main;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;

import utils.ItemCreator;
import utils.WarpSystem;

public class CompassListener implements Listener {

	private static Main m = Main.getMain();
	
	public static void openCompassInv(Player p) {
		Inventory inv = Bukkit.createInventory(null, 9*3, ChatColor.translateAlternateColorCodes('&', m.getMessage("compass")));
		
		// sets the items in the inventory
		inv.setItem(10, ItemCreator.crItem(Material.STICK, 1, (short) 0, "�5Magicwars", true, true));
		inv.setItem(13, ItemCreator.crItem(Material.MAGMA_CREAM, 1, "�6Spawn"));
		inv.setItem(16, ItemCreator.crItem(Material.COOKED_CHICKEN, 1, "�4WE ARE HUNGRY!"));
		
		// fills the inventory with dark glasspanes
		for(int i = 0; i < inv.getSize(); i++) {
			if(inv.getItem(i) == null) {
				inv.setItem(i, ItemCreator.crItem(Material.STAINED_GLASS_PANE, 1, (short) 7, " "));
			}
		}
		
		p.openInventory(inv);
	}
	
	@EventHandler
	public void onCompassClick(InventoryClickEvent e) {
		Player p = (Player) e.getWhoClicked();
		if(e.getClickedInventory() != null && e.getClickedInventory().getTitle().equals(ChatColor.translateAlternateColorCodes('&', m.getMessage("compass")))) {
			e.setCancelled(true);
			
			switch (e.getCurrentItem().getType()) {
			case MAGMA_CREAM:
				p.closeInventory();
				if(WarpSystem.doesWarpExists("spawn")) {p.teleport(WarpSystem.getWarpLoc("spawn", p.getWorld()));} 
				break;
				
			case STICK:
				p.closeInventory();
				if(WarpSystem.doesWarpExists("magicwars")) {p.teleport(WarpSystem.getWarpLoc("magicwars", p.getWorld()));} 
				break;
				
			case COOKED_CHICKEN:
				p.closeInventory();
				if(WarpSystem.doesWarpExists("wearehungry")) {p.teleport(WarpSystem.getWarpLoc("wearehungry", p.getWorld()));} 
				break;
				
			default:
				break;
			}
		}
	}
	
}
