package lobbyItems;

import java.util.HashMap;

import lobbySystem.Main;

import org.bukkit.ChatColor;
import org.bukkit.Effect;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import utils.ItemCreator;

public class PlayerShieldListener implements Listener {

	private static Main m = Main.getMain();
	public static HashMap<Player, BukkitRunnable> run = new HashMap<Player, BukkitRunnable>();

	public static void shieldClicked(Player p) {
		if(!run.containsKey(p)) {
			
			p.playSound(p.getLocation(), Sound.BLOCK_NOTE_PLING, 1, 1);
			// creates the activated item
			p.getInventory().setItem(3, ItemCreator.crItem(Material.EYE_OF_ENDER, 1, (short) 0, 
					ChatColor.translateAlternateColorCodes('&', m.getMessage("shield")), true, true));
			
			// sends the player the activation message
			String msg = m.getMessage("shieldActivated").replace("[prefix]", m.prefix);
			p.sendMessage(ChatColor.translateAlternateColorCodes('&', msg));
			
			// adds the player a runnable whitch plays a effect bellow the player
			run.put(p, new BukkitRunnable() {
				
				@Override
				public void run() {
					// flame is beacuse it looks cool
					p.getWorld().playEffect(p.getLocation(), Effect.ENDER_SIGNAL, 1);
				}
			});
			run.get(p).runTaskTimer(m, 5, 5);
			
		} else if(run.containsKey(p)) {
			
			p.playSound(p.getLocation(), Sound.BLOCK_NOTE_PLING, 1, 1);
			
			// creates the deactivated item
			p.getInventory().setItem(3, ItemCreator.crItem(Material.EYE_OF_ENDER, 1, ChatColor.translateAlternateColorCodes('&', m.getMessage("shield"))));
			
			// removes the player from the list and stopps the runnabel
			run.get(p).cancel();
			run.remove(p);
			
			// sends the player the deactivation message
			String msg = m.getMessage("shieldDeactivated").replace("[prefix]", m.prefix);
			p.sendMessage(ChatColor.translateAlternateColorCodes('&', msg));
		}	
	}
	
	@EventHandler
	public void onMove(PlayerMoveEvent e) {
		Player p = e.getPlayer();
		
		// goes thought all players who activated the shield
		for(Player player : run.keySet()) {
			if(p != player && !p.hasPermission(m.getPermission("shieldItem"))) {
				
				// when the shield is activated all players next to the player flys away
				if(p.getLocation().distance(player.getLocation()) <= 5) {
					double Ax = p.getLocation().getX();
					double Ay = p.getLocation().getY();
					double Az = p.getLocation().getZ();
					
					double Bx = player.getLocation().getX();
					double By = player.getLocation().getY();
					double Bz = player.getLocation().getZ();
					
					double x = Ax - Bx;
					double y = Ay - By;
					double z = Az - Bz;
					
					p.getWorld().playEffect(p.getLocation(), Effect.MOBSPAWNER_FLAMES, 5);
					Vector v = new Vector(x, y, z).normalize().multiply(2D).setY(0.3D);
					p.setVelocity(v);
				}
			}
		}
		
		// when the shielded player runs, all players next to him are flying away
		if(run.containsKey(p)) {
			for(Entity entity : p.getNearbyEntities(5, 5, 5)) {
				if(entity instanceof Player) {
					Entity target = (Entity) entity;
					
					if(p != target) {
						if(!target.hasPermission(m.getPermission("shieldItem"))) {
							double Ax = p.getLocation().getX();
							double Ay = p.getLocation().getY();
							double Az = p.getLocation().getZ();
		
							double Bx = target.getLocation().getX();
							double By = target.getLocation().getY();
							double Bz = target.getLocation().getZ();
		
							double x = Bx - Ax;
							double y = By - Ay;
							double z = Bz - Az;
		
							target.getWorld().playEffect(target.getLocation(), Effect.MOBSPAWNER_FLAMES, 5);
							Vector v = new Vector(x, y, z).normalize().multiply(2D).setY(0.3D);
							target.setVelocity(v);
						}
					}
				}
			}
		}
		
	}
	
	
}
