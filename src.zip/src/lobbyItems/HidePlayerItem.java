package lobbyItems;

import java.util.ArrayList;

import lobbySystem.Main;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;

import utils.ItemCreator;

public class HidePlayerItem {
	
	private static Main m = Main.getMain();
	public static ArrayList<Player> hidePlayers = new ArrayList<Player>();
	
	public static void itemClicked(Player p) {
		if(hidePlayers.contains(p)) {
			// sets the non-powered item in the hand
			p.getInventory().setItemInMainHand(ItemCreator.crItem(Material.BLAZE_ROD, 1, 
					ChatColor.translateAlternateColorCodes('&', m.getMessage("hide_item"))));
			
			// shows the player all other players
			for(Player all : Bukkit.getOnlinePlayers()) {
				p.showPlayer(all);
			}
				
			// removes the player from the list
			hidePlayers.remove(p);
				
			p.playSound(p.getLocation(), Sound.BLOCK_NOTE_PLING, 10, 1);
				
			String msg = m.getMessage("showPlayer").replace("[prefix]", m.prefix);
			p.sendMessage(ChatColor.translateAlternateColorCodes('&', msg));
				
		} else {
			// sets the powered item in the hand
			p.getInventory().setItemInMainHand(ItemCreator.crItem(Material.BLAZE_ROD, 1, (short) 0, 
					ChatColor.translateAlternateColorCodes('&', m.getMessage("hide_item")), true, true));
				
			// hides all players for the player
			for(Player all : Bukkit.getOnlinePlayers()) {
				p.hidePlayer(all);
			}
				
			// adds the player into the list
			hidePlayers.add(p);
				
			p.playSound(p.getLocation(), Sound.BLOCK_NOTE_PLING, 1, 1);
		
			String msg = m.getMessage("hidePlayer").replace("[prefix]", m.prefix);
			p.sendMessage(ChatColor.translateAlternateColorCodes('&', msg));
		}
	}
	
	
}
