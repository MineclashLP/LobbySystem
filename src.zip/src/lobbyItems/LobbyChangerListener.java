package lobbyItems;

import java.util.ArrayList;
import java.util.List;

import lobbySystem.Main;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import pets.PetManager;
import utils.ItemCreator;
import utils.SBManager;

public class LobbyChangerListener implements Listener {

private static Main m = Main.getMain();
	
	public static void openLobbyInv(Player p) {
		Inventory inv = Bukkit.createInventory(null, 9*1, ChatColor.translateAlternateColorCodes('&', m.getMessage("lobbychanger")));
		
		// sets the items in the inventory
		int count = 1;
		for(World worlds : Bukkit.getWorlds()) {
			ItemStack item = ItemCreator.crItem(Material.NETHER_STAR, count, "�6" + worlds.getName());
			List<String> lore = new ArrayList<String>();
			lore.add(ChatColor.translateAlternateColorCodes('&', m.getMessage("playerInLobby")) + worlds.getPlayers().size());
			ItemMeta meta = item.getItemMeta();
			meta.setLore(lore);
			item.setItemMeta(meta);
			inv.addItem(item);
			count++;
		}
		
		// fills the inventory with dark glasspanes
		for(int i = 0; i < inv.getSize(); i++) {
			if(inv.getItem(i) == null) {
				inv.setItem(i, ItemCreator.crItem(Material.STAINED_GLASS_PANE, 1, (short) 7, " "));
			}
		}
		
		p.openInventory(inv);
	}
	
	@EventHandler
	public void onLobbyClick(InventoryClickEvent e) {
		Player p = (Player) e.getWhoClicked();
		if(e.getClickedInventory() != null && e.getClickedInventory().getTitle().equals(ChatColor.translateAlternateColorCodes('&', m.getMessage("lobbychanger")))) {
			e.setCancelled(true);
			
			if(e.getCurrentItem().getType() == Material.NETHER_STAR) {
				p.closeInventory();
				
				Location loc = p.getLocation();
				loc.setWorld(Bukkit.getWorld(e.getCurrentItem().getItemMeta().getDisplayName().substring(2)));
				
				if(!loc.getWorld().equals(p.getWorld())) {
					p.teleport(loc);
					p.playSound(p.getLocation(), Sound.ENTITY_ENDERMEN_TELEPORT, 10, 1);
					SBManager.updateLobbySB(p);
					
					if(PetManager.playerPets.containsKey(p)) {
						Entity ent = PetManager.playerPets.get(p);
						ent.teleport(p);
					}
					
					String msg = m.getMessage("changeLobby").replace("[prefix]", m.prefix).replace("[lobby]", loc.getWorld().getName());
					p.sendMessage(ChatColor.translateAlternateColorCodes('&', msg));
					
				} else {
					String msg = m.getMessage("changeLobbyErr").replace("[prefix]", m.prefix).replace("[lobby]", loc.getWorld().getName());
					p.sendMessage(ChatColor.translateAlternateColorCodes('&', msg));
				}
			}
		}
	}
	
}
