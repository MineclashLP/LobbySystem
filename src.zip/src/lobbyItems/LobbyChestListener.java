package lobbyItems;

import gadgets.GadgetManager;
import lobbySystem.Main;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;

import pets.PetInvManager;
import boots.BootManager;
import utils.ItemCreator;

public class LobbyChestListener implements Listener {

	private static Main m = Main.getMain();
	
	public static void openChestInv(Player p) {
		Inventory inv = Bukkit.createInventory(null, 9*3, ChatColor.translateAlternateColorCodes('&', m.getMessage("chest")));
		
		// sets the items in the inventory
		inv.setItem(10, ItemCreator.crItemArmor(Material.GOLD_BOOTS, 1, "�6Boots", true));
		inv.setItem(13, ItemCreator.crItem(Material.BONE, 1, (short) 0, "�5Pets", true, true));
		inv.setItem(16, ItemCreator.crItem(Material.FIREWORK, 1, (short) 0, "�4Gadgets", true, true));
		
		// fills the inventory with dark glasspanes
		for(int i = 0; i < inv.getSize(); i++) {
			if(inv.getItem(i) == null) {
				inv.setItem(i, ItemCreator.crItem(Material.STAINED_GLASS_PANE, 1, (short) 7, " "));
			}
		}
		p.openInventory(inv);
	}
	
	@EventHandler
	public void onInvClick(InventoryClickEvent e) {
		Player p = (Player) e.getWhoClicked();
		if(e.getClickedInventory() != null && e.getClickedInventory().getTitle().equals(ChatColor.translateAlternateColorCodes('&', m.getMessage("chest")))) {
			e.setCancelled(true);
			
			switch (e.getCurrentItem().getType()) {
			case GOLD_BOOTS:
				// boots
				p.closeInventory();
				BootManager.openBootsInv(p);
				break;
				
			case BONE:
				// pets
				p.closeInventory();
				PetInvManager.openPetsInv(p);
				break;
				
			case FIREWORK:
				// gadgets
				p.closeInventory();
				GadgetManager.openGadgetInv(p);
				break;
				
			default:
				break;
			}
		}
	}
	
	
}
