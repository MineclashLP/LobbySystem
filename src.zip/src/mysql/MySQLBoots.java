package mysql;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.UUID;

import boots.Boot;

public class MySQLBoots {

	public static void createTable() {
		try {
			PreparedStatement ps = MySQL.getConnection().prepareStatement("CREATE TABLE IF NOT EXISTS playerboots (UUID VARCHAR(100), boot VARCHAR(100))");
			ps.executeUpdate();
		} catch(SQLException e) {e.printStackTrace();}
	}
	
	public static void addBootToPlayer(UUID uuid, Boot boot) {
		if(!hasBoot(uuid, boot)) {
			try {
				PreparedStatement ps = MySQL.getConnection().prepareStatement("INSERT INTO playerboots (UUID,boot) VALUES (?,?)");
				ps.setString(1, uuid.toString());
				ps.setString(2, boot.name());
				ps.executeUpdate();
			} catch (SQLException e) {e.printStackTrace();}
		}
	}
	
	public static boolean hasBoot(UUID uuid, Boot boot) {
		try {
			PreparedStatement ps = MySQL.getConnection().prepareStatement("SELECT boot FROM playerboots WHERE UUID = ?");
			ps.setString(1, uuid.toString());
			ResultSet rs = ps.executeQuery();
			
			while(rs.next()) {
				if(Boot.valueOf(rs.getString("boot")) == boot) {
					return true;
				}
			}
		} catch (SQLException e) {e.printStackTrace();}
		return false;
	}
	
	public static void removeBoot(UUID uuid, Boot boot) {
		if(hasBoot(uuid, boot)) {
			try {
				PreparedStatement ps = MySQL.getConnection().prepareStatement("DELETE FROM playerboots WHERE UUID = ? AND boot = ?");
				ps.setString(1, uuid.toString());
				ps.setString(2, boot.name());
				ps.executeUpdate();
			} catch (SQLException e) {e.printStackTrace();}
		}
	}
	
	
}
