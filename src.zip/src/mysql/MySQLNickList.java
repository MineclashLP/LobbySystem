package mysql;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.bukkit.entity.Player;

public class MySQLNickList {

	public static void createTables() {
		try {
			PreparedStatement ps = MySQL.getConnection().prepareStatement("CREATE TABLE IF NOT EXISTS nicknames (nickname VARCHAR(100))");
			PreparedStatement ps2 = MySQL.getConnection().prepareStatement("CREATE TABLE IF NOT EXISTS nickedPlayer (UUID VARCHAR(100), namenow VARCHAR(100))");
			ps.executeUpdate();
			ps2.executeUpdate();
		} catch(SQLException e) {e.printStackTrace();}
	}
	
	// nicknames table
	public static void addName(String name) {
		if(!nameExist(name)) {
			try {
				PreparedStatement ps = MySQL.getConnection().prepareStatement("INSERT INTO nicknames (nickname) VALUES (?)");
				ps.setString(1, name);
				ps.executeUpdate();
			} catch (SQLException e) {e.printStackTrace();}
		}
	}
	
	public static void removeName(String name) {
		if(nameExist(name)) {
			try {
				PreparedStatement ps = MySQL.getConnection().prepareStatement("DELETE FROM nicknames WHERE nickname = ?");
				ps.setString(1, name);
				ps.executeUpdate();
			} catch (SQLException e) {e.printStackTrace();}
		}
	}
	
	public static boolean nameExist(String name) {
		try {
			PreparedStatement ps = MySQL.getConnection().prepareStatement("SELECT nickname FROM nicknames WHERE nickname = ?");
			ps.setString(1, name);
			ResultSet rs = ps.executeQuery();
			return rs.next();
		} catch (SQLException e) {e.printStackTrace();}
		return false;
	}
	
	public static List<String> getNames() {
		List<String> names = new ArrayList<String>();
		
		try {
			PreparedStatement ps = MySQL.getConnection().prepareStatement("SELECT nickname FROM nicknames");
			ResultSet rs = ps.executeQuery();
				
			while(rs.next()) {
				names.add(rs.getString("nickname"));
			}
		} catch (SQLException e) {e.printStackTrace();}
		
		return names;
	}
	
	// nickedplayers table
	public static boolean userExist(UUID uuid) {
		try {
			PreparedStatement ps = MySQL.getConnection().prepareStatement("SELECT namenow FROM nickedPlayer WHERE UUID = ?");
			ps.setString(1, uuid.toString());
			ResultSet rs = ps.executeQuery();
			return rs.next();
		} catch (SQLException e) {e.printStackTrace();}
		return false;
	}
	
	public static void addPlayer(Player p) {
		if(!userExist(p.getUniqueId())) {
			try {
				PreparedStatement ps = MySQL.getConnection().prepareStatement("INSERT INTO nickedPlayer (UUID,namenow) VALUES (?,?)");
				ps.setString(1, p.getUniqueId().toString());
				ps.setString(2, p.getName());
				ps.executeUpdate();
			} catch (SQLException e) {e.printStackTrace();}
		}
	}
	
	public static void setNamenow(UUID uuid, String name) {
		if(userExist(uuid)) {
			try {
				PreparedStatement ps = MySQL.getConnection().prepareStatement("UPDATE nickedPlayer SET namenow = ? WHERE UUID = ?");
				ps.setString(1, name);
				ps.setString(2, uuid.toString());
				ps.executeUpdate();
			} catch (SQLException e) {e.printStackTrace();}
		}
	}
	
	public static String getNamenow(UUID uuid) {
		if(userExist(uuid)) {
			try {
				PreparedStatement ps = MySQL.getConnection().prepareStatement("SELECT namenow FROM nickedPlayer WHERE UUID = ?");
				ps.setString(1, uuid.toString());
				ResultSet rs = ps.executeQuery();
				
				while(rs.next()) {
					return rs.getString("namenow");
				}
			} catch (SQLException e) {e.printStackTrace();}
		}
		return null;
	}
	
}
