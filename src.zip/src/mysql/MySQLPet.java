package mysql;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.UUID;

import org.bukkit.entity.Player;

import pets.Pet;

public class MySQLPet {

	public static void createTables() {
		try {
			PreparedStatement ps = MySQL.getConnection().prepareStatement("CREATE TABLE IF NOT EXISTS playerpets (UUID VARCHAR(100), pet VARCHAR(100), name VARCHAR(100))");
			PreparedStatement ps2 = MySQL.getConnection().prepareStatement("CREATE TABLE IF NOT EXISTS playerHavePets (UUID VARCHAR(100), pet VARCHAR(100), options TINYINT(5))");
			ps.executeUpdate();
			ps2.executeUpdate();
		} catch(SQLException e) {e.printStackTrace();}
	}

	// the buy list
	public static void addPetToPlayer(UUID uuid, Pet pet, boolean options) {
		if(!hasPet(uuid, pet)) {
			try {
				PreparedStatement ps = MySQL.getConnection().prepareStatement("INSERT INTO playerHavePets (UUID,pet,options) VALUES (?,?,?)");
				ps.setString(1, uuid.toString());
				ps.setString(2, pet.name());
				ps.setBoolean(3, options);
				ps.executeUpdate();
			} catch (SQLException e) {e.printStackTrace();}
		}
	}
	
	public static boolean hasPet(UUID uuid, Pet pet) {
		try {
			PreparedStatement ps = MySQL.getConnection().prepareStatement("SELECT pet FROM playerHavePets WHERE UUID = ?");
			ps.setString(1, uuid.toString());
			ResultSet rs = ps.executeQuery();
			
			while(rs.next()) {
				if(Pet.valueOf(rs.getString("pet")) == pet) {
					return true;
				}
			}
		} catch (SQLException e) {e.printStackTrace();}
		return false;
	}
	
	public static boolean hasPetOptions(UUID uuid, Pet pet) {
		try {
			PreparedStatement ps = MySQL.getConnection().prepareStatement("SELECT options FROM playerHavePets WHERE UUID = ? AND pet = ?");
			ps.setString(1, uuid.toString());
			ps.setString(2, pet.name());
			ResultSet rs = ps.executeQuery();
			
			while(rs.next()) {
				if(rs.getBoolean("options")) {
					return true;
				}
			}
		} catch (SQLException e) {e.printStackTrace();}
		return false;
	}
	
	public static void setHasPetOptions(UUID uuid, Pet pet, boolean options) {
		if(hasAPet(uuid)) {
			try {
				PreparedStatement ps = MySQL.getConnection().prepareStatement("UPDATE playerHavePets SET options = ? WHERE UUID = ? AND pet = ?");
				ps.setBoolean(1, options);
				ps.setString(2, uuid.toString());
				ps.setString(3, pet.name());
				ps.executeUpdate();
			} catch (SQLException e) {e.printStackTrace();}
		}
	}
	
	public static void removePet(UUID uuid, Pet pet) {
		if(hasPet(uuid, pet)) {
			try {
				PreparedStatement ps = MySQL.getConnection().prepareStatement("DELETE FROM playerHavePets WHERE UUID = ? AND pet = ?");
				ps.setString(1, uuid.toString());
				ps.setString(2, pet.name());
				ps.executeUpdate();
			} catch (SQLException e) {e.printStackTrace();}
		}
	}
	
	
	
	// the pet now
	public static void setPlayersPet(Player p, Pet pet) {
		UUID uuid = p.getUniqueId();
		
		if(hasAPet(uuid)) {
			removePet(uuid);
		}
		try {
			PreparedStatement ps = MySQL.getConnection().prepareStatement("INSERT INTO playerpets (UUID,pet,name) VALUES (?,?,?)");
			ps.setString(1, uuid.toString());
			ps.setString(2, pet.name());
			ps.setString(3, p.getDisplayName() + "�e's Pet");
			ps.executeUpdate();
		} catch (SQLException e) {e.printStackTrace();}
	}
	
	public static boolean hasAPet(UUID uuid) {
		try {
			PreparedStatement ps = MySQL.getConnection().prepareStatement("SELECT pet FROM playerpets WHERE UUID = ?");
			ps.setString(1, uuid.toString());
			ResultSet rs = ps.executeQuery();
			return rs.next();
		} catch (SQLException e) {e.printStackTrace();}
		return false;
	}
	
	public static String getPetName(UUID uuid) {
		try {
			PreparedStatement ps = MySQL.getConnection().prepareStatement("SELECT name FROM playerpets WHERE UUID = ?");
			ps.setString(1, uuid.toString());
			ResultSet rs = ps.executeQuery();
			while(rs.next()) {
				return rs.getString("name");
			}
		} catch (SQLException e) {e.printStackTrace();}
		return null;
	}
	
	public static Pet getPetType(UUID uuid) {
		try {
			PreparedStatement ps = MySQL.getConnection().prepareStatement("SELECT pet FROM playerpets WHERE UUID = ?");
			ps.setString(1, uuid.toString());
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				return Pet.valueOf(rs.getString("pet"));
			}
		} catch (SQLException e) {e.printStackTrace();}
		return null;
	}
	
	public static void setPetName(UUID uuid, String name) {
		if(hasAPet(uuid)) {
			try {
				PreparedStatement ps = MySQL.getConnection().prepareStatement("UPDATE playerpets SET name = ? WHERE UUID = ?");
				ps.setString(1, name);
				ps.setString(2, uuid.toString());
				ps.executeUpdate();
			} catch (SQLException e) {e.printStackTrace();}
		}
	}
	
	public static void removePet(UUID uuid) {
		if(hasAPet(uuid)) {
			try {
				PreparedStatement ps = MySQL.getConnection().prepareStatement("DELETE FROM playerpets WHERE UUID = ?");
				ps.setString(1, uuid.toString());
				ps.executeUpdate();
			} catch (SQLException e) {e.printStackTrace();}
		}
	}
	
}
