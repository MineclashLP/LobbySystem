package listener;

import lobby.BuildModeManager;
import lobbySystem.Main;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerChatTabCompleteEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerPickupItemEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.event.weather.WeatherChangeEvent;

import pets.PetManager;

public class NormalLobbyListeners implements Listener {

	private Main m = Main.getMain();
	
	@EventHandler
	public void onJoin(PlayerJoinEvent e) {
		if(m.getConfigValueBoolean("disableJoinMsg")) {
			e.setJoinMessage(null);
		}
	}
	
	@EventHandler
	public void onQuit(PlayerQuitEvent e) {
		Player p = e.getPlayer();
		if(PetManager.playerPets.containsKey(p)) {
			PetManager.removePlayersPet(p);
		}
		
		if(m.getConfigValueBoolean("disableLeaveMsg")) {
			e.setQuitMessage(null);
		}
	}
	
	@EventHandler
	public void onDrop(PlayerDropItemEvent e) {
		if(m.getConfigValueBoolean("disableItemDrop")) {
			e.setCancelled(true);
		}
	}
	
	@EventHandler
	public void onPickUp(PlayerPickupItemEvent e) {
		if(m.getConfigValueBoolean("disableItemPickUp")) {
			if(!BuildModeManager.buildModeP.contains(e.getPlayer())) {
				e.setCancelled(true);
			}
		}
	}
	
	@EventHandler
	public void onBlockBreak(BlockBreakEvent e) {
		if(m.getConfigValueBoolean("disableBlockBreak")) {
			if(!BuildModeManager.buildModeP.contains(e.getPlayer())) {
				e.setCancelled(true);
			}
		}
	}
	
	@EventHandler
	public void onBlockPlace(BlockPlaceEvent e) {
		if(m.getConfigValueBoolean("disableBlockPlace")) {
			if(!BuildModeManager.buildModeP.contains(e.getPlayer())) {
				e.setCancelled(true);
			}
		}
	}
	
	@EventHandler
	public void onWeatherChange(WeatherChangeEvent e) {
		if(m.getConfigValueBoolean("disableWeatherChange")) {
			e.setCancelled(true);
		}
	}
	
	@EventHandler
	public void onDamage(EntityDamageEvent e) {
		if(m.getConfigValueBoolean("disableEntityDamage")) {
			e.setCancelled(true);
		}
	}
	
	@EventHandler
	public void onFoodChange(FoodLevelChangeEvent e) {
		if(m.getConfigValueBoolean("disableFoodChange")) {
			e.setCancelled(true);
		}
	}
	
	@EventHandler
	public void onInventoryClick(InventoryClickEvent e) {
		if (m.getConfigValueBoolean("disableInvClick")) {
			if(!BuildModeManager.buildModeP.contains(e.getWhoClicked())) {
				e.setCancelled(true);
			}
		}
	}
	
	@EventHandler
	public void onHandChange(PlayerSwapHandItemsEvent e) {
		if (m.getConfigValueBoolean("disableOffHand")) {
			e.setCancelled(true);
		}
	}
	
	@EventHandler
	public void onNoExplodeDamage(EntityExplodeEvent e) {
		e.setCancelled(true);
	}
	
	@EventHandler
	public void onTab(PlayerChatTabCompleteEvent e) {
		e.getTabCompletions().clear();
	}
}
