package listener;

import lobbySystem.Main;

import org.bukkit.ChatColor;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerLoginEvent;
import org.bukkit.event.player.PlayerLoginEvent.Result;
import org.bukkit.event.server.ServerListPingEvent;

public class PreJoinManager implements Listener {

	public static boolean maintenanceMode = false;
	
	@EventHandler
	public void onPing(ServerListPingEvent e) {
		if(maintenanceMode == false) {
			if(e.getNumPlayers() >= 18) {
				e.setMaxPlayers(e.getNumPlayers() + 5);
			} else {
				e.setMaxPlayers(20);
			}
		} else {
			e.setMotd(ChatColor.translateAlternateColorCodes('&', Main.getMain().getMessage("maintenanceModeMOTD")));
			e.setMaxPlayers(0);
		}
	}
	
	@EventHandler
	public void onPreJoin(PlayerLoginEvent e) {
		if(maintenanceMode == true) {
			if(e.getPlayer().hasPermission(Main.getMain().getPermission("joinOnMaintenance"))) {
				e.allow();
			} else {
				e.disallow(Result.KICK_OTHER, ChatColor.translateAlternateColorCodes('&', Main.getMain().getMessage("maintenanceKickRes")));
			}
		}
	}
	
}
