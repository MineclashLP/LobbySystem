package commands;

import lobbySystem.Main;

import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

public class AdminHelp_CMD implements CommandExecutor {

private Main m = Main.getMain();
	
	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		if(sender.hasPermission(m.getPermission("adminHelp"))) {
			sender.sendMessage("�4<==============> �6Admin-HELP �4<==============>");
			sender.sendMessage(" �f- �7/setwarp");
			sender.sendMessage(" �f- �7/uls reload");
			sender.sendMessage(" �f- �7/addnickname");
			sender.sendMessage(" �f- �7/removenickname");
			sender.sendMessage(" �f- �7/coins");
			sender.sendMessage(" �f- �7/setrank <rank>");
			sender.sendMessage(" �f- �7/setrank <rank> <player>");
			sender.sendMessage(" �f- �7/buildmode");
			sender.sendMessage(" �f- �7/togglemaintenance");
		} else {
			// sender has no permission for /adminhelp
			String noPerm = m.getMessage("noPerm").replace("[prefix]", m.prefix);
			sender.sendMessage(ChatColor.translateAlternateColorCodes('&', noPerm));
		}
		return true;
	}
	
}