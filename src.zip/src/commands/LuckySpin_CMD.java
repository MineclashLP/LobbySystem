package commands;

import lobbySystem.Main;
import lukkySpins.LuckySpinManager;
import mysql.MySQLLuckySpin;

import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class LuckySpin_CMD implements CommandExecutor {
	
	private Main m = Main.getMain();
	
	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		if(sender instanceof Player) {
			Player p = (Player) sender;
			if (args.length == 0) {
				if(LuckySpinManager.hasSpin(p)) {
					MySQLLuckySpin.setNextSpinTime(p.getUniqueId());
					LuckySpinManager.openLuckySpinInv(p);
					
				} else if(p.hasPermission(m.getPermission("luckySpinTimeBypass"))) {
					LuckySpinManager.openLuckySpinInv(p);
					
				} else {
					String msg = m.getMessage("noSpin").replace("[prefix]", m.prefix);
					p.sendMessage(ChatColor.translateAlternateColorCodes('&', msg));
				}
			} else {
				// the command is too long
				sender.sendMessage(m.prefix + " �c/luckyspin");
			}
		}
			
		return true;
	}

}
