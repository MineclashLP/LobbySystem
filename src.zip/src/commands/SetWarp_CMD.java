package commands;

import lobbySystem.Main;

import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import utils.WarpSystem;

public class SetWarp_CMD implements CommandExecutor {

	private Main m = Main.getMain();
	
	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		if(sender instanceof Player) {
			Player p = (Player) sender;
			
			if(p.hasPermission(m.getPermission("setWarpUse"))) {
				if(args.length == 1) {
					
					String name = args[0];
					boolean executed = WarpSystem.addWarp(name, p.getLocation());
					
					if(executed == false) {
						// the warp already exists
						String msg = m.getMessage("warpExistsErr").replace("[prefix]", m.prefix).replace("[name]", name);
						sender.sendMessage(ChatColor.translateAlternateColorCodes('&', msg));
						
					} else {
						// the warp doesn't exists
						String msg = m.getMessage("setWarpExec").replace("[prefix]", m.prefix).replace("[name]", name);
						sender.sendMessage(ChatColor.translateAlternateColorCodes('&', msg));
					}
				} else {
					// the command is too long or too short
					p.sendMessage(m.prefix + " �c/setwarp <name>");
				}
			} else {
				// the player hasn't the permission to run this command
				String msg = m.getMessage("noPerm").replace("[prefix]", m.prefix);
				sender.sendMessage(ChatColor.translateAlternateColorCodes('&', msg));
			}
			
		} else {
			// the sender isn't a player
			String msg = m.getMessage("noPlayerErr").replace("[prefix]", m.prefix);
			sender.sendMessage(ChatColor.translateAlternateColorCodes('&', msg));
		}
		
		return true;
	}

}
