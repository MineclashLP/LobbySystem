package commands;

import java.io.File;
import java.io.IOException;

import listener.PreJoinManager;
import lobbySystem.Main;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

public class ToggleMaintenance_CMD implements CommandExecutor {

	private Main m = Main.getMain();
	
	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		if(sender.hasPermission(m.getPermission("toggleMaintenanceMode"))) {
			if(args.length == 0) {
				
				File f = new File(m.getDataFolder() + File.separator + "maintenance.yml");
				FileConfiguration cfg = YamlConfiguration.loadConfiguration(f);
				
				if(cfg.getString("maintenance").equals("off")) {
					cfg.set("maintenance", "on");
					try {
						cfg.save(f);
					} catch (IOException e) {e.printStackTrace();}
					
					PreJoinManager.maintenanceMode = true;
					
					for(Player all : Bukkit.getOnlinePlayers()) {
						if(!all.hasPermission(m.getPermission("joinOnMaintenance"))) {
							all.kickPlayer(ChatColor.translateAlternateColorCodes('&', m.getMessage("maintenanceKickRes")));
						}
					}
					
					String msg = m.getMessage("maintenanceOn").replace("[prefix]", m.prefix);
					sender.sendMessage(ChatColor.translateAlternateColorCodes('&', msg));
				} else {
					cfg.set("maintenance", "off");
					try {
						cfg.save(f);
					} catch (IOException e) {e.printStackTrace();}
					
					PreJoinManager.maintenanceMode = false;
					
					String msg = m.getMessage("maintenanceOff").replace("[prefix]", m.prefix);
					sender.sendMessage(ChatColor.translateAlternateColorCodes('&', msg));
				}
			} else {
				// the command is too long
				sender.sendMessage(m.prefix + " �c/togglemaintenance");
			}
		} else {
			// the player hasn't the permission to run this command
			String msg = m.getMessage("noPerm").replace("[prefix]", m.prefix);
			sender.sendMessage(ChatColor.translateAlternateColorCodes('&', msg));
		}
			
		return true;
	}


}
