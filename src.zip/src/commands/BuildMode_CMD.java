package commands;

import lobby.BuildModeManager;
import lobbySystem.Main;

import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class BuildMode_CMD implements CommandExecutor {
	
	private Main m = Main.getMain();
	
	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		if(sender instanceof Player) {
			Player p = (Player) sender;
			
			if(p.hasPermission(m.getPermission("buildMode"))) {
				if(args.length == 0) {
					if(m.getConfigValueBoolean("buildMode")) {
						if(BuildModeManager.buildModeP.contains(p)) {
							BuildModeManager.removeBuildModeP(p);
							String msg = m.getMessage("buildModeOff").replace("[prefix]", m.prefix);
							sender.sendMessage(ChatColor.translateAlternateColorCodes('&', msg));
							
						} else {
							BuildModeManager.setPlayerInBuildMode(p);
							String msg = m.getMessage("buildModeOn").replace("[prefix]", m.prefix);
							sender.sendMessage(ChatColor.translateAlternateColorCodes('&', msg));
						}
					}
				} else {
					// the command is too long
					sender.sendMessage(m.prefix + " �c/buildmode");
				}
			} else {
				// the player hasn't the permission to run this command
				String msg = m.getMessage("noPerm").replace("[prefix]", m.prefix);
				sender.sendMessage(ChatColor.translateAlternateColorCodes('&', msg));
			}
		}
			
		return true;
	}

}
