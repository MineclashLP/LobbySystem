package commands;

import lobbySystem.Main;

import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

public class Help_CMD implements CommandExecutor {

	private Main m = Main.getMain();
	
	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		if(cmd.getName().equalsIgnoreCase("help")) {
			sender.sendMessage("�4<==============> �6CMD-HELP �4<==============>");
			sender.sendMessage(" �f- �7/boots �f-> " + ChatColor.translateAlternateColorCodes('&', m.getMessage("helpCMD-boots")));
			sender.sendMessage(" �f- �7/pet �f-> " + ChatColor.translateAlternateColorCodes('&', m.getMessage("helpCMD-pet")));
			sender.sendMessage(" �f- �7/luckyspin �f-> " + ChatColor.translateAlternateColorCodes('&', m.getMessage("helpCMD-luckyspin")));
			sender.sendMessage(" �f- �7/spawn �f-> " + ChatColor.translateAlternateColorCodes('&', m.getMessage("helpCMD-spawn")));
		}
		return true;
	}
	
}
