package commands;

import java.io.File;
import java.io.IOException;

import listener.JoinListener;
import lobby.BroadcastManager;
import lobby.TabListHeaderAFooter;
import lobbySystem.Main;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import utils.SBManager;

public class Uls_CMD implements CommandExecutor {

	// variables
	private Main m = Main.getMain();
	
	// uls-CMD
	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		// the noPerm-string is used second times in this code so I short it
		String noPerm = m.getMessage("noPerm").replace("[prefix]", m.prefix);
		noPerm = ChatColor.translateAlternateColorCodes('&', noPerm);
		
		//------------------------------------------------------------------------------------
		
		if (sender.hasPermission(m.getPermission("ulsUse"))) {
			if(args.length == 1) {
				
				// the '/uls reload' CMD
				if (args[0].equalsIgnoreCase("reload")) {
					if (sender.hasPermission(m.getPermission("reloadConfigFiles"))) {
						
						reloadConfigFiles();
						
						String msg = m.getMessage("ulsReloadExec").replace("[prefix]", m.prefix);
						sender.sendMessage(ChatColor.translateAlternateColorCodes('&', msg));
					} else {
						// sender has no permission for '/uls reload'
						sender.sendMessage(noPerm);
					}
				} else {
					// sends help because the second argument has no action
					sendUlsHelpPage(sender);
				}
			} else if(args.length == 2) {
				if(args[0].equalsIgnoreCase("setlanguage")) {
					if(sender.hasPermission(m.getPermission("setLanguage"))) {
						
						String fileName = args[1];
						String oldFileName = m.languageFile;
						
						File langFile = new File(m.getDataFolder() + File.separator + "messages" + File.separator + fileName);
						if(!langFile.exists()) {
							m.languageFile = oldFileName;
							
							String msg = m.getMessage("fileNotFoundErr").replace("[prefix]", m.prefix);
							sender.sendMessage(ChatColor.translateAlternateColorCodes('&', msg));
							return false;
						}
						
						try {
							File f = new File(m.getDataFolder() + File.separator + "config.yml");
							FileConfiguration cfg = YamlConfiguration.loadConfiguration(f);
							cfg.set("language", fileName);
							cfg.save(f);
						} catch (IOException e) {e.printStackTrace();}
						
						reloadConfigFiles();
						
						String msg = m.getMessage("ulsSetLangExec").replace("[prefix]", m.prefix);
						sender.sendMessage(ChatColor.translateAlternateColorCodes('&', msg));
					} else {
						// sender has no permission for '/uls setlanguage'
						sender.sendMessage(noPerm);
					}
				} else {
					// sends help because the second argument has no action
					sendUlsHelpPage(sender);
				}
			} else {
				// the second argument hasn't a valide action
				sendUlsHelpPage(sender);
			}
		} else {
			// sender has no permission for '/uls'
			sender.sendMessage(noPerm);
		}
		
		return true;
	}
	
	// Just a method for returning the help page
	private void sendUlsHelpPage(CommandSender s) {
		s.sendMessage("�4<============> �6Uls-CommandHelp �4<============>");
		s.sendMessage(" �f- �7/uls reload �f-> " + ChatColor.translateAlternateColorCodes('&', m.getMessage("ulsCMD-reloadDes")));
		s.sendMessage(" �f- �7/uls setlanguage <file-name> �f-> " + ChatColor.translateAlternateColorCodes('&', m.getMessage("ulsCMD-setLangDes")));
	}
	
	private void reloadConfigFiles() {
		m.createConfig();
		m.readConfig();
		m.createMessagesFiles();
		m.createPermissionFile();
		m.createMySQLFile();
		m.createMaintenaceModeFile();
		m.createActionbarFile();
		
		BroadcastManager.actionBarMsg.clear();
		
		for(Player all : Bukkit.getOnlinePlayers()) {
			all.getInventory().clear();
			all.getInventory().setArmorContents(null);
			JoinListener.giveItems(all);
			SBManager.updateLobbySB(all);
			TabListHeaderAFooter.sendTablistHeaderAndFooter(all, m.getMessage("tabListHeader"), m.getMessage("tabListFooter"));
		}
	}

}
