package commands;

import lobbySystem.Main;
import mysql.MySQLNickList;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import rankAPI.Rank;
import rankAPI.RankAPI;

public class SetRank_CMD implements CommandExecutor {

	private Main m = Main.getMain();
	
	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
			if(sender.hasPermission(m.getPermission("setRankCMD"))) {
				if(args.length == 1) {
					if(sender instanceof Player) {
						Player p = (Player) sender;
						Rank rank = null;
						for(Rank ranks : Rank.values()) {
							if(ranks.name().equalsIgnoreCase(args[0].toUpperCase())) {
								rank = ranks;
							}
						}
						
						if(rank == null) {
							String msg = m.getMessage("rankNotExists").replace("[prefix]", m.prefix).replace("[rank]", args[0].toUpperCase());
							p.sendMessage(ChatColor.translateAlternateColorCodes('&', msg));
						} else {
							if(p.hasPermission(m.getPermission("setRankCMD-" + rank.name()))) {
								RankAPI.setRank(p, rank);
								RankAPI.setRankToPlayer(p, MySQLNickList.getNamenow(p.getUniqueId()));
							} else {
								// the player hasn't the permission to run this command
								String msg = m.getMessage("noPerm").replace("[prefix]", m.prefix);
								p.sendMessage(ChatColor.translateAlternateColorCodes('&', msg));
							}
						}
					}
				} else {
					if(sender.hasPermission(m.getPermission("setRankCMDAdvanced"))) {
						if(args.length == 2) {
							Player target = Bukkit.getPlayer(args[1]);
							
							if(target != null) {
								
								Rank rank = null;
								for(Rank ranks : Rank.values()) {
									if(ranks.name().equalsIgnoreCase(args[0].toUpperCase())) {
										rank = ranks;
									}
								}
								
								if(rank == null) {
									String msg = m.getMessage("rankNotExists").replace("[prefix]", m.prefix).replace("[rank]", args[0].toUpperCase());
									sender.sendMessage(ChatColor.translateAlternateColorCodes('&', msg));
								} else {
									RankAPI.setRank(target, rank);
									RankAPI.setRankToPlayer(target, MySQLNickList.getNamenow(target.getUniqueId()));
								}
								
							} else {
								// the player is not online
								String notOnline = m.getMessage("playerNotOnline").replace("[prefix]", m.prefix);
								sender.sendMessage(ChatColor.translateAlternateColorCodes('&', notOnline));
								return true;
							}
						} else {
							// the command is too long or too short
							sender.sendMessage(m.prefix + " �c/setrank <rank> <name>");
						}
					} else {
						// the command is too long or too short
						sender.sendMessage(m.prefix + " �c/setrank <rank>");
					}
				}
			} else {
				// the player hasn't the permission to run this command
				String msg = m.getMessage("noPerm").replace("[prefix]", m.prefix);
				sender.sendMessage(ChatColor.translateAlternateColorCodes('&', msg));
			}
		return true;
	}

}
