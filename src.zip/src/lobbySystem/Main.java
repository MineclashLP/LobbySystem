package lobbySystem;

import gadgets.GadgetManager;
import gadgets.GadgetPlayer;

import java.io.File;
import java.io.IOException;
import java.sql.Date;
import java.time.LocalDate;

import listener.JoinListener;
import listener.NormalLobbyListeners;
import listener.PreJoinManager;
import lobby.BroadcastManager;
import lobby.ChatListener;
import lobby.DoubleJump;
import lobby.Jumppads;
import lobby.TabListHeaderAFooter;
import lobbyItems.CompassListener;
import lobbyItems.InteractListener;
import lobbyItems.LobbyChangerListener;
import lobbyItems.LobbyChestListener;
import lobbyItems.PlayerShieldListener;
import lukkySpins.LuckySpinManager;
import mysql.MySQL;
import mysql.MySQLBoots;
import mysql.MySQLLuckySpin;
import mysql.MySQLNickList;
import mysql.MySQLPet;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.GameMode;
import org.bukkit.World;
import org.bukkit.WorldCreator;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.plugin.PluginManager;
import org.bukkit.plugin.java.JavaPlugin;

import pets.Pet;
import pets.PetAdvOptionsListener;
import pets.PetInteractListener;
import pets.PetInvManager;
import pets.PetManager;
import pets.PetOptionsMenueManager;
import rankAPI.RankAPI;
import utils.SBManager;
import boots.BootManager;
import boots.BootPlayer;
import coinAPI.CoinAPI;
import commands.AddNickname_CMD;
import commands.AdminHelp_CMD;
import commands.Boots_CMD;
import commands.BuildMode_CMD;
import commands.Coins_CMD;
import commands.Help_CMD;
import commands.LuckySpin_CMD;
import commands.Pet_CMD;
import commands.RemoveNickname_CMD;
import commands.SetRank_CMD;
import commands.SetWarp_CMD;
import commands.Spawn_CMD;
import commands.ToggleMaintenance_CMD;
import commands.Uls_CMD;

public class Main extends JavaPlugin {

	private static Main main;
	public String prefix;
	public String languageFile;
	public String coinName;
	
	@Override
	public void onEnable() {
		main = this;
		
		// creates the pluginFolder
		try {
			if(!getDataFolder().exists())
			getDataFolder().mkdir();
		} catch (Exception e) {}
		
		createConfig();
		readConfig();
		createMessagesFiles();
		createPermissionFile();
		createMySQLFile();
		createMaintenaceModeFile();
		createActionbarFile();
		
		Pet.registerEntities();
		
		// connects to MySQL and creates tables
		FileConfiguration cfg = getFileConfig(getDataFolder() + File.separator + "mysql.yml");
		MySQL.connect(cfg.getString("host"), cfg.getString("port"), cfg.getString("database"), cfg.getString("username"), cfg.getString("password"));
		RankAPI.setupMySQL(cfg.getString("host"), cfg.getString("port"), cfg.getString("database"), cfg.getString("username"), cfg.getString("password"));
		CoinAPI.createTable();
		MySQLNickList.createTables();
		MySQLBoots.createTable();
		MySQLPet.createTables();
		MySQLLuckySpin.createTable();
		
		// temp worldgen
		if(Bukkit.getWorld("Lobby2") == null) {
			Bukkit.createWorld(WorldCreator.name("Lobby2").copy(Bukkit.getWorld("Lobby1")));
		}
		
		// general world settings
		for(World w : Bukkit.getWorlds()) {
			w.setStorm(false);
			w.setThundering(false);
			w.setGameRuleValue("doDaylightCycle", "false");
			w.setTime(6000);
			
			for(Entity ent : w.getEntities()) {
				if(!(ent instanceof Player)) {
					ent.remove();
				}
			}
		}
		
		// general player settings
		for(Player all : Bukkit.getOnlinePlayers()) {
			all.closeInventory();
			all.getInventory().clear();
			all.getInventory().setArmorContents(null);
			JoinListener.giveItems(all);
			SBManager.updateLobbySB(all);
			all.setAllowFlight(false);
			all.setFoodLevel(20);
			all.setGameMode(GameMode.SURVIVAL);
			LuckySpinManager.sendAvailableSpinMsg(all);
			TabListHeaderAFooter.sendTablistHeaderAndFooter(all, getMessage("tabListHeader"), getMessage("tabListFooter"));
			MySQLLuckySpin.addPlayerInList(all.getUniqueId(), Date.valueOf(LocalDate.now()));
			
			// sets also the displayname
			MySQLNickList.addPlayer(all);
			RankAPI.setRankToPlayer(all, MySQLNickList.getNamenow(all.getUniqueId()));
		}
		
		// maintenace
		File f2 = new File(getDataFolder() + File.separator + "maintenance.yml");
		FileConfiguration cfg2 = YamlConfiguration.loadConfiguration(f2);
		if(cfg2.getString("maintenance").equals("on")) {
			PreJoinManager.maintenanceMode = true;
		}
		
		
		// events
		PluginManager pm = Bukkit.getPluginManager();
		pm.registerEvents(new NormalLobbyListeners(), this);
		pm.registerEvents(new JoinListener(), this);
		pm.registerEvents(new InteractListener(), this);
		pm.registerEvents(new Jumppads(), this);
		pm.registerEvents(new DoubleJump(), this);
		pm.registerEvents(new ChatListener(), this);
		pm.registerEvents(new PreJoinManager(), this);
		pm.registerEvents(new LuckySpinManager(), this);
		
		// item events
		pm.registerEvents(new CompassListener(), this);
		pm.registerEvents(new LobbyChangerListener(), this);
		pm.registerEvents(new PlayerShieldListener(), this);
		pm.registerEvents(new LobbyChestListener(), this);
		
		// boots/pets/gadgets events
		pm.registerEvents(new BootManager(), this);
		pm.registerEvents(new PetManager(), this);
		pm.registerEvents(new PetInvManager(), this);
		pm.registerEvents(new PetInteractListener(), this);
		pm.registerEvents(new PetOptionsMenueManager(), this);
		pm.registerEvents(new PetAdvOptionsListener(), this);
		pm.registerEvents(new GadgetManager(), this);
		pm.registerEvents(new GadgetPlayer(), this);
		
		// commands
		this.getCommand("uls").setExecutor(new Uls_CMD());
		this.getCommand("setwarp").setExecutor(new SetWarp_CMD());
		this.getCommand("coins").setExecutor(new Coins_CMD());
		this.getCommand("addnickname").setExecutor(new AddNickname_CMD());
		this.getCommand("removenickname").setExecutor(new RemoveNickname_CMD());
		this.getCommand("togglemaintenance").setExecutor(new ToggleMaintenance_CMD());
		this.getCommand("buildmode").setExecutor(new BuildMode_CMD());
		this.getCommand("help").setExecutor(new Help_CMD());
		this.getCommand("boots").setExecutor(new Boots_CMD());
		this.getCommand("luckyspin").setExecutor(new LuckySpin_CMD());
		this.getCommand("pet").setExecutor(new Pet_CMD());
		this.getCommand("spawn").setExecutor(new Spawn_CMD());
		this.getCommand("setrank").setExecutor(new SetRank_CMD());
		this.getCommand("adminhelp").setExecutor(new AdminHelp_CMD());
		
		BootPlayer.startBootEffectRunnable();
		GadgetPlayer.startGadgetCooldown();
		GadgetPlayer.startGadgetScheduler();
		LuckySpinManager.startLuckySpinScheduler();
		BroadcastManager.startMSGBoradcast();
		
		String msg = getMessage("pluginEnable").replace("[prefix]", prefix);
		Bukkit.getConsoleSender().sendMessage(ChatColor.translateAlternateColorCodes('&', msg));
	}

	@Override
	public void onDisable() {	
		Pet.registerEntities();
		
		for(Player all : Bukkit.getOnlinePlayers()) {
			if(PetManager.playerPets.containsKey(all)) {
				PetManager.removePlayersPet(all);
			}
		}
		
		// closes the mysql connection
		MySQL.disconect();
		
		String msg = getMessage("pluginDisable").replace("[prefix]", prefix);
		Bukkit.getConsoleSender().sendMessage(ChatColor.translateAlternateColorCodes('&', msg));
	}
	

	public void readConfig() {
		this.prefix = ChatColor.translateAlternateColorCodes('&', getConfigValueString("prefix"));
		this.languageFile = getConfigValueString("language");
		this.coinName = ChatColor.translateAlternateColorCodes('&', getConfigValueString("coinName"));
	}

	public void createMessagesFiles() {
		// creates the messages folder
		File folder = new File(getDataFolder(), "messages");
		folder.mkdir();

		File f = new File(getDataFolder() + File.separator + "messages", "german.yml");
		FileConfiguration cfg = YamlConfiguration.loadConfiguration(f);

		if (!f.exists()) {
			try {
				f.createNewFile();
				cfg.set("pluginEnable", "[prefix] &aPlugin aktiviert");
				cfg.set("pluginDisable", "[prefix] &cPlugin deaktiviert");
				cfg.set("playerInLobby", "&9Spieler in der Lobby: ");
				cfg.set("changeLobby", "[prefix] &7Du bist nun in Lobby: &e[lobby]");
				cfg.set("warningNicked", "[prefix] &4Achtung! &aDu bist genickt und hei�t: &e[namenow]");
				cfg.set("maintenanceModeMOTD", "&4WARTUNGSARBEITEN!\n    &c->&c Versuche sp�ter erneut zu joinen!");
				cfg.set("maintenanceKickRes", "&4WARTUNGSARBEITEN!\n&c-> Versuche sp�ter erneut zu joinen!");
				cfg.set("pSetBoots", "[prefix] &aDu tr�gst nun die Boots: [boots]");
				cfg.set("luckySpin", "&6Gl�cksdreh");
				cfg.set("unlimitedSpins", "[prefix] &aDu hast heute noch &eunendlich &6Gl�cksdrehs&a! &e-> &aBenutze sie �ber &e/luckyspin");
				cfg.set("hasSpin", "[prefix] &aDu hast heute noch &e1 &6Gl�cksdreh&a! &e-> &aBenutze ihn �ber &e/luckyspin");
				cfg.set("notAvailable", "&4Nicht verf�gbar");
				
				// buyInv
				cfg.set("buyed", "&aGekauft");
				cfg.set("petConfirmation", "&ePet-Kauf best�tigen");
				cfg.set("petOptionsConfirmation", "&ePet Optionen - Kauf best�tigen");
				cfg.set("bootConfirmation", "&eBoot-Kauf best�tigen");
				cfg.set("accept", "&aAkzeptieren");
				cfg.set("abort", "&cAbbrechen");
				
				// boots
				cfg.set("unlockBoots", "[prefix] &aDu hast die Boots [boots] &aerfolgreich gekauft" );
				cfg.set("removeBoots", "&4Boots l�schen");
				
				// pets
				cfg.set("sheep", "&fSchaf");
				cfg.set("pig", "&cSchwein");
				cfg.set("chicken", "&fHuhn");
				cfg.set("cow", "&7Kuh");
				cfg.set("ocelot", "&eOzelot");
				cfg.set("horse", "&ePferd");
				cfg.set("creeper", "&aCreeper");
				cfg.set("skeleton", "&fSkelett");
				cfg.set("zombie", "&bZombie");
				cfg.set("spider", "&4Spinne");
				cfg.set("irongolem", "&fEisengolem");
				cfg.set("witch", "&9Hexe");
				cfg.set("blaze", "&6Lohe");
				cfg.set("enderman", "&7Enderman");
				cfg.set("wolf", "&7Wolf");
				cfg.set("snowman", "&fSchneegolem");
				cfg.set("mushroomcow", "&cPilzkuh");
				cfg.set("silverfish", "&7Silberfisch");
				cfg.set("cavespider", "&aH�hlenspinne");
				
				cfg.set("changeName", "&6Name �ndern");
				cfg.set("setOnHead", "&7Auf den Kopf setzen");
				cfg.set("removePet", "&4Pet l�schen");
				cfg.set("petOptions", "&ePet-Optionen");
				cfg.set("ride", "&5Reite dein Pet");
				cfg.set("advancedPetOptions", "&6Erweiterte Pet-Einstellungen");
				
				cfg.set("unlockPets", "[prefix] &aDu hast das Pet [pet] &aerfolgreich gekauft");
				cfg.set("unlockPetOptions", "[prefix] &aDu hast die Optionen f�r das Pet &e[pet] &aerfolgreich gekauft");
				cfg.set("pSpawnPet", "[prefix] &aDein Pet wurde gespawnt" );
				cfg.set("petRemoved", "[prefix] &cDein Pet wurde entfernt" );
				cfg.set("petOnHead", "[prefix] &aDein Pet wurde dir auf den Kopf gesetzt - \n�aDr�cke nochmal auf den Helm um es wieder herunterzulassen" );
				cfg.set("petRenamed", "[prefix] &aDein Pet wurde umbenannt und hei�t nun: &f[name]");
				cfg.set("petRenameInfo", "[prefix] $aGebe in den Chat den Namen ein! Verwende das Zeichen '&' f�r Farben");
				
				// pet advanced options description
				cfg.set("changeAge", "&eAlter ver�ndern");
				cfg.set("changeColor", "&5Farbe ver�ndern");
				cfg.set("changeSheared", "&fGeschoren &7| &aAn &7/ &cAus");
				cfg.set("changeSaddle", "&9Sattel &7| &aAn &7/ &cAus");
				cfg.set("changeSitting", "&eSitzen &7| &aAn &7/ &cAus");
				cfg.set("changeTamed", "&eGez�hmt &7| &aAn &7/ &cAus");
				cfg.set("changeCatType", "&6Ozelottyp ver�ndern");
				cfg.set("changePowered", "&9Aufgeladen &7| &aAn &7/ &cAus");
				cfg.set("changeHelmetType", "&eHelm-Material ver�ndern");
				cfg.set("changeSize", "&6Gr��e ver�ndern");
				
				// gadgets
				cfg.set("costPerActivation", "[coins] &apro Nutzung");
				cfg.set("costPerSecond", "[coins] &apro Sekunde");
				cfg.set("removeGadget", "&4Gadget l�schen");
				cfg.set("gadgetCooldown", "[prefix] &cWarte noch &e[time] &cSekunden bis du ein Gadget verwendest");
				cfg.set("firework", "&4F&6e&eu&ae&br&9w&5e&4r&6k");
				cfg.set("magicEnderpearl", "&9M&5a&9g&5i&9s&5c&9h&5e &5E&9n&5d&9e&5r&9p&5e&9r&5l&9e");
				cfg.set("smash", "&7S&8M&7A&8S&7H");
				cfg.set("firestar", "&4F&6e&4u&6e&4r&6s&4t&6e&4r&6n");
				cfg.set("rocket", "&4R&cA&4K&cE&4T&cE");
				cfg.set("lightningwand", "&bB&9l&bi&9t&bz&9s&bt&9a&bb");
				cfg.set("vulcan", "&6V&eu&6l&ek&6a&en");
				cfg.set("tntfountain", "&4T&fN&4T&fF&4o&fn&4t&f�&4n&fe");
				cfg.set("knockbackaxe", "&7R&f�&7c&fk&7s&ft&7o&f�&7-&fA&7x&ft");
				cfg.set("firename", "&4F&6e&4u&6e&4r&6n&4a&6m&4e");
				cfg.set("discoarmor", "&4D&6i&es&ac&co&ba&9n&5z&4u&6g");
				cfg.set("slime", "&aS&2c&ah&2l&ae&2i&am");
				
				// Item messages
				cfg.set("showPlayer", "[prefix] &7Alle Spieler sind nun &asichtbar");
				cfg.set("hidePlayer", "[prefix] &7Alle Spieler sind nun &cunsichtbar");
				cfg.set("nickPlayer", "[prefix] &7Du bist nun genickt und hei�t: &e[newname]");
				cfg.set("unnickPlayer", "[prefix] &7Du bist nun nicht mehr genickt");
				cfg.set("shieldActivated", "[prefix] &7Spieler-Schild &aaktivert");
				cfg.set("shieldDeactivated", "[prefix] &7Spieler-Schild &cdeaktivert");
				
				// Errors
				cfg.set("noPerm", "[prefix] &cDu darfst diesen Befehl nicht ausf�hren");
				cfg.set("fileNotFoundErr", "[prefix] &cDie angegebene Datei konnte nicht gefunden werden");
				cfg.set("noPlayerErr", "[prefix] &cDieser Befehl kann nur von einem Spieler ausgef�hrt werden");
				cfg.set("warpExistsErr", "[prefix] &cDer Warp &e[name] &cexistiert bereits");
				cfg.set("noNumber", "[prefix] &cDie angegeben Zahl besteht nicht nur aus Ziffern oder ist zu lang");
				cfg.set("minusCoins", "[prefix] &cDer angegeben Spieler hat nicht gen�gen [coinname]");
				cfg.set("playerNotOnline", "[prefix] &cDer angegebene Spieler ist nicht online");
				cfg.set("changeLobbyErr", "[prefix] &cDu bist bereits in der Lobby: &e[lobby]");
				cfg.set("nameExistErr", "[prefix] &cDer angegebene Nickname &e[name] &cexistiert bereits");
				cfg.set("nameNotExistErr", "[prefix] &cDer angegebene Nickname &e[name] &cexistiert nicht");
				cfg.set("notEnoughtCoins", "[prefix] &cDu hast nicht gen�gend [coinname] &cum dies zu kaufen");
				cfg.set("noSpin", "[prefix] &cDu hast heute keinen Gl�cksdeh mehr");
				cfg.set("noSelectedPet", "[prefix] &cDu hast kein Pet ausgew�hlt");
				cfg.set("rankNotExists", "[prefix] &cDer Rang &e[rank] &cexistiert nicht");
				cfg.set("wearDiscoArmor", "[prefix] &cDu kannst keine Boots oder Gadgets ausw�hlen, da das Gadget [discoarmor] &caktiv ist");
				
				// CMD-execute information
				cfg.set("ulsReloadExec", "[prefix] &aDie Config-Datein wurden erfolgreich neu geladen");
				cfg.set("ulsSetLangExec", "[prefix] &aDie Sprache wurde ge�ndert");
				cfg.set("setWarpExec", "[prefix] &aDer Warp &e[name] &awurde erfolgreich gesetzt");
				cfg.set("addCoinsExec", "[prefix] &aDer Spieler hat &e[addcoins] [coinname] &abekommen");
				cfg.set("removeCoinsExec", "[prefix] &aDem Spieler wurden &e[removecoins] [coinname] &aentfernt");
				cfg.set("setCoinsExec", "[prefix] &aDie Anzahl der [coinname] &ades Spielers wurde auf &e[setcoins] &agesetzt");
				cfg.set("getCoinMsg", "[prefix] &aDer Spieler hat &e[coins] [coinname]");
				cfg.set("addNicknameExec", "[prefix] &aDer Nickname &e[name] &awurde erfolgreich hinzugef�gt");
				cfg.set("removeNicknameExec", "[prefix] &aDer Nickname &e[name] &awurde erfolgreich entfernt");
				cfg.set("maintenanceOn", "[prefix] &aDer Wartungsmodus wurde aktiviert");
				cfg.set("maintenanceOff", "[prefix] &cDer Wartungsmodus wurde deaktiviert");
				cfg.set("buildModeOn", "[prefix] &aBuildmode aktiviert");
				cfg.set("buildModeOff", "[prefix] &cBuildmode deaktiviert");
				
				// items
				cfg.set("compass", "&bNavigator");
				cfg.set("hide_item", "&6Spieler verstecken");
				cfg.set("lobbychanger", "&cLobby wechseln");
				cfg.set("name_tag", "&eAutonick");
				cfg.set("shield", "&5Spieler-Schild");
				cfg.set("chest", "&9Pets / Boots / Gadgets");
				cfg.set("noGadget", "&4Kein Gadget ausgew�hlt");

				// scoreboard
				cfg.set("player", "&eSpieler online:");
				cfg.set("lobby", "&cAktuelle Lobby:");
				
				// the description of the command in the help-popups
				cfg.set("ulsCMD-reloadDes", "&eL�d alle config-, Nachrichten- und Berechtigungs-Datein neu");
				cfg.set("ulsCMD-setLangDes", "&e�ndert die Sprache des Plugins");  
				cfg.set("helpCMD-boots", "&e�ffnet das Boots-Inventar");
				cfg.set("helpCMD-pet", "&e�ffnet die Pet-Optionen deines aktuellen Pets");  
				cfg.set("helpCMD-luckyspin", "&eDrehe den t�glichen Gl�cksdreh");
				cfg.set("helpCMD-spawn", "&eTeleportiert dich zum Spawn");

				// the header and footer of the tab-list
				cfg.set("tabListHeader", "&eGameMagic.de &aLobby");  
				cfg.set("tabListFooter", "&6GameMagic &7- &4Servernetzwerk");  
				
				cfg.save(f);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		File f2 = new File(getDataFolder() + File.separator + "messages", "english.yml");
		FileConfiguration cfg2 = YamlConfiguration.loadConfiguration(f2);

		if (!f2.exists()) {
			try {
				f2.createNewFile();
				cfg2.set("pluginEnable", "[prefix] &aPlugin enabled");
				cfg2.set("pluginDisable", "[prefix] &cPlugin disabled");
				cfg2.set("playerInLobby", "&9Players in this lobby: ");
				cfg2.set("changeLobby", "[prefix] &7You are now in lobby: &e[lobby]");
				cfg2.set("warningNicked", "[prefix] &4Warning! &aYou are nicked and called: &e[namenow]");
				cfg2.set("maintenanceModeMOTD", "&4MAINTENANCE!\n    &c->&c Try to join later again!");
				cfg2.set("maintenanceKickRes", "&4MAINTENANCE!\n&c-> Try to join later again!");
				cfg2.set("pSetBoots", "[prefix] &aYou wear now the boots: [boots]");
				cfg2.set("luckySpin", "&6Lucky-spin");
				cfg2.set("unlimitedSpins", "[prefix] &aYou have &eunlimited &6lucky-spins &atoday! &e-> &aUse them with &e/luckyspin");
				cfg2.set("hasSpin", "[prefix] &aYou have &e1 &6lucky-spin &atoday! &e-> &aUse it with &e/luckyspin");
				cfg2.set("notAvailable", "&4Not available");
				
				// buy-inv
				cfg2.set("buyed", "&aBuyed");
				cfg2.set("petConfirmation", "&ePet-Buy confirmation");
				cfg2.set("petOptionsConfirmation", "&ePet options - Buy confirmation");
				cfg2.set("bootConfirmation", "&eBoot-Buy confirmation");
				cfg2.set("accept", "&aAccept");
				cfg2.set("abort", "&cAbort");
				
				// boots
				cfg2.set("unlockBoots", "[prefix] &aYou have unlocked the boots [boots] &asuccessfully" );
				cfg2.set("removeBoots", "&4Remove boots");
				
				// pets
				cfg2.set("sheep", "&fSheep");
				cfg2.set("pig", "&cPig");
				cfg2.set("chicken", "&fChicken");
				cfg2.set("cow", "&7Cow");
				cfg2.set("ocelot", "&eOcelot");
				cfg2.set("horse", "&eHorse");
				cfg2.set("creeper", "&aCreeper");
				cfg2.set("skeleton", "&fSkeleton");
				cfg2.set("zombie", "&bZombie");
				cfg2.set("spider", "&4Spinne");
				cfg2.set("irongolem", "&fIrongolem");
				cfg2.set("witch", "&9Witch");
				cfg2.set("blaze", "&6Blaze");
				cfg2.set("enderman", "&7Enderman");
				cfg2.set("slime", "&aSlime");
				cfg2.set("wolf", "&7Wolf");
				cfg2.set("snowman", "&fSnowman");
				cfg2.set("mushroomcow", "&cMushroomcow");
				cfg2.set("silverfish", "&7Silverfish");
				cfg2.set("cavespider", "&aCavespider");
				
				cfg2.set("changeName", "&6Change name");
				cfg2.set("setOnHead", "&7Set pet on head");
				cfg2.set("removePet", "&4Remove pet");
				cfg2.set("petOptions", "&ePet-Options");
				cfg2.set("ride", "&5Ride you pet");
				cfg2.set("advancedPetOptions", "&6Advanced pet-configuration");
				
				cfg2.set("unlockPets", "[prefix] &aYou have unlocked the pet [pet] &asuccessfully" );
				cfg2.set("unlockPetOptions", "[prefix] &aYou have unlocked the options for the pet &e[pet] &asuccessfully");
				cfg2.set("gadgetCooldown", "[prefix] &cYou have to wait &e[time] &cseconds bevor you use a gadget");
				cfg2.set("pSpawnPet", "[prefix] &aYour pet was spawned" );
				cfg2.set("petRemoved", "[prefix] &cYour pet was removed" );
				cfg2.set("petOnHead", "[prefix] &aYour pet was set on your head - \n�aPress again on the helmet to let it down again" );
				cfg2.set("petRenamed", "[prefix] &aYour pet was renamed and is now called: &f[name]");
				cfg2.set("petRenameInfo", "[prefix] $aWrite your petname in the chat! Use '&' for colors");
				
				// pet advanced options description
				cfg2.set("changeAge", "&echange age");
				cfg2.set("changeColor", "&5change color");
				cfg2.set("changeSheared", "&fSheared &7| &aOn &7/ &cOff");
				cfg2.set("changeSaddle", "&9Saddle &7| &aOn &7/ &cOff");
				cfg2.set("changeSitting", "&eSitting &7| &aOn &7/ &cOff");
				cfg2.set("changeTamed", "&eTamed &7| &aOn &7/ &cOff");
				cfg2.set("changeCatType", "&6Change ocelot-type");
				cfg2.set("changePowered", "&9Powered &7| &aOn &7/ &cOff");
				cfg2.set("changeHelmetType", "&eChange helmet-material");
				cfg2.set("changeSize", "&6change size");
				
				// gadgets
				cfg2.set("costPerActivation", "[coins] &aper activation");
				cfg2.set("costPerSecond", "[coins] &apro second");
				cfg2.set("removeGadget", "&4Remove Gadget");
				cfg2.set("firework", "&4F&6i&er&ae&bw&9o&5r&4k");
				cfg2.set("magicEnderpearl", "&9M&5a&9g&5i&9c &5E&9n&5d&9e&5r&9p&5e&9a&5r&9l");
				cfg2.set("smash", "&7S&8M&7A&8S&7H");
				cfg2.set("firestar", "&6Firestar");
				cfg2.set("rocket", "&4R&cO&4C&cK&4E&cT");
				cfg2.set("lightningwand", "&bL&9i&bg&9h&bt&9n&bi&9n&bg&9w&4a&9n&bd");
				cfg2.set("vulcan", "&6V&eu&6l&ec&6a&en");
				cfg2.set("tntfountain", "&4T&fN&4T&fF&4o&fu&4n&ft&4a&fi&4n");
				cfg2.set("knockbackaxe", "&7K&fn&7o&fc&7k&fb&7a&fc&7k&f-&7A&fx&7e");
				cfg2.set("firename", "&4F&6i&4r&6e&4n&6a&4m&6e");
				cfg2.set("discoarmor", "&4D&6i&es&ac&co&ba&9r&5m&4o&6r");
				cfg2.set("slime", "&aS&2l&ai&2i&am&2e");
				
				// Item messages
				cfg2.set("showPlayer", "[prefix] &7All players are now visible");
				cfg2.set("hidePlayer", "[prefix] &7All players are now invisible");
				cfg2.set("nickPlayer", "[prefix] &7You are now nicked and called: &e[newname]");
				cfg2.set("unnickPlayer", "[prefix] &7You are no longer nicked");
				cfg2.set("shieldActivated", "[prefix] &7Player-shield &aenabled");
				cfg2.set("shieldDeactivated", "[prefix] &7Player-shield &cdisabled");
				
				// Errors
				cfg2.set("noPerm","[prefix] &cYou are not allowed to run this command");
				cfg2.set("fileNotFoundErr", "[prefix] &cThe file doesn't exists");
				cfg2.set("noPlayerErr", "[prefix] &cJust players can run this command");
				cfg2.set("warpExistsErr", "[prefix] &cThe warp &e[name] &calready exists");
				cfg2.set("noNumber", "[prefix] &cThe number is not numeral or too long");
				cfg2.set("minusCoins", "[prefix] &cThe player has not enouth [coinname] to remove");
				cfg2.set("playerNotOnline", "[prefix] &cThe player is not online");
				cfg2.set("changeLobbyErr", "[prefix] &cYou are already in lobby: &e[lobby]");
				cfg2.set("nameExistErr", "[prefix] &cThe nickname &e[name] &cdoes already exists");
				cfg2.set("nameNotExistErr", "[prefix] &cThe nickname &e[name] &cdoesn't exists");
				cfg2.set("notEnoughtCoins", "[prefix] &cYou haven't enought [coinname] to buy this");
				cfg2.set("noSpin", "[prefix] &cYou have no lucky-spin today");
				cfg2.set("noSelectedPet", "[prefix] &cYou haven't selected a pet");
				cfg2.set("rankNotExists", "[prefix] &cThe rank &e[rank] &cdoesn't exists");
				cfg2.set("wearDiscoArmor", "[prefix] &cYou can't select a boot or gadget because the gadget [discoarmor] &cis enabled");
				
				// CMD-execute information
				cfg2.set("ulsReloadExec", "[prefix] &aThe config files were reloaded");
				cfg2.set("ulsSetLangExec", "[prefix] &aThe language has been changed");
				cfg2.set("setWarpExec", "[prefix] &aYou have set the warp &e[name]");
				cfg2.set("addCoinsExec", "[prefix] &aThe player got &e[addcoins] [coinname]");
				cfg2.set("removeCoinsExec", "[prefix] &aYou have removed &e[removecoins] [coinname] &afrom the player");
				cfg2.set("setCoinsExec", "[prefix] &aYou set the [coinname] &afrom the player to &e[setcoins]");
				cfg2.set("getCoinMsg", "[prefix] &aThe player has &e[coins] [coinname]");
				cfg2.set("addNicknameExec", "[prefix] &aThe nickname &e[name] &awas sucessfully added");
				cfg2.set("removeNicknameExec", "[prefix] &aThe nickname &e[name] &awas sucessfully removed");
				cfg2.set("maintenanceOn", "[prefix] &aThe maintenance mode is enabled");
				cfg2.set("maintenanceOff", "[prefix] &cThe maintenance mode is disabled");
				cfg2.set("buildModeOn", "[prefix] &aBuildmode enabled");
				cfg2.set("buildModeOff", "[prefix] &cBuildmode disabled");
				
				// items
				cfg2.set("compass", "&bNavigator");
				cfg2.set("hide_item", "&6Hide players");
				cfg2.set("lobbychanger", "&cLobby changer");
				cfg2.set("name_tag", "&eAuto-nick");
				cfg2.set("shield", "&5Player-shield");
				cfg2.set("chest", "&9Pets / Boots / Gadgets");
				cfg2.set("noGadget", "&4No gadget selected");
				
				// scoreboard
				cfg2.set("player", "&ePlayer online:");
				cfg2.set("lobby", "&cYour Lobby:");
				
				// the description of the command in the help-popups
				cfg2.set("ulsCMD-reloadDes", "&eReloades the config, permissions and messages files");
				cfg2.set("ulsCMD-setLangDes", "&eChanges the language of the plugin");  
				cfg2.set("helpCMD-boots", "&eOpens the boots-inventory");
				cfg2.set("helpCMD-pet", "&eOpens the pet-options of your selected pet");  
				cfg2.set("helpCMD-luckyspin", "&eSpin you daily lucky-spin");
				cfg2.set("helpCMD-spawn", "&eTeleports you to the spawn");
				
				// the header and footer of the tab-list
				cfg2.set("tabListHeader", "&eGameMagic.de &aLobby");  
				cfg2.set("tabListFooter", "&6GameMagic &7- &4Servernetwork");  
				
				cfg2.save(f2);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	
	public void createMaintenaceModeFile() {
		File f = new File(getDataFolder(), "maintenance.yml");
		FileConfiguration cfg = YamlConfiguration.loadConfiguration(f);

		if (!f.exists()) {
			try {
				f.createNewFile();
				cfg.set("maintenance", "off");

				cfg.save(f);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	
	public void createMySQLFile() {
		File f = new File(getDataFolder(), "mysql.yml");
		FileConfiguration cfg = YamlConfiguration.loadConfiguration(f);

		if (!f.exists()) {
			try {
				f.createNewFile();
				cfg.set("host", "localhost");
				cfg.set("port", "3306");
				cfg.set("database", "gamemagic");
				cfg.set("username", "mysqlmanager");
				cfg.set("password", "");

				cfg.save(f);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	public void createPermissionFile() {
		File f = new File(getDataFolder(), "permissions.yml");
		FileConfiguration cfg = YamlConfiguration.loadConfiguration(f);

		if (!f.exists()) {
			try {
				f.createNewFile();
				cfg.set("ulsUse", "lobby.uls");
				cfg.set("reloadConfigFiles", "lobby.uls.reload");
				cfg.set("setLanguage", "lobby.uls.setlanguage");
				cfg.set("setWarpUse", "lobby.setwarp");
				cfg.set("nickItem", "lobby.nick");
				cfg.set("shieldItem", "lobby.shield"); // this permission is for the item and a shield bypass!
				cfg.set("doubleJump", "lobby.doublejump");
				cfg.set("coinsCMD", "lobby.coins");
				cfg.set("addNicknameUse", "lobby.addnickname");
				cfg.set("removeNicknameUse", "lobby.removenickname");
				cfg.set("joinOnMaintenance", "lobby.joinonmaintenance");
				cfg.set("toggleMaintenanceMode", "lobby.toggleMaintenance");
				cfg.set("buildMode", "lobby.buildMode");
				cfg.set("luckySpinTimeBypass", "lobby.luckyspintimebypass");
				cfg.set("setRankCMD", "lobby.setrank.use");
				cfg.set("setRankCMD-ADMIN", "lobby.setrank.admin");
				cfg.set("setRankCMD-TEAM", "lobby.setrank.team");
				cfg.set("setRankCMD-SPECIAL", "lobby.setrank.special");
				cfg.set("setRankCMD-YT", "lobby.setrank.yt");
				cfg.set("setRankCMD-PLAYER", "lobby.setrank.player");
				cfg.set("setRankCMDAdvanced", "lobby.setrankadvanced");
				cfg.set("adminHelp", "lobby.adminhelp");
				
				// boots, pets, gadgets
				cfg.set("specialBoots", "lobby.specialboots");
				cfg.set("specialPets", "lobby.specialpets");
				cfg.set("specialGadgets", "lobby.specialgadgets");
				cfg.set("gadgetsCooldownBypass", "lobby.gadgetcooldownbypass");
				
				cfg.save(f);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	
	public void createActionbarFile() {
		File f = new File(getDataFolder(), "actionbar.yml");
		FileConfiguration cfg = YamlConfiguration.loadConfiguration(f);

		if (!f.exists()) {
			try {
				f.createNewFile();
				cfg.set("msg1", "&6GameMagic�7-�4Servernetzwerk");
					
				cfg.save(f);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	public void createConfig() {
		File f = new File(getDataFolder(), "config.yml");
		FileConfiguration cfg = YamlConfiguration.loadConfiguration(f);

		if (!f.exists()) {
			try {
				f.createNewFile();
				cfg.set("prefix", "&4[&6Lobby&4]");
				cfg.set("language", "german.yml");
				cfg.set("coinName", "&5Magics");
				cfg.set("sbTitel", "&6GameMagic.de");
				cfg.set("gadgetCooldown", 5);
				cfg.set("actionBarMsgInterval", 200);
				cfg.set("Jumppads", true);
				cfg.set("disableJoinMsg", true);
				cfg.set("disableLeaveMsg", true);
				cfg.set("disableItemDrop", true);
				cfg.set("disableItemPickUp", true);
				cfg.set("disableBlockBreak", true);
				cfg.set("disableBlockPlace", true);
				cfg.set("disableWeatherChange", true);
				cfg.set("disableEntityDamage", true);
				cfg.set("disableFoodChange", true);
				cfg.set("disableInvClick", true);
				cfg.set("disableOffHand", true);
				cfg.set("buildMode", true);
				
				cfg.save(f);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	public String getPermission(String permKey) {
		return getFileConfig(getDataFolder() + File.separator + "permissions.yml").getString(permKey);
	}

	public String getMessage(String msgKey) {
		return getFileConfig(
				getDataFolder() + File.separator + "messages" + File.separator + languageFile).getString(msgKey);
	}

	public String getConfigValueString(String cKey) {
		return getFileConfig(getDataFolder() + File.separator + "config.yml").getString(cKey);
	}
	
	public boolean getConfigValueBoolean(String cKey) {
		return getFileConfig(getDataFolder() + File.separator + "config.yml").getBoolean(cKey);
	}

	public int getConfigValueInt(String cKey) {
		return getFileConfig(getDataFolder() + File.separator + "config.yml").getInt(cKey);
	}
	
	public FileConfiguration getFileConfig(String path) {
		File f = new File(path);
		FileConfiguration cfg = YamlConfiguration.loadConfiguration(f);
		return cfg;
	}

	public static Main getMain() {
		return main;
	}

}
