package gadgets;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import listener.JoinListener;
import lobbySystem.Main;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Color;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;

import utils.ItemCreator;

public class GadgetManager implements Listener {

	private static Main m = Main.getMain();
	public static HashMap<Player, Gadget> playerGadgets = new HashMap<Player, Gadget>();
	
	public static void openGadgetInv(Player p) {
		Inventory inv = Bukkit.createInventory(null, 9*3, "�4Gadgets");
		
		Gadget[] gadgets = Gadget.values();
		for(int i = 0; i < gadgets.length; i++) {
			Gadget gadget = gadgets[i];
			if(gadget.isPermission()) {
				if(p.hasPermission(m.getPermission("specialGadgets"))) {
					List<String> lore = new ArrayList<String>();
					if(gadget != Gadget.DISCOARMOR) {
						lore.add("�e" + gadget.getCost() + " " + ChatColor.translateAlternateColorCodes('&', m.getMessage("costPerActivation").replace("[coins]", m.coinName)));
						inv.setItem(gadget.getSlot(), ItemCreator.crItem(gadget.getMat(), 1, (short) 0, lore, gadget.getDisplayname(), gadget.isEnch(), true));
						
					} else {
						lore.add("�e" + gadget.getCost() + " " + ChatColor.translateAlternateColorCodes('&', m.getMessage("costPerSecond").replace("[coins]", m.coinName)));
						inv.setItem(gadget.getSlot(), ItemCreator.crItemLeatherArmor(gadget.getMat(), 1, gadget.getDisplayname(), gadget.isEnch(), Color.ORANGE, lore));
					}
					
				} else {
					if(gadget != Gadget.DISCOARMOR) {
						inv.setItem(gadget.getSlot(), ItemCreator.crItem(gadget.getMat(), 1, (short) 0, gadget.getDisplayname() + " �7(" + 
								ChatColor.translateAlternateColorCodes('&', m.getMessage("notAvailable")) + "�7)", gadget.isEnch(), true));
						
					} else {
						inv.setItem(gadget.getSlot(), ItemCreator.crItemLeatherArmor(gadget.getMat(), 1, gadget.getDisplayname() + " �7(" + 
								ChatColor.translateAlternateColorCodes('&', m.getMessage("notAvailable")) + "�7)", gadget.isEnch(), Color.ORANGE, null));
					}
				}
			} else {
				List<String> lore = new ArrayList<String>();
				lore.add("�e" + gadget.getCost() + " " + ChatColor.translateAlternateColorCodes('&', m.getMessage("costPerActivation").replace("[coins]", m.coinName)));
				inv.setItem(gadget.getSlot(), ItemCreator.crItem(gadget.getMat(), 1, (short) 0, lore, gadget.getDisplayname(), gadget.isEnch(), true));
			}
		}
		
		inv.setItem(9*2 + 4, ItemCreator.crItem(Material.BARRIER, 1, ChatColor.translateAlternateColorCodes('&', m.getMessage("removeGadget"))));
		
		ItemCreator.fillInvWithDarkGlass(inv);
		p.openInventory(inv);
	}
	
	@EventHandler
	public void onGadgetSelect(InventoryClickEvent e) {
		Player p = (Player) e.getWhoClicked();
		
		if(e.getInventory().getTitle().equals("�4Gadgets")) {
			Gadget gadget = null;
			for(Gadget gadgets : Gadget.values()) {
				if(gadgets.getSlot() == e.getSlot())
					gadget = gadgets;
			}
			
			if(gadget != null) {
				if(gadget.isPermission()) {
					if(!p.hasPermission(m.getPermission("specialGadgets"))) {
						return;
					}
				}
				
				if(playerGadgets.containsKey(p)) {
					if(playerGadgets.get(p) == Gadget.DISCOARMOR && GadgetPlayer.discoPlayers.containsKey(p)) {
						p.closeInventory();
						String msg = m.getMessage("wearDiscoArmor").replace("[prefix]", m.prefix).replace("[discoarmor]", playerGadgets.get(p).getDisplayname());
						p.sendMessage(ChatColor.translateAlternateColorCodes('&', msg));
						return;
					} else {
						playerGadgets.remove(p);
					}
				}
				p.closeInventory();
				p.getInventory().setItem(7, e.getCurrentItem());
				playerGadgets.put(p, gadget);
			}
			
			if(e.getCurrentItem().getType() == Material.BARRIER) {
				if(playerGadgets.containsKey(p)) {
					if(playerGadgets.get(p) == Gadget.DISCOARMOR) {
						if(GadgetPlayer.discoPlayers.containsKey(p)) {
							GadgetPlayer.discoPlayers.get(p).cancel();
							GadgetPlayer.discoPlayers.remove(p);
							GadgetPlayer.discoTimeToPlay.remove(p);
							p.getInventory().setHelmet(null);
							p.getInventory().setChestplate(null);
							p.getInventory().setLeggings(null);
							p.getInventory().setBoots(null);
						}
					}
					playerGadgets.remove(p);
					JoinListener.giveItems(p);
					p.closeInventory();
				}
			}
		}
	}
	
}
