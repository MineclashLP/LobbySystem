package utils;

import java.io.File;
import java.io.IOException;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import lobbySystem.Main;

public class WarpSystem {

	private static Main m = Main.getMain();
	
	public static boolean addWarp(String name, Location loc) {
		File f = new File(m.getDataFolder() + File.separator + "warps.yml");
		FileConfiguration cfg = YamlConfiguration.loadConfiguration(f);
		
		if(!f.exists()) {
			try {
				f.createNewFile();
			} catch (IOException e) {e.printStackTrace();}
		}
		
		if(!cfg.contains(name)) {
			cfg.createSection(name);
			cfg.set(name + ".x", loc.getX());
			cfg.set(name + ".y", loc.getY());
			cfg.set(name + ".z", loc.getZ());
			cfg.set(name + ".yaw", loc.getYaw());
			cfg.set(name + ".pitch", loc.getPitch());
			cfg.set(name + ".world", loc.getWorld().getName());
			
			try {
				cfg.save(f);
			} catch (IOException e) {e.printStackTrace();}
			
			return true;
		} else {
			return false;
		}
	}
	
	public static boolean doesWarpExists(String name) {
		File f = new File(m.getDataFolder() + File.separator + "warps.yml");
		FileConfiguration cfg = YamlConfiguration.loadConfiguration(f);
		
		if(f.exists() && cfg.contains(name)) {
			return true;
		}
		return false;
	}
	
	public static Location getWarpLoc(String name) {
		File f = new File(m.getDataFolder() + File.separator + "warps.yml");
		FileConfiguration cfg = YamlConfiguration.loadConfiguration(f);
		
		if(f.exists()) {
			Location loc = new Location(Bukkit.getWorld(cfg.getString(name + ".world")),
					cfg.getDouble(name + ".x"),
					cfg.getDouble(name + ".y"), 
					cfg.getDouble(name + ".z"));
			loc.setYaw((float) cfg.getDouble(name + ".yaw"));
			loc.setPitch((float) cfg.getDouble(name + ".pitch"));
			
			return loc;
		} else {
			return null;
		}
	}
	
	public static Location getWarpLoc(String name, World w) {
		File f = new File(m.getDataFolder() + File.separator + "warps.yml");
		FileConfiguration cfg = YamlConfiguration.loadConfiguration(f);
		
		if(f.exists()) {
			Location loc = new Location(
					w,
					cfg.getDouble(name + ".x"),
					cfg.getDouble(name + ".y"), 
					cfg.getDouble(name + ".z"));
			loc.setYaw((float) cfg.getDouble(name + ".yaw"));
			loc.setPitch((float) cfg.getDouble(name + ".pitch"));
			
			return loc;
		} else {
			return null;
		}
	}
	
}
